/**
 * =============================================================================
 * DONNÉES DE DÉMONSTRATION — APPLICATION DE PRÉSENTATION
 * =============================================================================
 * Ces constantes et générateurs alimentent l'UI tant que le backend n'est pas
 * branché. Ne pas les utiliser en production.
 *
 * Pour basculer vers l'API réelle : implémenter les mêmes signatures dans
 * `src/services/api.ts` (les écrans ne connaissent que le service).
 * =============================================================================
 */

import type {
  Asset,
  BacktestStats,
  Candle,
  ConditionGroup,
  DataProvider,
  HelpArticle,
  PatternMatch,
  Scenario,
  SyncStep,
} from "../types";

export const IS_DEMO = true;

export const DEMO_NOTICE =
  "Données fictives destinées à la présentation de l'application.";

export const APP_VERSION = "1.4.2";
export const APP_UPDATED_AT = "12 oct. 2024";

export const MOCK_ASSETS: Asset[] = [
  {
    id: "btc-usdt",
    symbol: "BTC",
    pairLabel: "BTC/USDT",
    name: "Bitcoin",
    category: "crypto",
    exchange: "Binance",
    price: 68542.32,
    change24h: 2.14,
    quote: "USDT",
    decimals: 2,
  },
  {
    id: "eth-usdt",
    symbol: "ETH",
    pairLabel: "ETH/USDT",
    name: "Ethereum",
    category: "crypto",
    exchange: "Binance",
    price: 3246.77,
    change24h: 1.85,
    quote: "USDT",
    decimals: 2,
  },
  {
    id: "sol-usdt",
    symbol: "SOL",
    pairLabel: "SOL/USDT",
    name: "Solana",
    category: "crypto",
    exchange: "Binance",
    price: 158.42,
    change24h: 3.21,
    quote: "USDT",
    decimals: 2,
  },
  {
    id: "eurusd",
    symbol: "EURUSD",
    pairLabel: "EUR/USD",
    name: "EUR / USD",
    category: "forex",
    exchange: "Forex",
    price: 1.0823,
    change24h: -1.26,
    quote: "",
    decimals: 4,
  },
  {
    id: "gbpusd",
    symbol: "GBPUSD",
    pairLabel: "GBP/USD",
    name: "GBP / USD",
    category: "forex",
    exchange: "Forex",
    price: 1.2698,
    change24h: 0.08,
    quote: "",
    decimals: 4,
  },
  {
    id: "aapl",
    symbol: "AAPL",
    pairLabel: "AAPL",
    name: "Apple",
    category: "stock",
    exchange: "NASDAQ",
    price: 189.32,
    change24h: 0.76,
    quote: "USD",
    decimals: 2,
  },
  {
    id: "msft",
    symbol: "MSFT",
    pairLabel: "MSFT",
    name: "Microsoft",
    category: "stock",
    exchange: "NASDAQ",
    price: 428.15,
    change24h: 1.12,
    quote: "USD",
    decimals: 2,
  },
  {
    id: "xauusd",
    symbol: "XAUUSD",
    pairLabel: "XAU/USD",
    name: "Or",
    category: "commodity",
    exchange: "COMEX",
    price: 2328.4,
    change24h: 0.42,
    quote: "USD",
    decimals: 2,
  },
  {
    id: "wti",
    symbol: "WTI",
    pairLabel: "WTI",
    name: "Pétrole WTI",
    category: "commodity",
    exchange: "NYMEX",
    price: 81.26,
    change24h: -0.54,
    quote: "USD",
    decimals: 2,
  },
];

/** PRNG déterministe — mêmes bougies à chaque chargement (démo). */
function seeded(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function generateCandles(opts: {
  count: number;
  startPrice: number;
  seed: number;
  startTime?: number;
  intervalMs?: number;
  volatility?: number;
}): Candle[] {
  const {
    count,
    startPrice,
    seed,
    startTime = Date.UTC(2024, 3, 8, 8, 0, 0),
    intervalMs = 60 * 60 * 1000,
    volatility = 0.012,
  } = opts;
  const rand = seeded(seed);
  const candles: Candle[] = [];
  let price = startPrice;

  for (let i = 0; i < count; i++) {
    const drift = (rand() - 0.48) * volatility;
    const open = price;
    const shock = (rand() - 0.5) * volatility * 1.6;
    let close = open * (1 + drift + shock * 0.4);
    // Léger motif de hausse en fin de série (pattern « opportunité »)
    if (i > count - 28 && i < count - 6) {
      close = open * (1 + Math.abs(drift) * 0.35 + (rand() - 0.35) * volatility * 0.6);
    }
    if (i >= count - 6) {
      close = open * (1 + 0.004 + (rand() - 0.3) * volatility * 0.5);
    }
    const wick = Math.abs(open - close) * (0.4 + rand() * 1.4) + open * volatility * 0.15;
    const high = Math.max(open, close) + wick * (0.3 + rand() * 0.7);
    const low = Math.min(open, close) - wick * (0.3 + rand() * 0.7);
    const volume = 800 + rand() * 4200 + (i > count - 20 ? 1500 : 0);
    candles.push({
      time: startTime + i * intervalMs,
      open,
      high,
      low: Math.max(low, open * 0.97),
      close,
      volume,
    });
    price = close;
  }
  return candles;
}

export const MOCK_BTC_CANDLES: Candle[] = generateCandles({
  count: 90,
  startPrice: 64200,
  seed: 42,
  startTime: Date.UTC(2024, 3, 8),
  intervalMs: 6 * 60 * 60 * 1000,
  volatility: 0.011,
});

function matchCandles(seed: number, start: number, direction: "up" | "down" | "flat"): Candle[] {
  const vol = direction === "flat" ? 0.008 : 0.013;
  const c = generateCandles({
    count: 36,
    startPrice: start,
    seed,
    volatility: vol,
  });
  if (direction === "down") {
    return c.map((x, i) => {
      const f = 1 - i * 0.0018;
      return { ...x, open: x.open * f, close: x.close * f, high: x.high * f, low: x.low * f };
    });
  }
  return c;
}

export const MOCK_MATCHES: PatternMatch[] = [
  {
    id: "m1",
    rank: 1,
    score: 9.6,
    date: "14 fév. 2024",
    dateShort: "14 fév.",
    candles: 38,
    direction: "bullish",
    volumeTrend: "up",
    candlesData: matchCandles(101, 51200, "up"),
    strengths: [
      "Même structure de mouvement",
      "Amplitude similaire (+2,3%)",
      "Volatilité comparable",
      "Volume en hausse",
    ],
  },
  {
    id: "m2",
    rank: 2,
    score: 9.2,
    date: "3 jan. 2024",
    dateShort: "3 jan.",
    candles: 36,
    direction: "bullish",
    volumeTrend: "up",
    candlesData: matchCandles(202, 42800, "up"),
    strengths: [
      "Canal haussier identique",
      "Retracement Fibonacci 38,2%",
      "Volume croissant sur 4 séances",
    ],
  },
  {
    id: "m3",
    rank: 3,
    score: 8.9,
    date: "22 nov. 2023",
    dateShort: "22 nov.",
    candles: 32,
    direction: "neutral",
    volumeTrend: "flat",
    candlesData: matchCandles(303, 37100, "flat"),
    strengths: ["Compression de range similaire", "Volatilité en contraction", "Soutien horizontal"],
  },
  {
    id: "m4",
    rank: 4,
    score: 8.7,
    date: "5 oct. 2023",
    dateShort: "5 oct.",
    candles: 40,
    direction: "bullish",
    volumeTrend: "up",
    candlesData: matchCandles(404, 27800, "up"),
    strengths: ["Breakout de consolidation", "Plus hauts croissants", "Volume d'accumulation"],
  },
  {
    id: "m5",
    rank: 5,
    score: 8.4,
    date: "18 août 2023",
    dateShort: "18 août",
    candles: 28,
    direction: "bearish",
    volumeTrend: "down",
    candlesData: matchCandles(505, 29400, "down"),
    strengths: ["Épaule-tête-épaule partielle", "Perte de momentum", "Volume vendeur"],
  },
  {
    id: "m6",
    rank: 6,
    score: 8.1,
    date: "2 juil. 2023",
    dateShort: "2 juil.",
    candles: 34,
    direction: "bullish",
    volumeTrend: "up",
    candlesData: matchCandles(606, 30500, "up"),
    strengths: ["Rebond sur moyenne mobile 50", "Divergences RSI résolues"],
  },
  {
    id: "m7",
    rank: 7,
    score: 7.8,
    date: "19 mai 2023",
    dateShort: "19 mai",
    candles: 30,
    direction: "neutral",
    volumeTrend: "flat",
    candlesData: matchCandles(707, 27100, "flat"),
    strengths: ["Triangle symétrique", "Volume en diminution"],
  },
  {
    id: "m8",
    rank: 8,
    score: 7.4,
    date: "11 mars 2023",
    dateShort: "11 mars",
    candles: 42,
    direction: "bearish",
    volumeTrend: "down",
    candlesData: matchCandles(808, 22400, "down"),
    strengths: ["Lower high successifs", "Cassure de support"],
  },
];

export const MOCK_SCENARIOS: Scenario[] = [
  {
    id: "s1",
    horizon: "Très court terme",
    rangeLabel: "1-6 bougies",
    direction: "bullish",
    probability: 62,
    deviation: 1.8,
  },
  {
    id: "s2",
    horizon: "Court terme",
    rangeLabel: "7-20 bougies",
    direction: "bullish",
    probability: 56,
    deviation: 3.4,
  },
  {
    id: "s3",
    horizon: "Moyen terme",
    rangeLabel: "21-60 bougies",
    direction: "neutral",
    probability: 48,
    deviation: 6.7,
  },
  {
    id: "s4",
    horizon: "Long terme",
    rangeLabel: "61+ bougies",
    direction: "bullish",
    probability: 52,
    deviation: 12.3,
  },
];

export const MOCK_OUTCOME = { bullish: 68, bearish: 10, leftover: 22 };

export const MOCK_CONDITIONS: ConditionGroup[] = [
  {
    id: "confirm",
    title: "Confirmation haussière",
    tone: "bullish",
    items: [
      { id: "c1", label: "Franchissement de la résistance", value: "69 500 $" },
      { id: "c2", label: "Augmentation du volume" },
      { id: "c3", label: "Accélération du mouvement" },
    ],
  },
  {
    id: "risk",
    title: "Risque de baisse",
    tone: "bearish",
    items: [
      { id: "r1", label: "Cassure du support", value: "64 200 $" },
      { id: "r2", label: "Ralentissement de la dynamique" },
      { id: "r3", label: "Hausse de la volatilité" },
    ],
  },
  {
    id: "invalid",
    title: "Invalide l'analyse",
    tone: "invalid",
    items: [
      { id: "i1", label: "Divergence importante" },
      { id: "i2", label: "Écart avec les correspondances" },
    ],
  },
];

export const MOCK_PROVIDERS: DataProvider[] = [
  {
    id: "yahoo",
    name: "Yahoo Finance",
    subtitle: "Actions, indices, ETF",
    connected: true,
    primary: true,
    color: "#7c5cff",
    icon: "yahoo",
  },
  {
    id: "binance",
    name: "Binance API",
    subtitle: "Binance API",
    connected: true,
    primary: false,
    color: "#f0b90b",
    icon: "binance",
  },
  {
    id: "kraken",
    name: "Kraken API",
    subtitle: "Crypto API",
    connected: true,
    primary: false,
    color: "#5b4dff",
    icon: "kraken",
  },
  {
    id: "iress",
    name: "IRESS API",
    subtitle: "Generic Forex/Equities",
    connected: true,
    primary: false,
    color: "#3b9eff",
    icon: "iress",
  },
  {
    id: "forexfeed",
    name: "Forex Data Feed",
    subtitle: "Forex Data",
    connected: false,
    primary: false,
    color: "#2ee6c8",
    icon: "forex",
  },
];

export const MOCK_BACKTEST: BacktestStats = {
  cases: 142,
  correctDirection: 58,
  meanError: 2.8,
  calibration: 0.63,
  bySimilarity: [
    { range: "9-10", accuracy: 72, error: 0.9 },
    { range: "8-8,9", accuracy: 61, error: 2.3 },
    { range: "7-7,9", accuracy: 54, error: 3.7 },
    { range: "6-6,9", accuracy: 48, error: 5.1 },
  ],
  equityCurve: [
    0, 1.2, 0.4, 2.1, 3.4, 2.8, 4.1, 3.2, 5.0, 4.2, 6.1, 5.4, 7.2, 6.3, 8.1, 7.4, 9.6, 8.8, 10.4,
    9.1, 11.2, 10.1, 12.4, 11.6, 13.2, 12.0, 14.1, 13.4, 15.2, 14.6, 16.8, 15.9, 17.4, 16.2, 18.1,
    17.3, 19.2, 18.4, 20.1, 19.0, 18.2, 19.6, 20.8, 19.9, 21.4, 20.6, 22.1, 21.3, 23.0,
  ],
};

export const MOCK_HELP: HelpArticle[] = [
  {
    id: "guide",
    title: "Guide de démarrage",
    icon: "book",
    body: [
      "MarketScope compare le motif de prix actuel à l'historique pour estimer les prolongements les plus probables.",
      "1. Choisissez une classe d'actifs (crypto, forex, actions, matières).",
      "2. Sélectionnez un symbole puis une unité de temps.",
      "3. Lancez l'analyse : le mode Auto détecte le pattern sur les dernières bougies.",
      "4. Parcourez les correspondances, les scénarios et les conditions d'invalidation.",
      "Cette version présente des données fictives. Le backend branchera les mêmes écrans.",
    ],
  },
  {
    id: "results",
    title: "Types de résultats",
    icon: "info",
    body: [
      "Score de similarité (0 à 10) : proximité de la structure, de l'amplitude et du volume.",
      "Direction : haussière, baissière ou neutre, d'après le prolongement historique.",
      "Scénarios : probabilités par horizon (très court, court, moyen, long terme).",
      "Conditions : niveaux qui confirment, fragilisent ou invalident l'analyse.",
    ],
  },
  {
    id: "granularity",
    title: "Types de granularité",
    icon: "grid",
    body: [
      "1m / 15m : scalping et intradieu. Plus de bruit, fenêtres courtes.",
      "1h : swing intra-semaine, bon compromis signal / bruit.",
      "1j : tendance de fond. 1s = 1 semaine, 1M = 1 mois.",
      "La granularité choisie s'applique à la recherche des correspondances.",
    ],
  },
  {
    id: "scores",
    title: "Interprétation des scores",
    icon: "score",
    body: [
      "9,0 – 10 : excellente correspondance, structure quasi identique.",
      "8,0 – 8,9 : bonne correspondance, quelques écarts d'amplitude.",
      "7,0 – 7,9 : correspondance acceptable, à confirmer par le volume.",
      "Sous 7 : signal faible — élargir la période ou changer de timeframe.",
    ],
  },
  {
    id: "faq",
    title: "Questions fréquentes",
    icon: "faq",
    body: [
      "Les résultats sont-ils des conseils d'investissement ? Non. Outil d'aide à l'analyse technique uniquement.",
      "Puis-je importer mes propres bougies ? Oui, via « Dossier local » dans Paramètres (backend à venir).",
      "Comment exporter ? Menu → Exporter les résultats (PDF, CSV, JSON, image).",
    ],
  },
  {
    id: "support-chat",
    title: "Contacter le support",
    icon: "chat",
    body: [
      "Écrivez-nous à support@marketscope.app (adresse de démonstration).",
      "Décrivez l'écran concerné, le symbole et l'unité de temps.",
      "Les demandes de démo sont traitées sous 24 h ouvrées.",
    ],
  },
  {
    id: "support-phone",
    title: "Appeler le support",
    icon: "phone",
    body: [
      "Ligne démo : +33 1 86 95 00 00",
      "Horaires : lun.–ven. 9h00 – 18h00 (CET).",
      "Précisez que vous utilisez la version de présentation 1.4.2.",
    ],
  },
];

export const MOCK_SYNC_STEPS: SyncStep[] = [
  { id: "connect", label: "Connexion aux fournisseurs" },
  { id: "fetch", label: "Récupération des données" },
  { id: "norm", label: "Normalisation" },
  { id: "dedup", label: "Dédoublonnage" },
  { id: "cache", label: "Mise en cache" },
];

export const CHART_AXIS = [60000, 64000, 68000, 72000];
export const MATCH_CHART_AXIS = [60000, 65000, 70000];
