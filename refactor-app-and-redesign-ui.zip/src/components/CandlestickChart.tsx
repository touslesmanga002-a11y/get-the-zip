import { useMemo, useRef, useState, type PointerEvent } from "react";
import type { Candle, PatternRange } from "../types";
import { cn } from "../utils/cn";

interface Props {
  candles: Candle[];
  height?: number;
  showVolume?: boolean;
  showAxis?: boolean;
  selection?: PatternRange | null;
  onSelectionChange?: (r: PatternRange) => void;
  interactive?: boolean;
  overlay?: Candle[] | null;
  overlayLabel?: string;
  patternLabel?: string;
  axisValues?: number[];
  dates?: string[];
  highlightLast?: number;
}

function extents(candles: Candle[]) {
  let min = Infinity;
  let max = -Infinity;
  let vmax = 0;
  for (const c of candles) {
    if (c.low < min) min = c.low;
    if (c.high > max) max = c.high;
    if (c.volume > vmax) vmax = c.volume;
  }
  const pad = (max - min) * 0.08 || 1;
  return { min: min - pad, max: max + pad, vmax: vmax || 1 };
}

export function CandlestickChart({
  candles,
  height = 260,
  showVolume = true,
  showAxis = true,
  selection,
  onSelectionChange,
  interactive = false,
  overlay,
  overlayLabel = "Correspondance",
  patternLabel = "Pattern",
  axisValues,
  dates,
  highlightLast,
}: Props) {
  const volH = showVolume ? 46 : 0;
  const plotH = height - volH;
  const padL = showAxis ? 8 : 4;
  const padR = showAxis ? 44 : 8;
  const width = 360;
  const innerW = width - padL - padR;

  const { min, max, vmax } = useMemo(() => extents(candles), [candles]);
  const y = (price: number) =>
    8 + ((max - price) / (max - min)) * (plotH - 16);
  const x = (i: number) => padL + ((i + 0.5) / candles.length) * innerW;
  const cw = Math.max(2.2, (innerW / candles.length) * 0.62);

  const axis = axisValues ?? niceAxis(min, max);

  const [activeDrag, setActiveDrag] = useState<"l" | "r" | "move" | null>(null);
  const dragRef = useRef<{
    mode: "l" | "r" | "move";
    startClientX: number;
    startStart: number;
    startEnd: number;
  } | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const indexFromClientX = (clientX: number) => {
    if (!svgRef.current) return 0;
    const rect = svgRef.current.getBoundingClientRect();
    const sx = ((clientX - rect.left) / rect.width) * width;
    const i = Math.round(((sx - padL) / innerW) * candles.length - 0.5);
    return Math.max(0, Math.min(candles.length - 1, i));
  };

  const startDragHandle = (
    mode: "l" | "r" | "move",
    e: PointerEvent<SVGElement>,
  ) => {
    if (!interactive || !selection || !onSelectionChange) return;
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    dragRef.current = {
      mode,
      startClientX: e.clientX,
      startStart: selection.startIndex,
      startEnd: selection.endIndex,
    };
    setActiveDrag(mode);
  };

  const onGlobalPointerMove = (e: PointerEvent<SVGSVGElement>) => {
    const i = indexFromClientX(e.clientX);
    setHover(i);

    if (!dragRef.current || !selection || !onSelectionChange || !svgRef.current)
      return;

    const { mode, startClientX, startStart, startEnd } = dragRef.current;
    const rect = svgRef.current.getBoundingClientRect();
    const deltaPx = e.clientX - startClientX;
    const pxPerCandle = (rect.width / width) * (innerW / candles.length);
    const deltaCandles = Math.round(deltaPx / (pxPerCandle || 1));

    if (mode === "l") {
      const newStart = Math.max(
        0,
        Math.min(startEnd - 4, startStart + deltaCandles),
      );
      if (newStart !== selection.startIndex) {
        onSelectionChange({ startIndex: newStart, endIndex: startEnd });
      }
    } else if (mode === "r") {
      const newEnd = Math.max(
        startStart + 4,
        Math.min(candles.length - 1, startEnd + deltaCandles),
      );
      if (newEnd !== selection.endIndex) {
        onSelectionChange({ startIndex: startStart, endIndex: newEnd });
      }
    } else if (mode === "move") {
      const len = startEnd - startStart;
      let newStart = startStart + deltaCandles;
      newStart = Math.max(0, Math.min(candles.length - 1 - len, newStart));
      const newEnd = newStart + len;
      if (
        newStart !== selection.startIndex ||
        newEnd !== selection.endIndex
      ) {
        onSelectionChange({ startIndex: newStart, endIndex: newEnd });
      }
    }
  };

  const onGlobalPointerUp = () => {
    dragRef.current = null;
    setActiveDrag(null);
  };

  const sel =
    selection && candles.length
      ? {
          x: Math.max(padL, x(selection.startIndex) - cw * 1.2),
          w: Math.max(
            16,
            x(selection.endIndex) - x(selection.startIndex) + cw * 2.4,
          ),
          candleCount: selection.endIndex - selection.startIndex + 1,
        }
      : null;

  return (
    <div className="relative w-full select-none">
      <svg
        ref={svgRef}
        viewBox={`0 0 ${width} ${height}`}
        className="w-full touch-none"
        onPointerMove={onGlobalPointerMove}
        onPointerUp={onGlobalPointerUp}
        onPointerLeave={() => {
          onGlobalPointerUp();
          setHover(null);
        }}
      >
        <defs>
          {/* Glowing gradient for selection zone */}
          <linearGradient
            id="ms-sel-fill"
            x1="0"
            y1="0"
            x2="0"
            y2="1"
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0%" stopColor="#10b981" stopOpacity="0.22" />
            <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#10b981" stopOpacity="0.25" />
          </linearGradient>

          <filter id="ms-sel-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="glow" />
            <feComposite in="SourceGraphic" in2="glow" operator="over" />
          </filter>
        </defs>

        {/* Grid lines and Price Axis */}
        {axis.map((v) => (
          <g key={v}>
            <line
              x1={padL}
              x2={width - padR + 6}
              y1={y(v)}
              y2={y(v)}
              stroke="#132c45"
              strokeDasharray="3 5"
              strokeWidth={0.8}
            />
            {showAxis && (
              <text
                x={width - 6}
                y={y(v) + 3}
                textAnchor="end"
                fill="#7d97ad"
                fontSize="8"
                fontFamily="Inter, sans-serif"
              >
                {formatAxis(v)}
              </text>
            )}
          </g>
        ))}

        {/* Dimming outside selection when interactive */}
        {sel && interactive && (
          <>
            {/* Left dimmed area */}
            <rect
              x={padL}
              y={6}
              width={Math.max(0, sel.x - padL)}
              height={plotH - 10}
              fill="rgba(5, 13, 24, 0.45)"
            />
            {/* Right dimmed area */}
            <rect
              x={sel.x + sel.w}
              y={6}
              width={Math.max(0, width - padR - (sel.x + sel.w))}
              height={plotH - 10}
              fill="rgba(5, 13, 24, 0.45)"
            />
          </>
        )}

        {/* The Green Analysis Selection Box Background */}
        {sel && (
          <g>
            <rect
              x={sel.x}
              y={6}
              width={sel.w}
              height={plotH - 10}
              rx={8}
              fill="url(#ms-sel-fill)"
              stroke={activeDrag ? "#34d399" : "#2ee6c8"}
              strokeWidth={activeDrag ? 2.2 : 1.8}
            />

            {/* Subtle vertical striping inside selected zone */}
            <line
              x1={sel.x + sel.w * 0.25}
              x2={sel.x + sel.w * 0.25}
              y1={7}
              y2={plotH - 5}
              stroke="rgba(46, 230, 200, 0.12)"
              strokeDasharray="2 3"
              strokeWidth={1}
            />
            <line
              x1={sel.x + sel.w * 0.5}
              x2={sel.x + sel.w * 0.5}
              y1={7}
              y2={plotH - 5}
              stroke="rgba(46, 230, 200, 0.18)"
              strokeDasharray="2 3"
              strokeWidth={1}
            />
            <line
              x1={sel.x + sel.w * 0.75}
              x2={sel.x + sel.w * 0.75}
              y1={7}
              y2={plotH - 5}
              stroke="rgba(46, 230, 200, 0.12)"
              strokeDasharray="2 3"
              strokeWidth={1}
            />
          </g>
        )}

        {/* Candlesticks */}
        {candles.map((c, i) => {
          const up = c.close >= c.open;
          const color = up ? "#34d399" : "#f43f5e";
          const inSelection =
            selection &&
            i >= selection.startIndex &&
            i <= selection.endIndex;

          const dim =
            selection && interactive
              ? inSelection
                ? 1
                : 0.35
              : highlightLast != null && i < candles.length - highlightLast
                ? 0.35
                : 1;

          const bodyTop = y(Math.max(c.open, c.close));
          const bodyBot = y(Math.min(c.open, c.close));
          const bh = Math.max(1.2, bodyBot - bodyTop);

          return (
            <g key={c.time} opacity={dim}>
              <line
                x1={x(i)}
                x2={x(i)}
                y1={y(c.high)}
                y2={y(c.low)}
                stroke={color}
                strokeWidth={1.2}
              />
              <rect
                x={x(i) - cw / 2}
                y={bodyTop}
                width={cw}
                height={bh}
                rx={0.6}
                fill={color}
              />
            </g>
          );
        })}

        {/* Overlay comparison candles (e.g. historical pattern overlay) */}
        {overlay &&
          overlay.slice(0, candles.length).map((c, i) => {
            const up = c.close >= c.open;
            const color = up
              ? "rgba(96,165,250,0.85)"
              : "rgba(248,113,113,0.7)";
            const bodyTop = y(Math.max(c.open, c.close));
            const bodyBot = y(Math.min(c.open, c.close));
            return (
              <rect
                key={`ov-${i}`}
                x={x(i) - cw / 2}
                y={bodyTop}
                width={cw}
                height={Math.max(1, bodyBot - bodyTop)}
                fill={color}
                opacity={0.45}
              />
            );
          })}

        {/* INTERACTIVE SELECTION HANDLES & GESTURES */}
        {sel && interactive && (
          <g>
            {/* Center Draggable Zone (Moves entire window) */}
            <rect
              x={sel.x + 8}
              y={6}
              width={Math.max(1, sel.w - 16)}
              height={plotH - 10}
              fill="transparent"
              className={cn(
                "cursor-grab active:cursor-grabbing",
                activeDrag === "move" && "cursor-grabbing",
              )}
              onPointerDown={(e) => startDragHandle("move", e)}
            />

            {/* Top Badge: "Zone d'analyse: X bougies (Glisser)" */}
            <g
              transform={`translate(${Math.max(
                padL + 45,
                Math.min(width - padR - 45, sel.x + sel.w / 2),
              )}, 16)`}
              className="cursor-grab active:cursor-grabbing"
              onPointerDown={(e) => startDragHandle("move", e)}
            >
              <rect
                x="-46"
                y="-10"
                width="92"
                height="19"
                rx="9.5"
                fill="#071b2c"
                stroke="#2ee6c8"
                strokeWidth="1.2"
                filter="url(#ms-sel-glow)"
              />
              <circle cx="-34" cy="-0.5" r="2.5" fill="#34d399" />
              <text
                x="-26"
                y="3"
                fill="#e6fff9"
                fontSize="8.5"
                fontWeight="700"
                fontFamily="Inter, sans-serif"
              >
                {sel.candleCount} bougies
              </text>
              <path
                d="M26 -3 L30 -0.5 L26 2 M34 -3 L30 -0.5 L34 2"
                stroke="#34d399"
                strokeWidth="1.1"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </g>

            {/* LEFT HANDLE (Resize Left) */}
            <g
              className="cursor-ew-resize"
              onPointerDown={(e) => startDragHandle("l", e)}
            >
              {/* Invisible large touch target (32px wide) */}
              <rect
                x={sel.x - 16}
                y={6}
                width={32}
                height={plotH - 10}
                fill="transparent"
              />
              {/* Vertical accent bar */}
              <line
                x1={sel.x}
                x2={sel.x}
                y1={6}
                y2={plotH - 4}
                stroke={activeDrag === "l" ? "#ffffff" : "#2ee6c8"}
                strokeWidth={activeDrag === "l" ? 2.5 : 1.8}
              />
              {/* Tactile Grip Knob at Vertical Center */}
              <rect
                x={sel.x - 5.5}
                y={plotH / 2 - 16}
                width={11}
                height={32}
                rx={5.5}
                fill={activeDrag === "l" ? "#34d399" : "#0d3b4c"}
                stroke="#2ee6c8"
                strokeWidth={1.4}
              />
              {/* Grip lines on knob */}
              <line
                x1={sel.x - 2}
                x2={sel.x - 2}
                y1={plotH / 2 - 7}
                y2={plotH / 2 + 7}
                stroke={activeDrag === "l" ? "#06201c" : "#e6fff9"}
                strokeWidth={1.2}
                strokeLinecap="round"
              />
              <line
                x1={sel.x + 2}
                x2={sel.x + 2}
                y1={plotH / 2 - 7}
                y2={plotH / 2 + 7}
                stroke={activeDrag === "l" ? "#06201c" : "#e6fff9"}
                strokeWidth={1.2}
                strokeLinecap="round"
              />
            </g>

            {/* RIGHT HANDLE (Resize Right) */}
            <g
              className="cursor-ew-resize"
              onPointerDown={(e) => startDragHandle("r", e)}
            >
              {/* Invisible large touch target (32px wide) */}
              <rect
                x={sel.x + sel.w - 16}
                y={6}
                width={32}
                height={plotH - 10}
                fill="transparent"
              />
              {/* Vertical accent bar */}
              <line
                x1={sel.x + sel.w}
                x2={sel.x + sel.w}
                y1={6}
                y2={plotH - 4}
                stroke={activeDrag === "r" ? "#ffffff" : "#2ee6c8"}
                strokeWidth={activeDrag === "r" ? 2.5 : 1.8}
              />
              {/* Tactile Grip Knob at Vertical Center */}
              <rect
                x={sel.x + sel.w - 5.5}
                y={plotH / 2 - 16}
                width={11}
                height={32}
                rx={5.5}
                fill={activeDrag === "r" ? "#34d399" : "#0d3b4c"}
                stroke="#2ee6c8"
                strokeWidth={1.4}
              />
              {/* Grip lines on knob */}
              <line
                x1={sel.x + sel.w - 2}
                x2={sel.x + sel.w - 2}
                y1={plotH / 2 - 7}
                y2={plotH / 2 + 7}
                stroke={activeDrag === "r" ? "#06201c" : "#e6fff9"}
                strokeWidth={1.2}
                strokeLinecap="round"
              />
              <line
                x1={sel.x + sel.w + 2}
                x2={sel.x + sel.w + 2}
                y1={plotH / 2 - 7}
                y2={plotH / 2 + 7}
                stroke={activeDrag === "r" ? "#06201c" : "#e6fff9"}
                strokeWidth={1.2}
                strokeLinecap="round"
              />
            </g>
          </g>
        )}

        {/* Volume Sub-Chart */}
        {showVolume &&
          candles.map((c, i) => {
            const up = c.close >= c.open;
            const vh = (c.volume / vmax) * (volH - 8);
            return (
              <rect
                key={`v-${c.time}`}
                x={x(i) - cw / 2}
                y={height - 4 - vh}
                width={cw}
                height={vh}
                rx={0.5}
                fill={up ? "#34d399" : "#f43f5e"}
                opacity={0.55}
              />
            );
          })}

        {/* Crosshair on hover */}
        {hover != null && candles[hover] && (
          <line
            x1={x(hover)}
            x2={x(hover)}
            y1={4}
            y2={height - 2}
            stroke="#7d97ad"
            strokeDasharray="2 3"
            strokeWidth={0.8}
          />
        )}
      </svg>

      {/* Date labels */}
      {dates && dates.length > 0 && (
        <div className="mt-0.5 flex justify-between px-1 text-[10px] text-ms-muted">
          {dates.map((d) => (
            <span key={d}>{d}</span>
          ))}
        </div>
      )}

      {/* Legend if overlay is provided */}
      {overlay && (
        <div className="mt-2 flex items-center justify-center gap-4 text-[11px] text-ms-muted">
          <span className="flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-full bg-ms-green" /> {patternLabel}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-full bg-sky-400" /> {overlayLabel}
          </span>
        </div>
      )}
    </div>
  );
}

function niceAxis(min: number, max: number): number[] {
  const steps = 4;
  const step = (max - min) / steps;
  const res: number[] = [];
  for (let i = 0; i <= steps; i++) {
    res.push(min + step * i);
  }
  return res;
}

function formatAxis(v: number): string {
  if (v >= 1000) return `${(v / 1000).toFixed(1)}k`;
  if (v >= 1) return v.toFixed(2);
  return v.toFixed(4);
}

export function MiniSpark({
  candles,
  width = 64,
  height = 32,
}: {
  candles: Candle[];
  width?: number;
  height?: number;
}) {
  if (!candles || candles.length < 2) return null;
  const closes = candles.map((c) => c.close);
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const range = max - min || 1;
  const up = closes[closes.length - 1] >= closes[0];

  const points = closes
    .map((c, i) => {
      const px = (i / (closes.length - 1)) * (width - 4) + 2;
      const py = height - 3 - ((c - min) / range) * (height - 6);
      return `${px.toFixed(1)},${py.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg width={width} height={height} className="overflow-visible shrink-0">
      <polyline
        points={points}
        fill="none"
        stroke={up ? "#34d399" : "#f43f5e"}
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function EquityChart({
  values,
  height = 140,
}: {
  values: number[];
  height?: number;
}) {
  if (!values || values.length < 2) return null;
  const width = 340;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  const points = values.map((v, i) => {
    const px = (i / (values.length - 1)) * (width - 20) + 10;
    const py = height - 16 - ((v - min) / range) * (height - 32);
    return { x: px, y: py };
  });

  const polylineStr = points.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const first = points[0];
  const last = points[points.length - 1];
  const areaPath = `M ${first.x} ${first.y} L ${points
    .map((p) => `${p.x} ${p.y}`)
    .join(" L ")} L ${last.x} ${height - 4} L ${first.x} ${height - 4} Z`;

  return (
    <div className="relative w-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full">
        <defs>
          <linearGradient id="eq-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2ee6c8" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#2ee6c8" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        <path d={areaPath} fill="url(#eq-grad)" />
        <polyline
          points={polylineStr}
          fill="none"
          stroke="#2ee6c8"
          strokeWidth={2.2}
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Start and end dots */}
        <circle cx={first.x} cy={first.y} r={3} fill="#10b981" />
        <circle cx={last.x} cy={last.y} r={4} fill="#2ee6c8" stroke="#ffffff" strokeWidth={1.5} />
      </svg>
    </div>
  );
}
