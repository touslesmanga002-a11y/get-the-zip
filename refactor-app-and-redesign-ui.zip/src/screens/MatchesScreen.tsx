import { useMemo, useState } from "react";
import { MiniSpark } from "../components/CandlestickChart";
import { IconChevronRight, IconFilter } from "../components/Icons";
import { Header, Screen, Scroll } from "../components/ui";
import { useApp } from "../context/AppContext";
import { directionLabel, formatScore, cnScoreColor } from "../utils/format";
import { cn } from "../utils/cn";
import type { Direction, VolumeTrend } from "../types";

function DirChip({ d }: { d: Direction }) {
  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-[10px] font-semibold",
        d === "bullish" && "bg-emerald-500/15 text-ms-green border border-emerald-500/30",
        d === "bearish" && "bg-rose-500/15 text-ms-red border border-rose-500/30",
        d === "neutral" && "bg-white/10 text-ms-muted border border-white/15",
      )}
    >
      {directionLabel(d)}
    </span>
  );
}

function VolChip({ v }: { v: VolumeTrend }) {
  const label = v === "up" ? "Vol ↑" : v === "down" ? "Vol ↓" : "Vol =";
  const color =
    v === "up" ? "text-ms-green" : v === "down" ? "text-ms-red" : "text-ms-muted";
  return <span className={cn("text-[10px] font-semibold", color)}>{label}</span>;
}

export function MatchesScreen() {
  const { goBack, navigate, matches, setSelectedMatch, period, settings, selectedAsset } = useApp();
  const [filterDir, setFilterDir] = useState<Direction | "all">("all");
  const pageSize = 5;
  const [page, setPage] = useState(0);

  const filteredMatches = useMemo(() => {
    return matches.filter((m) => filterDir === "all" || m.direction === filterDir);
  }, [matches, filterDir]);

  const visible = filteredMatches.slice(0, settings.resultCount);
  const pages = Math.max(1, Math.ceil(visible.length / pageSize));
  const slice = visible.slice(page * pageSize, page * pageSize + pageSize);

  return (
    <Screen>
      <Header
        title="Correspondances historiques"
        subtitle={`${selectedAsset.pairLabel} · ${matches.length} motifs trouvés`}
        onBack={goBack}
      />

      {/* Filter and Period Bar */}
      <div className="px-4 pb-2">
        <div className="flex items-center justify-between pb-2 text-[12px] text-ms-muted">
          <span>{visible.length} résultats classés par similarité</span>
          <button
            type="button"
            onClick={() => navigate("period")}
            className="flex items-center gap-1 rounded-lg bg-ms-card px-2 py-1 text-[11px] text-ms-teal hover:bg-ms-card-2"
            aria-label="Filtrer la période"
          >
            <IconFilter size={13} />
            <span>{period.candleCount} b.</span>
          </button>
        </div>

        {/* Direction Filter Chips */}
        <div className="flex gap-1.5">
          {(["all", "bullish", "bearish"] as const).map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => {
                setFilterDir(d);
                setPage(0);
              }}
              className={cn(
                "rounded-full px-3 py-1 text-[11px] font-semibold transition active:scale-95",
                filterDir === d
                  ? "bg-ms-teal text-[#06201c]"
                  : "bg-ms-card text-ms-muted hover:text-white",
              )}
            >
              {d === "all" ? "Tous" : d === "bullish" ? "Haussier (Bull)" : "Baissier (Bear)"}
            </button>
          ))}
        </div>
      </div>

      <Scroll className="pt-1">
        <div className="flex flex-col gap-2.5">
          {slice.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => {
                setSelectedMatch(m);
                navigate("matchDetail");
              }}
              className="flex items-center gap-3 rounded-2xl border border-white/5 bg-ms-card px-3.5 py-3 text-left transition hover:border-ms-teal/30 hover:bg-ms-card-2 active:scale-[0.99]"
            >
              <div className="flex flex-col items-center justify-center w-8 text-center">
                <span className="text-[11px] font-bold text-ms-muted">#{m.rank}</span>
                <span className="text-[9px] uppercase text-ms-muted-2">Rang</span>
              </div>

              <div className="rounded-lg bg-black/30 p-1">
                <MiniSpark candles={m.candlesData.slice(-16)} />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between">
                  <div className={cn("text-[17px] font-bold tabular-nums", cnScoreColor(m.score))}>
                    {formatScore(m.score)}
                    <span className="text-[11px] font-normal text-ms-muted"> /10</span>
                  </div>
                  <span className="text-[11px] font-medium text-ms-muted">{m.date}</span>
                </div>

                <div className="mt-1 flex items-center gap-2">
                  <DirChip d={m.direction} />
                  <VolChip v={m.volumeTrend} />
                  <span className="text-[10px] text-ms-muted-2">{m.candles} bougies</span>
                </div>
              </div>

              <IconChevronRight size={18} className="text-ms-muted-2" />
            </button>
          ))}
        </div>
      </Scroll>

      {/* Pagination Footer */}
      <div className="flex items-center justify-between border-t border-white/5 bg-ms-card/40 px-6 py-2.5 text-[13px] font-semibold text-ms-muted">
        <button
          type="button"
          disabled={page === 0}
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className={cn("transition", page === 0 ? "opacity-30 cursor-not-allowed" : "text-white hover:text-ms-teal")}
        >
          ‹ Précédent
        </button>
        <span className="text-[11px] tabular-nums text-ms-muted">
          Page {page + 1} sur {pages}
        </span>
        <button
          type="button"
          disabled={page >= pages - 1}
          onClick={() => setPage((p) => Math.min(pages - 1, p + 1))}
          className={cn(
            "transition",
            page >= pages - 1 ? "opacity-30 cursor-not-allowed" : "text-white hover:text-ms-teal",
          )}
        >
          Suivant ›
        </button>
      </div>
    </Screen>
  );
}
