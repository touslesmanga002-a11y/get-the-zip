import { IconCalendar } from "../components/Icons";
import {
  BottomBar,
  Header,
  PrimaryButton,
  RadioRow,
  Screen,
  Scroll,
  StatusBar,
  Stepper,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import type { PeriodConfig } from "../types";

export function PeriodScreen() {
  const { goBack, period, setPeriod, showToast } = useApp();

  const setKind = (kind: PeriodConfig["kind"]) =>
    setPeriod((p) => ({ ...p, kind }));

  return (
    <Screen>
      <StatusBar />
      <Header title="Période de recherche" onBack={goBack} />
      <Scroll className="space-y-2.5">
        <RadioRow
          checked={period.kind === "lastCandles"}
          onChange={() => setKind("lastCandles")}
          trailing={
            <span className="text-ms-muted">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 9l6 6 6-6" />
              </svg>
            </span>
          }
        >
          {period.candleCount} dernières bougies
        </RadioRow>

        <div className="flex items-center justify-between rounded-2xl bg-ms-card px-4 py-3">
          <span className="text-[14px] font-medium">Nombre de bougies</span>
          <Stepper
            value={period.candleCount}
            onChange={(n) => setPeriod((p) => ({ ...p, candleCount: n }))}
            min={50}
            max={5000}
            step={50}
          />
        </div>

        <RadioRow
          checked={period.kind === "custom"}
          onChange={() => setKind("custom")}
        >
          Période personnalisée
        </RadioRow>
        <div className="grid grid-cols-2 gap-2">
          <DateField
            label="Début"
            value={period.start}
            onChange={(v) => setPeriod((p) => ({ ...p, start: v }))}
          />
          <DateField
            label="Fin"
            value={period.end}
            onChange={(v) => setPeriod((p) => ({ ...p, end: v }))}
          />
        </div>

        <RadioRow checked={period.kind === "since"} onChange={() => setKind("since")}>
          Depuis une date
        </RadioRow>
        <DateField
          label=""
          value={period.since}
          onChange={(v) => setPeriod((p) => ({ ...p, since: v }))}
        />

        <RadioRow checked={period.kind === "all"} onChange={() => setKind("all")}>
          Tout l'historique
        </RadioRow>
        <RadioRow checked={period.kind === "chart"} onChange={() => setKind("chart")}>
          Période sur le graphique
        </RadioRow>
      </Scroll>
      <BottomBar>
        <PrimaryButton
          onClick={() => {
            showToast("Période appliquée (démo)");
            goBack();
          }}
        >
          Appliquer
        </PrimaryButton>
      </BottomBar>
    </Screen>
  );
}

function DateField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="flex items-center gap-2 rounded-2xl bg-ms-card px-3 py-3">
      {label && <span className="text-[12px] text-ms-muted">{label}</span>}
      <input
        type="date"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="min-w-0 flex-1 bg-transparent text-[13px] text-white outline-none"
      />
      <IconCalendar size={16} className="text-ms-muted" />
    </label>
  );
}
