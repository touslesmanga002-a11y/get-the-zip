import { useMemo } from "react";
import { CandlestickChart } from "../components/CandlestickChart";
import {
  BottomBar,
  GhostButton,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  Segmented,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { formatPrice } from "../utils/format";

export function PatternScreen() {
  const {
    goBack,
    navigate,
    candles,
    patternRange,
    setPatternRange,
    selectionMode,
    setSelectionMode,
    selectedAsset,
    timeframe,
  } = useApp();

  const reset = () => {
    setPatternRange({
      startIndex: Math.max(0, candles.length - 26),
      endIndex: candles.length - 2,
    });
    setSelectionMode("auto");
  };

  const count = patternRange.endIndex - patternRange.startIndex + 1;

  // Selected zone stats
  const zoneStats = useMemo(() => {
    const sub = candles.slice(patternRange.startIndex, patternRange.endIndex + 1);
    if (!sub.length) return { min: 0, max: 0, change: 0 };
    let min = Infinity;
    let max = -Infinity;
    for (const c of sub) {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
    }
    const open = sub[0].open;
    const close = sub[sub.length - 1].close;
    const change = open ? ((close - open) / open) * 100 : 0;
    return { min, max, change };
  }, [candles, patternRange]);

  // Tactile shift & resize actions
  const shiftLeft = () => {
    const len = patternRange.endIndex - patternRange.startIndex;
    const newStart = Math.max(0, patternRange.startIndex - 2);
    setPatternRange({ startIndex: newStart, endIndex: newStart + len });
    setSelectionMode("manual");
  };

  const shiftRight = () => {
    const len = patternRange.endIndex - patternRange.startIndex;
    const newEnd = Math.min(candles.length - 1, patternRange.endIndex + 2);
    setPatternRange({ startIndex: newEnd - len, endIndex: newEnd });
    setSelectionMode("manual");
  };

  const shrink = () => {
    const len = patternRange.endIndex - patternRange.startIndex;
    if (len <= 4) return;
    setPatternRange({
      startIndex: patternRange.startIndex + 1,
      endIndex: patternRange.endIndex - 1,
    });
    setSelectionMode("manual");
  };

  const expand = () => {
    const newStart = Math.max(0, patternRange.startIndex - 1);
    const newEnd = Math.min(candles.length - 1, patternRange.endIndex + 1);
    setPatternRange({ startIndex: newStart, endIndex: newEnd });
    setSelectionMode("manual");
  };

  const applyPreset = (targetCount: number) => {
    const endIndex = candles.length - 2;
    const startIndex = Math.max(0, endIndex - targetCount + 1);
    setPatternRange({ startIndex, endIndex });
    setSelectionMode("manual");
  };

  return (
    <Screen>
      <Header
        title="Zone d'analyse du pattern"
        subtitle={`${selectedAsset.pairLabel} · Unité ${timeframe}`}
        onBack={goBack}
      />

      {/* Mode toggle */}
      <div className="px-4 pb-2">
        <Segmented
          value={selectionMode}
          onChange={(id) => setSelectionMode(id as "auto" | "manual")}
          options={[
            { id: "auto", label: "Auto (Détection IA)" },
            { id: "manual", label: "Manuel (Sur mesure)" },
          ]}
        />
      </div>

      <Scroll className="pt-0">
        {/* Interactive Candlestick Chart */}
        <div className="rounded-2xl border border-white/5 bg-ms-card/80 p-2 shadow-inner">
          <CandlestickChart
            candles={candles}
            height={240}
            showVolume={false}
            selection={patternRange}
            onSelectionChange={(r) => {
              setPatternRange(r);
              setSelectionMode("manual");
            }}
            interactive
            highlightLast={count + 4}
          />
        </div>

        {/* Selected Zone Metrics Badge Card */}
        <div className="mt-3 rounded-2xl border border-emerald-500/20 bg-emerald-500/5 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[13px] font-bold text-white">
                Zone sélectionnée : {count} bougies
              </span>
            </div>
            <span
              className={`text-[12px] font-bold ${
                zoneStats.change >= 0 ? "text-ms-green" : "text-ms-red"
              }`}
            >
              {zoneStats.change >= 0 ? "+" : ""}
              {zoneStats.change.toFixed(2)}%
            </span>
          </div>

          <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] text-ms-muted">
            <div>
              Bas :{" "}
              <span className="font-semibold text-white">
                {formatPrice(zoneStats.min, selectedAsset.decimals, " $")}
              </span>
            </div>
            <div className="text-right">
              Haut :{" "}
              <span className="font-semibold text-white">
                {formatPrice(zoneStats.max, selectedAsset.decimals, " $")}
              </span>
            </div>
          </div>
        </div>

        {/* Tactile Fine-Tuning Controls */}
        <div className="mt-3 space-y-2">
          <div className="text-[12px] font-semibold text-ms-muted px-1 flex items-center justify-between">
            <span>Ajustement rapide de la zone</span>
            <span className="text-[10px] text-teal-400">Glissez aussi les poignées sur le graphique</span>
          </div>

          {/* Stepper Buttons */}
          <div className="grid grid-cols-4 gap-1.5">
            <button
              type="button"
              onClick={shiftLeft}
              className="flex items-center justify-center gap-1 rounded-xl bg-ms-card py-2 text-[12px] font-semibold text-white transition hover:bg-ms-card-2 active:scale-95"
              title="Déplacer vers la gauche"
            >
              <span>◄</span> Déplacer
            </button>
            <button
              type="button"
              onClick={shiftRight}
              className="flex items-center justify-center gap-1 rounded-xl bg-ms-card py-2 text-[12px] font-semibold text-white transition hover:bg-ms-card-2 active:scale-95"
              title="Déplacer vers la droite"
            >
              Déplacer <span>►</span>
            </button>
            <button
              type="button"
              onClick={shrink}
              disabled={count <= 4}
              className="flex items-center justify-center gap-1 rounded-xl bg-ms-card py-2 text-[12px] font-semibold text-white transition hover:bg-ms-card-2 active:scale-95 disabled:opacity-40"
              title="Réduire la largeur"
            >
              <span>−</span> Réduire
            </button>
            <button
              type="button"
              onClick={expand}
              className="flex items-center justify-center gap-1 rounded-xl bg-ms-card py-2 text-[12px] font-semibold text-white transition hover:bg-ms-card-2 active:scale-95"
              title="Élargir la largeur"
            >
              <span>+</span> Élargir
            </button>
          </div>

          {/* Quick Preset Chips */}
          <div className="flex gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => applyPreset(15)}
              className={`flex-1 rounded-xl py-1.5 text-[11px] font-semibold transition ${
                count === 15 ? "bg-ms-teal text-[#06201c]" : "bg-ms-elev text-ms-muted hover:text-white"
              }`}
            >
              15 bougies
            </button>
            <button
              type="button"
              onClick={() => applyPreset(25)}
              className={`flex-1 rounded-xl py-1.5 text-[11px] font-semibold transition ${
                count === 25 ? "bg-ms-teal text-[#06201c]" : "bg-ms-elev text-ms-muted hover:text-white"
              }`}
            >
              25 bougies
            </button>
            <button
              type="button"
              onClick={() => applyPreset(40)}
              className={`flex-1 rounded-xl py-1.5 text-[11px] font-semibold transition ${
                count === 40 ? "bg-ms-teal text-[#06201c]" : "bg-ms-elev text-ms-muted hover:text-white"
              }`}
            >
              40 bougies
            </button>
          </div>
        </div>

        <p className="mt-4 px-2 text-center text-[12px] leading-relaxed text-ms-muted">
          {selectionMode === "auto"
            ? "Mode IA actif : la zone cible automatiquement le dernier cycle de compression/consolidation."
            : "Mode manuel actif : vous pouvez déplacer la zone et ajuster sa largeur au doigt ou via les touches ci-dessus."}
        </p>
      </Scroll>

      <BottomBar>
        <div className="flex gap-3">
          <GhostButton className="flex-1" onClick={reset}>
            Réinitialiser
          </GhostButton>
          <PrimaryButton className="flex-1" onClick={() => navigate("sync")}>
            Lancer le scan →
          </PrimaryButton>
        </div>
      </BottomBar>
    </Screen>
  );
}
