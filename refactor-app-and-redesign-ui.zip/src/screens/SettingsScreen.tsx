import { IconChevronRight } from "../components/Icons";
import {
  Header,
  Screen,
  Scroll,
  StatusBar,
  Stepper,
  Toggle,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import type { Timeframe } from "../types";
import { TIMEFRAME_LABELS } from "../types";

const TFS: Timeframe[] = ["1m", "15m", "1h", "1j", "1s", "1M"];

export function SettingsScreen() {
  const { goBack, navigate, settings, setSettings } = useApp();

  return (
    <Screen>
      <StatusBar />
      <Header title="Paramètres" onBack={goBack} />
      <Scroll>
        <h3 className="mb-2 px-1 text-[13px] font-semibold text-ms-muted">
          Source de données
        </h3>
        <div className="overflow-hidden rounded-2xl bg-ms-card">
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[14px]">Mode</span>
            <select
              value={settings.mode}
              onChange={(e) =>
                setSettings((s) => ({ ...s, mode: e.target.value as "auto" | "manual" }))
              }
              className="rounded-lg bg-ms-elev px-3 py-1.5 text-[13px] text-white outline-none"
            >
              <option value="auto">Auto</option>
              <option value="manual">Manuel</option>
            </select>
          </div>
          <RowToggle
            label="Cloudflare (si disponible)"
            checked={settings.cloudflare}
            onChange={(v) => setSettings((s) => ({ ...s, cloudflare: v }))}
          />
          <RowToggle
            label="Fournisseurs directs"
            checked={settings.directProviders}
            onChange={(v) => setSettings((s) => ({ ...s, directProviders: v }))}
          />
          <RowToggle
            label="Dossier local"
            checked={settings.localFolder}
            onChange={(v) => setSettings((s) => ({ ...s, localFolder: v }))}
          />
        </div>

        <div className="mt-3 overflow-hidden rounded-2xl bg-ms-card">
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[14px]">Granularité</span>
            <select
              value={settings.granularity}
              onChange={(e) =>
                setSettings((s) => ({ ...s, granularity: e.target.value as Timeframe }))
              }
              className="rounded-lg bg-ms-elev px-3 py-1.5 text-[13px] text-white outline-none"
            >
              {TFS.map((t) => (
                <option key={t} value={t}>
                  {TIMEFRAME_LABELS[t]}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[14px]">Nombre de résultats</span>
            <Stepper
              value={settings.resultCount}
              onChange={(n) => setSettings((s) => ({ ...s, resultCount: n }))}
              min={5}
              max={100}
              step={5}
            />
          </div>
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[14px]">Limite de recherche</span>
            <div className="flex items-center gap-2">
              <Stepper
                value={settings.searchLimit}
                onChange={(n) => setSettings((s) => ({ ...s, searchLimit: n }))}
                min={100}
                max={5000}
                step={50}
              />
              <span className="text-[11px] text-ms-muted">bougies</span>
            </div>
          </div>
        </div>

        <div className="mt-3 overflow-hidden rounded-2xl bg-ms-card">
          <LinkRow label="Fournisseurs" onClick={() => navigate("dataSources")} />
          <LinkRow label="Cache" onClick={() => navigate("cache")} />
          <LinkRow label="Avancé" onClick={() => navigate("advanced")} last />
        </div>
      </Scroll>
    </Screen>
  );
}

function RowToggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between border-t border-white/5 px-4 py-3.5">
      <span className="flex items-center gap-2 text-[14px]">
        <span
          className={`h-3.5 w-3.5 rounded-full border ${checked ? "border-ms-teal bg-ms-teal/30" : "border-ms-muted-2"}`}
        />
        {label}
      </span>
      <Toggle checked={checked} onChange={onChange} />
    </div>
  );
}

function LinkRow({
  label,
  onClick,
  last,
}: {
  label: string;
  onClick: () => void;
  last?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center justify-between px-4 py-3.5 text-left ${last ? "" : "border-b border-white/5"}`}
    >
      <span className="text-[14px]">{label}</span>
      <IconChevronRight size={18} className="text-ms-muted" />
    </button>
  );
}
