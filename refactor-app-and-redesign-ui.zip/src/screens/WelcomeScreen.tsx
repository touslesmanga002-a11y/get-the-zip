import { BitcoinBadge, LogoMark } from "../components/Icons";
import { BottomBar, PrimaryButton, Screen } from "../components/ui";
import { useApp } from "../context/AppContext";
import type { AssetCategory } from "../types";

function MountainSky() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* Background Mountain Photo */}
      <img
        src="/images/mountains.jpg"
        alt="Montagnes MarketScope"
        className="absolute inset-0 h-full w-full object-cover object-top opacity-55 mix-blend-screen scale-105"
      />

      {/* Atmospheric overlays for fintech sleekness */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(16,40,65,0.75)_0%,#071422_60%,#050d18_100%)]" />

      {/* Subtle Starry Sparks */}
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 390 844"
        preserveAspectRatio="xMidYMin slice"
      >
        {Array.from({ length: 32 }).map((_, i) => (
          <circle
            key={i}
            cx={(i * 107) % 390}
            cy={15 + ((i * 47) % 200)}
            r={i % 6 === 0 ? 1.4 : 0.8}
            fill="#ffffff"
            opacity={0.25 + (i % 5) * 0.12}
          />
        ))}

        {/* Elegant Mountain Ridges Silhouette for depth */}
        <path
          d="M0 320 L75 240 L125 275 L180 190 L225 245 L285 160 L335 235 L390 195 L390 844 L0 844 Z"
          fill="#0a1d33"
          opacity="0.85"
        />
        <path
          d="M0 375 L55 315 L105 350 L155 270 L205 335 L265 240 L325 315 L365 270 L390 300 L390 844 L0 844 Z"
          fill="#071422"
          opacity="0.95"
        />
      </svg>

      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#071422]/60 to-[#071422]" />
    </div>
  );
}

const CATEGORIES: {
  id: AssetCategory;
  title: string;
  subtitle: string;
  icon: "btc" | "forex" | "stock" | "commodity";
}[] = [
  { id: "crypto", title: "Cryptomonnaies", subtitle: "BTC, ETH, SOL, etc.", icon: "btc" },
  { id: "forex", title: "Forex", subtitle: "EUR/USD, GBP/USD, etc.", icon: "forex" },
  { id: "stock", title: "Actions", subtitle: "AAPL, MSFT, TSLA, etc.", icon: "stock" },
  { id: "commodity", title: "Matières premières", subtitle: "Or, Pétrole WTI, etc.", icon: "commodity" },
];

function CatIcon({ kind }: { kind: (typeof CATEGORIES)[number]["icon"] }) {
  if (kind === "btc") return <BitcoinBadge />;
  if (kind === "forex")
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#0d9488] to-[#115e59] shadow-sm shadow-teal-500/20">
        <span className="text-lg font-bold text-white">€/$</span>
      </div>
    );
  if (kind === "stock")
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#6366f1] to-[#4338ca] shadow-sm shadow-indigo-500/20">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2">
          <path d="M4 16l5-6 4 3 7-8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
    );
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#f59e0b] to-[#b45309] shadow-sm shadow-amber-500/20">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
        <ellipse cx="12" cy="8" rx="7" ry="3" />
        <path d="M5 8v8c0 1.7 3.1 3 7 3s7-1.3 7-3V8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

export function WelcomeScreen() {
  const { navigate, setCategoryFilter } = useApp();

  const open = (cat: AssetCategory | "all") => {
    setCategoryFilter(cat);
    // Navigation vers l'application : l'écran de démarrage ne sera plus accessible via retour
    navigate("assets");
  };

  return (
    <Screen className="relative overflow-hidden">
      <MountainSky />
      <div className="relative flex min-h-0 flex-1 flex-col">
        <div className="flex flex-1 flex-col px-5 pt-8">
          <div className="ms-fade flex flex-col items-center pt-2 text-center">
            {/* Logo MarketScope corrigé avec flèche ascendante connectée */}
            <div className="mb-3.5 flex items-center justify-center rounded-2xl shadow-xl shadow-teal-500/10 ring-1 ring-white/15">
              <LogoMark size={58} />
            </div>

            <div className="inline-flex items-center gap-1.5 rounded-full border border-teal-500/30 bg-teal-500/10 px-3 py-1 text-[11px] font-semibold text-teal-300">
              <span className="h-1.5 w-1.5 rounded-full bg-teal-400 animate-pulse" />
              Moteur d'Analyse Prédictive V2
            </div>

            <h1 className="mt-3 text-[32px] font-extrabold tracking-tight text-white leading-tight">
              Market<span className="text-ms-teal">Scope</span>
            </h1>
            <p className="mt-2 max-w-[280px] text-[14px] leading-snug text-ms-muted">
              Détectez les patterns de marché et anticipez les mouvements avec précision.
            </p>
          </div>

          <div className="mt-7 flex flex-col gap-2.5">
            <p className="px-1 text-[12px] font-semibold tracking-wider uppercase text-ms-muted">
              Choisissez un marché à scanner
            </p>
            {CATEGORIES.map((c, i) => (
              <button
                key={c.id}
                type="button"
                onClick={() => open(c.id)}
                className={`ms-fade ms-delay-${i + 1} flex items-center gap-3 rounded-2xl border border-white/5 bg-[#0e243a]/90 px-3.5 py-3 text-left shadow-sm backdrop-blur-md transition hover:border-ms-teal/30 hover:bg-[#132f4c] active:scale-[0.99]`}
              >
                <CatIcon kind={c.icon} />
                <div className="flex-1 min-w-0">
                  <div className="text-[15px] font-semibold text-white">{c.title}</div>
                  <div className="text-[12px] text-ms-muted">{c.subtitle}</div>
                </div>
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-white/5 text-ms-muted">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                    <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </button>
            ))}
          </div>
        </div>

        <BottomBar>
          <PrimaryButton tone="blue" onClick={() => open("all")} className="font-bold">
            Explorer tous les marchés →
          </PrimaryButton>
        </BottomBar>
      </div>
    </Screen>
  );
}
