import { useEffect, useState } from "react";
import { EquityChart } from "../components/CandlestickChart";
import {
  BottomBar,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  StatusBar,
} from "../components/ui";
import { MOCK_BACKTEST } from "../data/mock";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { BacktestStats } from "../types";

export function BacktestScreen() {
  const { goBack, navigate, selectedAsset, settings } = useApp();
  const [stats, setStats] = useState<BacktestStats>(MOCK_BACKTEST);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    marketApi
      .runBacktest({ assetId: selectedAsset.id, settings })
      .then(setStats)
      .finally(() => setLoading(false));
  }, [selectedAsset.id, settings]);

  return (
    <Screen>
      <StatusBar />
      <Header title="Résultats du backtest" onBack={goBack} />
      <Scroll>
        {loading && (
          <p className="mb-3 text-center text-[12px] text-ms-muted">Calcul en cours (démo)…</p>
        )}
        <div className="grid grid-cols-2 gap-2.5">
          <Stat label="Nombre de cas" value={String(stats.cases)} />
          <Stat label="Direction correcte" value={`${stats.correctDirection}%`} />
          <Stat
            label="Erreur moyenne"
            value={`${stats.meanError.toLocaleString("fr-FR")}%`}
          />
          <Stat
            label="Calibration prob."
            value={stats.calibration.toLocaleString("fr-FR")}
          />
        </div>

        <h3 className="mt-6 text-[14px] font-semibold">Par similarité</h3>
        <div className="mt-2 overflow-hidden rounded-2xl bg-ms-card">
          {stats.bySimilarity.map((row, i) => (
            <div
              key={row.range}
              className={`flex items-center px-4 py-2.5 text-[13px] ${i > 0 ? "border-t border-white/5" : ""}`}
            >
              <span className="w-16 font-semibold text-ms-muted">{row.range}</span>
              <span className="flex-1 font-semibold text-ms-teal">{row.accuracy}%</span>
              <span className="text-ms-muted">
                {row.error.toLocaleString("fr-FR")} %
              </span>
            </div>
          ))}
        </div>

        <h3 className="mt-6 text-[14px] font-semibold">Courbe de performance</h3>
        <div className="mt-2 rounded-2xl bg-ms-card p-2">
          <EquityChart values={stats.equityCurve} />
        </div>
        <p className="mt-2 text-center text-[10px] text-ms-muted-2">
          Backtest fictif — ne constitue pas un historique réel
        </p>
      </Scroll>
      <BottomBar>
        <PrimaryButton onClick={() => navigate("export")}>Exporter</PrimaryButton>
      </BottomBar>
    </Screen>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-ms-card px-4 py-3">
      <div className="text-[11px] text-ms-muted">{label}</div>
      <div className="mt-1 text-[26px] font-bold tabular-nums tracking-tight text-ms-teal">
        {value}
      </div>
    </div>
  );
}
