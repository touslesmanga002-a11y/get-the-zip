import { useEffect, useState } from "react";
import { IconGear, ProviderIcon } from "../components/Icons";
import {
  BottomBar,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  StatusBar,
} from "../components/ui";
import { MOCK_PROVIDERS } from "../data/mock";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { DataProvider } from "../types";
import { cn } from "../utils/cn";

export function DataSourcesScreen() {
  const { goBack, showToast } = useApp();
  const [providers, setProviders] = useState<DataProvider[]>(MOCK_PROVIDERS);

  useEffect(() => {
    marketApi.getProviders().then(setProviders);
  }, []);

  const primary = providers.find((p) => p.primary);
  const backups = providers.filter((p) => !p.primary);

  const toggle = (id: string) => {
    setProviders((list) =>
      list.map((p) => (p.id === id ? { ...p, connected: !p.connected } : p)),
    );
  };

  return (
    <Screen>
      <StatusBar />
      <Header title="Source de données (Backup)" onBack={goBack} />
      <Scroll>
        {primary && (
          <>
            <h3 className="mb-2 px-1 text-[13px] font-semibold text-ms-muted">
              Fournisseur principal
            </h3>
            <ProviderCard p={primary} onGear={() => toggle(primary.id)} />
          </>
        )}
        <h3 className="mt-5 mb-2 px-1 text-[13px] font-semibold text-ms-muted">
          Sources de secours
        </h3>
        <div className="space-y-2.5">
          {backups.map((p) => (
            <ProviderCard key={p.id} p={p} onGear={() => toggle(p.id)} />
          ))}
        </div>
      </Scroll>
      <BottomBar>
        <PrimaryButton
          onClick={() => showToast("Ajout de source — disponible avec le backend")}
        >
          Ajouter une nouvelle source de données
        </PrimaryButton>
      </BottomBar>
    </Screen>
  );
}

function ProviderCard({ p, onGear }: { p: DataProvider; onGear: () => void }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-ms-card px-3 py-3">
      <ProviderIcon icon={p.icon} color={p.color} />
      <div className="min-w-0 flex-1">
        <div className="text-[14px] font-semibold">{p.name}</div>
        <div className="text-[11px] text-ms-muted">{p.subtitle}</div>
        <div
          className={cn(
            "mt-0.5 flex items-center gap-1.5 text-[11px] font-medium",
            p.connected ? "text-ms-green" : "text-ms-muted",
          )}
        >
          <span
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              p.connected ? "bg-ms-green" : "bg-ms-muted",
            )}
          />
          {p.connected ? "Connecté" : "Déconnecté"}
        </div>
      </div>
      <button
        type="button"
        onClick={onGear}
        className="flex h-9 w-9 items-center justify-center rounded-full text-ms-muted active:bg-white/5"
        aria-label={`Configurer ${p.name}`}
      >
        <IconGear size={18} />
      </button>
    </div>
  );
}

export function CacheScreen() {
  const { goBack, navigate, showToast } = useApp();
  return (
    <Screen>
      <StatusBar />
      <Header title="Cache" onBack={goBack} />
      <Scroll>
        <div className="rounded-2xl bg-ms-card p-4">
          <p className="text-[14px] leading-relaxed text-white/85">
            Le cache local accélère les recherches de correspondances. En mode
            présentation, 1 200 points fictifs sont indexés.
          </p>
          <dl className="mt-4 space-y-2 text-[13px]">
            <div className="flex justify-between">
              <dt className="text-ms-muted">Taille estimée</dt>
              <dd className="font-semibold">4,2 Mo</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ms-muted">Séries</dt>
              <dd className="font-semibold">9 actifs</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ms-muted">Dernière sync</dt>
              <dd className="font-semibold">À l'instant</dd>
            </div>
          </dl>
        </div>
        <button
          type="button"
          onClick={() => navigate("sync")}
          className="mt-3 h-12 w-full rounded-full bg-ms-teal text-[14px] font-semibold text-[#06201c]"
        >
          Relancer la synchronisation
        </button>
        <button
          type="button"
          onClick={() => showToast("Cache vidé (démo)")}
          className="mt-2 h-12 w-full rounded-full border border-ms-border-2 text-[14px] font-semibold"
        >
          Vider le cache
        </button>
      </Scroll>
    </Screen>
  );
}

export function AdvancedScreen() {
  const { goBack } = useApp();
  return (
    <Screen>
      <StatusBar />
      <Header title="Avancé" onBack={goBack} />
      <Scroll>
        <div className="rounded-2xl bg-ms-card p-4 text-[13px] leading-relaxed text-ms-muted">
          Options destinées au futur backend. Elles n'ont pas d'effet réseau
          dans cette version de présentation.
        </div>
        <div className="mt-3 overflow-hidden rounded-2xl bg-ms-card">
          <label className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[14px]">Logs de diagnostic</span>
            <input type="checkbox" defaultChecked className="accent-ms-teal" />
          </label>
          <label className="flex items-center justify-between border-t border-white/5 px-4 py-3.5">
            <span className="text-[14px]">Normaliser les volumes</span>
            <input type="checkbox" defaultChecked className="accent-ms-teal" />
          </label>
          <label className="flex items-center justify-between border-t border-white/5 px-4 py-3.5">
            <span className="text-[14px]">Fenêtre de similarité</span>
            <select
              className="rounded-lg bg-ms-elev px-2 py-1 text-[13px] outline-none"
              defaultValue="25"
            >
              <option value="15">15 bougies</option>
              <option value="25">25 bougies</option>
              <option value="40">40 bougies</option>
            </select>
          </label>
          <label className="flex items-center justify-between border-t border-white/5 px-4 py-3.5">
            <span className="text-[14px]">Seuil de score min.</span>
            <select
              className="rounded-lg bg-ms-elev px-2 py-1 text-[13px] outline-none"
              defaultValue="7"
            >
              <option value="6">6,0</option>
              <option value="7">7,0</option>
              <option value="8">8,0</option>
            </select>
          </label>
        </div>
      </Scroll>
    </Screen>
  );
}
