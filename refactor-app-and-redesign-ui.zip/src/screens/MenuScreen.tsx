import {
  IconAnalyze,
  IconBacktest,
  IconBars,
  IconChevronRight,
  IconClock,
  IconExport,
  IconGear,
  IconHome,
  IconLineChart,
  LogoMark,
} from "../components/Icons";
import { Screen, Scroll, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import type { ScreenId } from "../types";
import type { ReactNode } from "react";

const ITEMS: { id: ScreenId; label: string; icon: ReactNode }[] = [
  { id: "assets", label: "Accueil", icon: <IconHome size={20} /> },
  { id: "chart", label: "Analyser", icon: <IconAnalyze size={20} /> },
  { id: "matches", label: "Historique", icon: <IconClock size={20} /> },
  { id: "scenarios", label: "Scénarios", icon: <IconLineChart size={20} /> },
  { id: "conditions", label: "Alertes", icon: <IconBars size={20} /> },
  { id: "backtest", label: "Backtest", icon: <IconBacktest size={20} /> },
];

const FOOT: { id: ScreenId; label: string; icon: ReactNode }[] = [
  { id: "settings", label: "Paramètres", icon: <IconGear size={20} /> },
  { id: "export", label: "Exporter les résultats", icon: <IconExport size={20} /> },
];

export function MenuScreen() {
  const { navigate, resetTo, goBack } = useApp();

  return (
    <Screen>
      <StatusBar />
      <div className="flex items-center gap-2 px-5 py-3">
        <LogoMark size={32} />
        <h1 className="text-[18px] font-semibold">MarketScope</h1>
      </div>
      <Scroll>
        <div className="overflow-hidden rounded-2xl bg-ms-card">
          {ITEMS.map((it, i) => (
            <button
              key={`${it.label}-${i}`}
              type="button"
              onClick={() => navigate(it.id)}
              className={`flex w-full items-center gap-3 px-4 py-3.5 text-left ${i < ITEMS.length - 1 ? "border-b border-white/5" : ""}`}
            >
              <span className="text-ms-muted">{it.icon}</span>
              <span className="flex-1 text-[14px]">{it.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-3 overflow-hidden rounded-2xl bg-ms-card">
          {FOOT.map((it, i) => (
            <button
              key={it.label}
              type="button"
              onClick={() => navigate(it.id)}
              className={`flex w-full items-center gap-3 px-4 py-3.5 text-left ${i === 0 ? "border-b border-white/5" : ""}`}
            >
              <span className="text-ms-muted">{it.icon}</span>
              <span className="flex-1 text-[14px]">{it.label}</span>
              <IconChevronRight size={18} className="text-ms-muted" />
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => navigate("help")}
          className="mt-3 flex w-full items-center justify-between rounded-2xl bg-ms-card px-4 py-3.5 text-[14px]"
        >
          Aide
          <IconChevronRight size={18} className="text-ms-muted" />
        </button>
      </Scroll>
      <div className="px-4 pb-[max(20px,env(safe-area-inset-bottom))] pt-2 text-center">
        <button
          type="button"
          onClick={() => resetTo("welcome")}
          className="text-[14px] font-medium text-rose-400"
        >
          Se déconnecter
        </button>
        <button type="button" onClick={goBack} className="mt-3 block w-full text-[12px] text-ms-muted">
          Fermer le menu
        </button>
      </div>
    </Screen>
  );
}
