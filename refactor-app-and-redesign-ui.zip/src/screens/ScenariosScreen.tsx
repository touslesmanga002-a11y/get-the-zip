import { Header, Screen, Scroll, StatusBar } from "../components/ui";
import { MOCK_OUTCOME, MOCK_SCENARIOS } from "../data/mock";
import { useApp } from "../context/AppContext";
import { directionLabel } from "../utils/format";
import { cn } from "../utils/cn";
import type { Direction } from "../types";

function DirIcon({ d }: { d: Direction }) {
  const color =
    d === "bullish" ? "text-ms-green bg-ms-green/15" : d === "bearish" ? "text-ms-red bg-ms-red/15" : "text-ms-muted bg-white/10";
  return (
    <span className={cn("flex h-6 w-6 items-center justify-center rounded-full", color)}>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
        <path d="M5 12.5l4.2 4.2L19 7.5" />
      </svg>
    </span>
  );
}

export function ScenariosScreen() {
  const { goBack, navigate } = useApp();
  const outcome = MOCK_OUTCOME;
  const scenarios = MOCK_SCENARIOS;

  return (
    <Screen>
      <StatusBar />
      <Header title="Prolongements historiques" onBack={goBack} />
      <Scroll>
        <p className="text-[13px] text-ms-muted">Après cette correspondance :</p>
        <div className="mt-3 flex gap-3">
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-ms-card px-3 py-3">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <path d="M5 12.5l4.2 4.2L19 7.5" />
              </svg>
            </span>
            <span className="text-[22px] font-bold text-ms-green">{outcome.bullish}%</span>
            <span className="text-[13px] text-ms-muted">hausse</span>
          </div>
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-ms-card px-3 py-3">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ms-red/15 text-ms-red">
              <span className="text-xs">●</span>
            </span>
            <span className="text-[22px] font-bold text-ms-red">{outcome.bearish}%</span>
            <span className="text-[13px] text-ms-muted">baisse</span>
          </div>
        </div>

        <h3 className="mt-6 text-[15px] font-semibold">Scénarios probabilistes</h3>
        <div className="mt-3 space-y-2.5">
          {scenarios.map((s) => (
            <div key={s.id} className="rounded-2xl bg-ms-card px-4 py-3.5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[14px] font-semibold text-white">{s.horizon}</div>
                  <div className="text-[11px] text-ms-muted">({s.rangeLabel})</div>
                </div>
                <div className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <DirIcon d={s.direction} />
                    <span
                      className={cn(
                        "text-[13px] font-semibold",
                        s.direction === "bullish"
                          ? "text-ms-green"
                          : s.direction === "bearish"
                            ? "text-ms-red"
                            : "text-ms-muted",
                      )}
                    >
                      {directionLabel(s.direction)}
                    </span>
                    <span className="text-[16px] font-bold tabular-nums text-white">
                      {s.probability}%
                    </span>
                  </div>
                  <div className="mt-0.5 text-[11px] text-ms-muted">
                    ±{s.deviation.toLocaleString("fr-FR")} %
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Scroll>
      <div className="px-4 pb-[max(16px,env(safe-area-inset-bottom))] pt-2">
        <button
          type="button"
          onClick={() => navigate("conditions")}
          className="h-12 w-full rounded-full border border-ms-border-2 text-[14px] font-semibold text-white/90"
        >
          Voir les conditions de modification
        </button>
      </div>
    </Screen>
  );
}
