import { IconAlert, IconCheck } from "../components/Icons";
import { Header, Screen, Scroll, StatusBar } from "../components/ui";
import { MOCK_CONDITIONS } from "../data/mock";
import { useApp } from "../context/AppContext";
import { cn } from "../utils/cn";

export function ConditionsScreen() {
  const { goBack, showToast } = useApp();

  return (
    <Screen>
      <StatusBar />
      <Header title="Conditions et alertes" onBack={goBack} />
      <Scroll>
        {MOCK_CONDITIONS.map((g) => (
          <section key={g.id} className="mb-5">
            <h3
              className={cn(
                "mb-2.5 text-[15px] font-semibold",
                g.tone === "bullish" && "text-sky-300",
                g.tone === "bearish" && "text-rose-300",
                g.tone === "invalid" && "text-ms-muted",
              )}
            >
              {g.title}
            </h3>
            <div className="space-y-2">
              {g.items.map((it) => (
                <div
                  key={it.id}
                  className="flex items-start gap-3 rounded-2xl bg-ms-card px-3.5 py-3"
                >
                  <span
                    className={cn(
                      "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full",
                      g.tone === "bullish" && "bg-ms-green/15 text-ms-green",
                      g.tone === "bearish" && "bg-ms-red/15 text-ms-red",
                      g.tone === "invalid" && "bg-white/10 text-ms-muted",
                    )}
                  >
                    {g.tone === "bearish" ? <IconAlert size={14} /> : <IconCheck size={14} />}
                  </span>
                  <div className="flex-1 text-[13px] leading-snug text-white/90">
                    {it.label}
                    {it.value && (
                      <span className="ml-1 font-semibold text-white">{it.value}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </Scroll>
      <div className="px-4 pb-[max(16px,env(safe-area-inset-bottom))] pt-2">
        <button
          type="button"
          onClick={() =>
            showToast("Détails techniques — données de démonstration")
          }
          className="flex h-12 w-full items-center justify-center gap-2 rounded-full border border-ms-border-2 text-[14px] font-semibold text-white/90"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <rect x="4" y="4" width="16" height="16" rx="3" />
            <path d="M8 14l3-3 2 2 3-4" />
          </svg>
          Détails techniques
        </button>
      </div>
    </Screen>
  );
}
