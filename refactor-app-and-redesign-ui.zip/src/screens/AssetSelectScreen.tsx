import { useEffect, useMemo, useState } from "react";
import {
  AppleBadge,
  BitcoinBadge,
  EthBadge,
  FlagEU,
  FlagUK,
  GoldBadge,
  IconSearch,
  MsftBadge,
  OilBadge,
  SolBadge,
} from "../components/Icons";
import { Header, Screen, Scroll } from "../components/ui";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { Asset, AssetCategory } from "../types";
import { CATEGORY_LABELS } from "../types";
import { formatPct, formatPrice } from "../utils/format";
import { cn } from "../utils/cn";

const FILTERS: (AssetCategory | "all")[] = ["all", "crypto", "forex", "stock", "commodity"];

function AssetIcon({ asset }: { asset: Asset }) {
  switch (asset.symbol) {
    case "BTC":
      return <BitcoinBadge />;
    case "ETH":
      return <EthBadge />;
    case "SOL":
      return <SolBadge />;
    case "EURUSD":
      return <FlagEU />;
    case "GBPUSD":
      return <FlagUK />;
    case "AAPL":
      return <AppleBadge />;
    case "MSFT":
      return <MsftBadge />;
    case "XAUUSD":
      return <GoldBadge />;
    case "WTI":
      return <OilBadge />;
    default:
      return (
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-ms-elev text-xs font-bold">
          {asset.symbol.slice(0, 3)}
        </div>
      );
  }
}

export function AssetSelectScreen() {
  const {
    navigate,
    categoryFilter,
    setCategoryFilter,
    setSelectedAsset,
    setCandles,
    setTimeframe,
  } = useApp();
  const [q, setQ] = useState("");
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    marketApi.getAssets().then((list) => {
      setAssets(list);
      setLoading(false);
    });
  }, []);

  const filtered = useMemo(() => {
    return assets.filter((a) => {
      const catOk = categoryFilter === "all" || a.category === categoryFilter;
      const qq = q.trim().toLowerCase();
      const qOk =
        !qq ||
        a.symbol.toLowerCase().includes(qq) ||
        a.name.toLowerCase().includes(qq) ||
        a.pairLabel.toLowerCase().includes(qq);
      return catOk && qOk;
    });
  }, [assets, categoryFilter, q]);

  const openAsset = async (a: Asset) => {
    setSelectedAsset(a);
    setTimeframe("1h");
    const candles = await marketApi.getCandles(a.id, "1h");
    setCandles(candles);
    navigate("chart");
  };

  return (
    <Screen>
      <Header
        title="Sélectionner un actif"
        subtitle="Choisissez l'instrument à analyser"
      />
      <div className="px-4 pb-2">
        <div className="flex items-center gap-2 rounded-2xl bg-ms-card px-3.5 py-2.5 ring-1 ring-white/5">
          <IconSearch size={18} className="text-ms-muted" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher un symbole..."
            className="w-full bg-transparent text-[14px] text-white outline-none placeholder:text-ms-muted-2"
          />
        </div>
        <div className="ms-scroll mt-3 flex gap-2 overflow-x-auto pb-1">
          {FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setCategoryFilter(f)}
              className={cn(
                "shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-semibold",
                categoryFilter === f
                  ? "bg-ms-blue text-white"
                  : "bg-ms-card text-ms-muted",
              )}
            >
              {CATEGORY_LABELS[f]}
            </button>
          ))}
        </div>
      </div>
      <Scroll className="pt-1">
        {loading && (
          <p className="py-10 text-center text-sm text-ms-muted">Chargement des actifs…</p>
        )}
        <div className="flex flex-col gap-2">
          {filtered.map((a) => {
            const up = a.change24h >= 0;
            const suffix = a.quote ? " $" : "";
            return (
              <button
                key={a.id}
                type="button"
                onClick={() => openAsset(a)}
                className="flex items-center gap-3 rounded-2xl bg-ms-card px-3 py-3 text-left active:bg-ms-card-2"
              >
                <AssetIcon asset={a} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="text-[15px] font-semibold text-white">{a.symbol}</span>
                    <span className="truncate text-[12px] text-ms-muted">{a.name}</span>
                  </div>
                  <div className="text-[11px] text-ms-muted-2">
                    {CATEGORY_LABELS[a.category]}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[14px] font-semibold tabular-nums text-white">
                    {formatPrice(a.price, a.decimals, suffix)}
                  </div>
                  <div
                    className={cn(
                      "text-[12px] font-semibold tabular-nums",
                      up ? "text-ms-green" : "text-ms-red",
                    )}
                  >
                    {formatPct(a.change24h)}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
        <p className="mt-4 text-center text-[10px] text-ms-muted-2">
          Cours fictifs — application de présentation
        </p>
      </Scroll>
    </Screen>
  );
}
