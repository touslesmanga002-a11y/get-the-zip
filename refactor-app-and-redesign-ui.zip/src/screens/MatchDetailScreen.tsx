import { useState } from "react";
import { CandlestickChart, EquityChart } from "../components/CandlestickChart";
import { IconAlert, IconCheck, IconExport } from "../components/Icons";
import { BottomBar, GhostButton, Header, PrimaryButton, Screen, Scroll } from "../components/ui";
import { useApp } from "../context/AppContext";
import { MOCK_BACKTEST, MOCK_CONDITIONS, MOCK_OUTCOME, MOCK_SCENARIOS } from "../data/mock";
import { directionLabel, formatScore } from "../utils/format";
import { cn } from "../utils/cn";
import type { Direction } from "../types";

const DETAIL_TABS = [
  { id: "vue", label: "Graphique" },
  { id: "scenarios", label: "Scénarios" },
  { id: "conditions", label: "Alertes" },
  { id: "backtest", label: "Backtest" },
] as const;

type DetailTab = (typeof DETAIL_TABS)[number]["id"];

function DirIcon({ d }: { d: Direction }) {
  const color =
    d === "bullish"
      ? "text-ms-green bg-ms-green/15"
      : d === "bearish"
        ? "text-ms-red bg-ms-red/15"
        : "text-ms-muted bg-white/10";
  return (
    <span className={cn("flex h-6 w-6 items-center justify-center rounded-full", color)}>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
        <path d="M5 12.5l4.2 4.2L19 7.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </span>
  );
}

export function MatchDetailScreen() {
  const { goBack, navigate, selectedMatch, candles, selectedAsset, timeframe } = useApp();
  const [activeTab, setActiveTab] = useState<DetailTab>("vue");

  const m = selectedMatch;
  const scoreLabel =
    m.score >= 9
      ? "Correspondance exceptionnelle"
      : m.score >= 8
        ? "Forte corrélation historique"
        : "Corrélation modérée";

  return (
    <Screen>
      <Header
        title={`Correspondance #${m.rank}`}
        subtitle={`${selectedAsset.pairLabel} · ${timeframe}`}
        onBack={goBack}
      />

      <Scroll className="pt-0">
        {/* Score and Rank Banner */}
        <div className="flex flex-col items-center pt-1 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/20 text-ms-green ring-1 ring-emerald-500/40">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <path d="M5 12.5l4.2 4.2L19 7.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
            <span className="text-[36px] font-black tabular-nums tracking-tight text-white">
              {formatScore(m.score)}
              <span className="text-[16px] font-semibold text-ms-muted"> / 10</span>
            </span>
          </div>
          <p className="mt-0.5 text-[13px] font-semibold text-ms-green">{scoreLabel}</p>
          <span className="mt-1 text-[11px] text-ms-muted">
            Motif détecté le {m.date} · {m.candles} bougies comparées
          </span>
        </div>

        {/* Cohesive Sub-Tabs Navigation */}
        <div className="flex rounded-2xl bg-ms-card p-1 ring-1 ring-white/5">
          {DETAIL_TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id)}
              className={cn(
                "h-8 flex-1 rounded-xl text-[12px] font-bold transition active:scale-95",
                activeTab === t.id
                  ? "bg-ms-teal text-[#06201c] shadow-sm shadow-teal-500/20"
                  : "text-ms-muted hover:text-white",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* TAB 1: VUE GRAPHIQUE & SUPERPOSITION */}
        {activeTab === "vue" && (
          <div className="mt-4 space-y-4">
            <div className="rounded-2xl border border-white/5 bg-ms-card/80 p-2 shadow-inner">
              <CandlestickChart
                candles={m.candlesData}
                overlay={alignOverlay(
                  candles.slice(-m.candlesData.length),
                  m.candlesData,
                )}
                height={220}
                showVolume={false}
                patternLabel="Historique similaire"
                overlayLabel="Marché actuel"
                dates={["Début cycle", "Compression", "Cassure", "Extension"]}
              />
            </div>

            {/* Strengths & Alignment */}
            <div className="rounded-2xl border border-white/5 bg-ms-card p-4">
              <h3 className="text-[14px] font-bold text-white">Points forts de la corrélation</h3>
              <ul className="mt-3 space-y-2.5">
                {m.strengths.map((s) => (
                  <li key={s} className="flex items-start gap-2.5 text-[13px] text-white/90">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                        <path d="M5 12.5l4.2 4.2L19 7.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-ms-card p-3">
                <div className="text-[11px] text-ms-muted">Biais historique</div>
                <div className="mt-1 flex items-center gap-1.5 font-bold text-white">
                  <span className="h-2 w-2 rounded-full bg-ms-green" />
                  {m.direction === "bullish" ? "Haussier (Bullish)" : "Baissier"}
                </div>
              </div>
              <div className="rounded-xl bg-ms-card p-3">
                <div className="text-[11px] text-ms-muted">Dynamique volume</div>
                <div className="mt-1 font-bold text-white">
                  {m.volumeTrend === "up" ? "En hausse (+18%)" : "Stable"}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SCÉNARIOS & PROLONGEMENTS */}
        {activeTab === "scenarios" && (
          <div className="mt-4 space-y-4">
            <div className="rounded-2xl border border-white/5 bg-ms-card p-4">
              <div className="text-[12px] font-medium text-ms-muted">
                Comportement historique après ce motif :
              </div>
              <div className="mt-3 flex gap-3">
                <div className="flex flex-1 items-center gap-2.5 rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ms-green/20 text-ms-green">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <path d="M5 12.5l4.2 4.2L19 7.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  <div>
                    <div className="text-[22px] font-extrabold text-ms-green leading-tight">
                      {MOCK_OUTCOME.bullish}%
                    </div>
                    <div className="text-[11px] font-medium text-ms-muted">Hausse</div>
                  </div>
                </div>

                <div className="flex flex-1 items-center gap-2.5 rounded-xl border border-rose-500/20 bg-rose-500/10 p-3">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-rose-500/20 text-ms-red">
                    <span className="text-sm font-black">▼</span>
                  </span>
                  <div>
                    <div className="text-[22px] font-extrabold text-ms-red leading-tight">
                      {MOCK_OUTCOME.bearish}%
                    </div>
                    <div className="text-[11px] font-medium text-ms-muted">Baisse</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Horizons probabilistes */}
            <h3 className="text-[14px] font-bold text-white px-1">Horizons prédictifs</h3>
            <div className="space-y-2">
              {MOCK_SCENARIOS.map((s) => (
                <div key={s.id} className="rounded-2xl border border-white/5 bg-ms-card px-4 py-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-[14px] font-semibold text-white">{s.horizon}</div>
                      <div className="text-[11px] text-ms-muted">{s.rangeLabel}</div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <DirIcon d={s.direction} />
                        <span className="text-[14px] font-bold text-white">{s.probability}%</span>
                      </div>
                      <div className="text-[11px] font-medium text-ms-muted">
                        ±{s.deviation.toLocaleString("fr-FR")}%
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CONDITIONS ET INVALIDATION */}
        {activeTab === "conditions" && (
          <div className="mt-4 space-y-4">
            {MOCK_CONDITIONS.map((g) => (
              <div key={g.id} className="rounded-2xl border border-white/5 bg-ms-card p-4">
                <h4
                  className={cn(
                    "text-[14px] font-bold mb-3 flex items-center gap-2",
                    g.tone === "bullish" && "text-emerald-400",
                    g.tone === "bearish" && "text-rose-400",
                    g.tone === "invalid" && "text-amber-400",
                  )}
                >
                  {g.tone === "bullish" && <IconCheck size={16} />}
                  {g.tone === "bearish" && <IconAlert size={16} />}
                  {g.tone === "invalid" && <IconAlert size={16} />}
                  {g.title}
                </h4>
                <div className="space-y-2">
                  {g.items.map((it) => (
                    <div
                      key={it.id}
                      className="flex items-center justify-between rounded-xl bg-ms-bg/60 px-3 py-2.5 text-[12px]"
                    >
                      <span className="text-white/90">{it.label}</span>
                      {it.value && (
                        <span className="font-bold text-white bg-white/10 px-2 py-0.5 rounded-md">
                          {it.value}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 4: BACKTEST & STATISTIQUES */}
        {activeTab === "backtest" && (
          <div className="mt-4 space-y-4">
            <div className="grid grid-cols-2 gap-2.5">
              <div className="rounded-2xl border border-white/5 bg-ms-card p-3.5">
                <div className="text-[11px] text-ms-muted">Direction confirmée</div>
                <div className="mt-1 text-[22px] font-extrabold text-ms-teal">
                  {MOCK_BACKTEST.correctDirection}%
                </div>
              </div>
              <div className="rounded-2xl border border-white/5 bg-ms-card p-3.5">
                <div className="text-[11px] text-ms-muted">Cas historiques analysés</div>
                <div className="mt-1 text-[22px] font-extrabold text-white">
                  {MOCK_BACKTEST.cases}
                </div>
              </div>
              <div className="rounded-2xl border border-white/5 bg-ms-card p-3.5">
                <div className="text-[11px] text-ms-muted">Erreur moyenne</div>
                <div className="mt-1 text-[20px] font-bold text-white">
                  {MOCK_BACKTEST.meanError.toLocaleString("fr-FR")}%
                </div>
              </div>
              <div className="rounded-2xl border border-white/5 bg-ms-card p-3.5">
                <div className="text-[11px] text-ms-muted">Calibration probabilité</div>
                <div className="mt-1 text-[20px] font-bold text-white">
                  {MOCK_BACKTEST.calibration.toLocaleString("fr-FR")}
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/5 bg-ms-card p-3">
              <div className="text-[12px] font-bold text-white mb-2">Courbe d'équité cumulée</div>
              <EquityChart values={MOCK_BACKTEST.equityCurve} height={130} />
            </div>
          </div>
        )}
      </Scroll>

      {/* Bottom Bar Actions */}
      <BottomBar>
        <div className="flex gap-3">
          <GhostButton className="flex-1" onClick={goBack}>
            ‹ Autres motifs
          </GhostButton>
          <PrimaryButton
            className="flex-1 flex items-center justify-center gap-2"
            onClick={() => navigate("export")}
          >
            <IconExport size={18} />
            <span>Exporter le rapport</span>
          </PrimaryButton>
        </div>
      </BottomBar>
    </Screen>
  );
}

function alignOverlay(
  overlay: { open: number; high: number; low: number; close: number; volume: number; time: number }[],
  base: { open: number; high: number; low: number; close: number }[],
) {
  if (!overlay.length || !base.length) return overlay;
  const b0 = base[0].open;
  const o0 = overlay[0].open || 1;
  const factor = b0 / o0;
  return overlay.map((c) => ({
    ...c,
    open: c.open * factor,
    high: c.high * factor,
    low: c.low * factor,
    close: c.close * factor,
  }));
}
