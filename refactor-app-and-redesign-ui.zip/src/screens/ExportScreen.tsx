import {
  BottomBar,
  CheckRow,
  Header,
  PrimaryButton,
  RadioRow,
  Screen,
  Scroll,
  StatusBar,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { ExportConfig } from "../types";

const FORMATS: { id: ExportConfig["format"]; title: string; hint: string }[] = [
  { id: "pdf", title: "PDF", hint: "(rapport complet)" },
  { id: "csv", title: "CSV", hint: "(données brutes)" },
  { id: "json", title: "JSON", hint: "(données complètes)" },
  { id: "image", title: "Image", hint: "(graphique)" },
];

export function ExportScreen() {
  const { goBack, exportConfig, setExportConfig, showToast } = useApp();

  const run = async () => {
    const res = await marketApi.exportResults(exportConfig);
    showToast(`Export démo prêt : ${res.filename}`);
  };

  return (
    <Screen>
      <StatusBar />
      <Header title="Exporter les résultats" onBack={goBack} />
      <Scroll>
        <div className="space-y-2">
          {FORMATS.map((f) => (
            <RadioRow
              key={f.id}
              checked={exportConfig.format === f.id}
              onChange={() => setExportConfig((e) => ({ ...e, format: f.id }))}
            >
              <span className="font-semibold">{f.title}</span>{" "}
              <span className="font-normal text-ms-muted">{f.hint}</span>
            </RadioRow>
          ))}
        </div>

        <h3 className="mt-6 mb-1 text-[14px] font-semibold">Inclure</h3>
        <div className="rounded-2xl bg-ms-card px-4 py-2">
          <CheckRow
            checked={exportConfig.includeCharts}
            onChange={() =>
              setExportConfig((e) => ({ ...e, includeCharts: !e.includeCharts }))
            }
          >
            Graphiques
          </CheckRow>
          <CheckRow
            checked={exportConfig.includeMatches}
            onChange={() =>
              setExportConfig((e) => ({ ...e, includeMatches: !e.includeMatches }))
            }
          >
            Correspondances
          </CheckRow>
          <CheckRow
            checked={exportConfig.includeScenarios}
            onChange={() =>
              setExportConfig((e) => ({ ...e, includeScenarios: !e.includeScenarios }))
            }
          >
            Scénarios
          </CheckRow>
          <CheckRow
            checked={exportConfig.includeSettings}
            onChange={() =>
              setExportConfig((e) => ({ ...e, includeSettings: !e.includeSettings }))
            }
          >
            Paramètres
          </CheckRow>
        </div>
      </Scroll>
      <BottomBar>
        <PrimaryButton onClick={run}>Exporter</PrimaryButton>
      </BottomBar>
    </Screen>
  );
}
