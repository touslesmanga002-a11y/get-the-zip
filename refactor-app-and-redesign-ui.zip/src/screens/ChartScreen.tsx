import { CandlestickChart } from "../components/CandlestickChart";
import { IconStar } from "../components/Icons";
import {
  BottomBar,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { Timeframe } from "../types";
import { TIMEFRAME_LABELS } from "../types";
import { formatPct, formatPrice } from "../utils/format";
import { cn } from "../utils/cn";

const TFS: Timeframe[] = ["1m", "15m", "1h", "1j", "1s", "1M"];

export function ChartScreen() {
  const {
    goBack,
    navigate,
    selectedAsset,
    timeframe,
    setTimeframe,
    setCandles,
    candles,
    selectionMode,
    setSelectionMode,
    patternRange,
    setPatternRange,
    favorite,
    setFavorite,
  } = useApp();

  const a = selectedAsset;
  const up = a.change24h >= 0;
  const suffix = a.quote ? " $" : "";

  const changeTf = async (tf: Timeframe) => {
    setTimeframe(tf);
    const data = await marketApi.getCandles(a.id, tf);
    setCandles(data);
  };

  const launch = async () => {
    if (selectionMode === "auto") {
      const range = await marketApi.detectPattern(candles);
      setPatternRange(range);
    }
    navigate("pattern");
  };

  return (
    <Screen>
      <Header
        title={
          <span className="inline-flex items-center gap-2">
            <span className="text-[18px] font-bold text-white">{a.pairLabel}</span>
            <button
              type="button"
              onClick={() => setFavorite(!favorite)}
              className="text-ms-gold transition hover:scale-110 active:scale-95"
              aria-label="Favori"
            >
              <IconStar size={17} filled={favorite} />
            </button>
          </span>
        }
        onBack={goBack}
        center={false}
      />
      <Scroll className="pt-0">
        <p className="px-1 text-[12px] text-ms-muted">{a.exchange}</p>
        <div className="mt-1 flex items-end justify-between px-1">
          <div className="text-[28px] font-bold tabular-nums tracking-tight text-white">
            {formatPrice(a.price, a.decimals, suffix)}
          </div>
          <div
            className={cn(
              "mb-1 text-[13px] font-semibold",
              up ? "text-ms-green" : "text-ms-red",
            )}
          >
            {formatPct(a.change24h)} <span className="text-ms-muted">(24h)</span>
          </div>
        </div>

        <div className="mt-3 flex gap-1">
          {TFS.map((tf) => (
            <button
              key={tf}
              type="button"
              onClick={() => changeTf(tf)}
              className={cn(
                "flex-1 rounded-lg py-1.5 text-[12px] font-semibold",
                timeframe === tf
                  ? "bg-ms-elev text-ms-teal"
                  : "text-ms-muted",
              )}
            >
              {TIMEFRAME_LABELS[tf]}
            </button>
          ))}
        </div>

        <div className="mt-2 rounded-2xl bg-ms-card/60 p-2">
          <CandlestickChart
            candles={candles}
            height={268}
            selection={patternRange}
            dates={["10 avr.", "15 avr.", "20 avr.", "25 avr."]}
          />
        </div>

        <div className="mt-4">
          <p className="mb-2 text-center text-[12px] font-medium text-ms-muted">
            Mode sélection
          </p>
          <div className="mx-auto flex w-[70%] rounded-full bg-ms-elev p-1">
            {(["auto", "manual"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setSelectionMode(m)}
                className={cn(
                  "h-9 flex-1 rounded-full text-[12px] font-bold uppercase tracking-wide",
                  selectionMode === m
                    ? "bg-ms-blue text-white"
                    : "text-ms-muted",
                )}
              >
                {m === "auto" ? "Auto" : "Manuel"}
              </button>
            ))}
          </div>
        </div>
      </Scroll>
      <BottomBar>
        <PrimaryButton onClick={launch}>Lancer l'analyse</PrimaryButton>
      </BottomBar>
    </Screen>
  );
}
