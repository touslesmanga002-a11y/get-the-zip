import type { Direction } from "../types";

/** Format monétaire FR : 68 542,32 $ */
export function formatPrice(value: number, decimals = 2, suffix = " $"): string {
  const formatted = value.toLocaleString("fr-FR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return `${formatted}${suffix}`;
}

export function formatPct(value: number, decimals = 2): string {
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toLocaleString("fr-FR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })} %`;
}

export function formatScore(value: number): string {
  return value.toLocaleString("fr-FR", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  });
}

export function directionLabel(d: Direction): string {
  if (d === "bullish") return "Haussière";
  if (d === "bearish") return "Baissière";
  return "Neutre";
}

export function cnScoreColor(score: number): string {
  if (score >= 9) return "text-ms-green";
  if (score >= 8.5) return "text-ms-gold";
  if (score >= 8) return "text-ms-gold";
  return "text-ms-red";
}
