import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { MOCK_ASSETS, MOCK_BTC_CANDLES, MOCK_MATCHES } from "../data/mock";
import type {
  AnalysisRecord,
  AppSettings,
  Asset,
  AssetCategory,
  Candle,
  ExportConfig,
  PatternMatch,
  PatternRange,
  PeriodConfig,
  ScreenId,
  SelectionMode,
  Timeframe,
} from "../types";

interface Toast {
  id: number;
  message: string;
}

interface NavEntry {
  screen: ScreenId;
  articleId?: string;
}

interface AppState {
  stack: NavEntry[];
  screen: ScreenId;
  articleId?: string;
  direction: "fwd" | "back";
  categoryFilter: AssetCategory | "all";
  selectedAsset: Asset;
  timeframe: Timeframe;
  selectionMode: SelectionMode;
  patternRange: PatternRange;
  candles: Candle[];
  matches: PatternMatch[];
  selectedMatch: PatternMatch;
  matchTab: "vue" | "details";
  settings: AppSettings;
  period: PeriodConfig;
  exportConfig: ExportConfig;
  favorite: boolean;
  toast: Toast | null;
  demoBanner: boolean;
  analysisHistory: AnalysisRecord[];
  backtestAsset: Asset | null;
  backtestFromChart: boolean;
}

interface AppContextValue extends AppState {
  navigate: (screen: ScreenId, extra?: { articleId?: string; replace?: boolean }) => void;
  goBack: () => void;
  resetTo: (screen: ScreenId) => void;
  goHome: () => void;
  navigateFromMenu: (screen: ScreenId, extra?: { articleId?: string }) => void;
  canGoBack: boolean;
  setCategoryFilter: (c: AssetCategory | "all") => void;
  setSelectedAsset: (a: Asset) => void;
  setTimeframe: (t: Timeframe) => void;
  setSelectionMode: (m: SelectionMode) => void;
  setPatternRange: (r: PatternRange) => void;
  setCandles: (c: Candle[]) => void;
  setMatches: (m: PatternMatch[]) => void;
  setSelectedMatch: (m: PatternMatch) => void;
  setMatchTab: (t: "vue" | "details") => void;
  setSettings: (s: AppSettings | ((p: AppSettings) => AppSettings)) => void;
  setPeriod: (p: PeriodConfig | ((prev: PeriodConfig) => PeriodConfig)) => void;
  setExportConfig: (e: ExportConfig | ((p: ExportConfig) => ExportConfig)) => void;
  setFavorite: (v: boolean) => void;
  showToast: (message: string) => void;
  hideToast: () => void;
  dismissDemoBanner: () => void;
  addAnalysisRecord: (r: Omit<AnalysisRecord, "id" | "at">) => void;
  setBacktestAsset: (a: Asset | null) => void;
  setBacktestFromChart: (v: boolean) => void;
  openBacktest: (fromChart: boolean) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const defaultSettings: AppSettings = {
  mode: "auto",
  cloudflare: true,
  directProviders: true,
  localFolder: false,
  granularity: "1h",
  resultCount: 20,
  searchLimit: 500,
};

const defaultPeriod: PeriodConfig = {
  kind: "lastCandles",
  candleCount: 500,
  start: "2024-01-01",
  end: "2025-04-25",
  since: "2024-01-01",
};

const defaultExport: ExportConfig = {
  format: "pdf",
  includeCharts: true,
  includeMatches: true,
  includeScenarios: true,
  includeSettings: true,
};

const HISTORY_KEY = "ms-analysis-history";

function loadHistory(): AnalysisRecord[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as AnalysisRecord[]) : [];
  } catch {
    return [];
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<NavEntry[]>([{ screen: "welcome" }]);
  const [direction, setDirection] = useState<"fwd" | "back">("fwd");
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | "all">("all");
  const [selectedAsset, setSelectedAsset] = useState<Asset>(MOCK_ASSETS[0]);
  const [timeframe, setTimeframe] = useState<Timeframe>("1h");
  const [selectionMode, setSelectionMode] = useState<SelectionMode>("auto");
  const [patternRange, setPatternRange] = useState<PatternRange>({
    startIndex: 64,
    endIndex: 88,
  });
  const [candles, setCandles] = useState<Candle[]>(MOCK_BTC_CANDLES);
  const [matches, setMatches] = useState<PatternMatch[]>(MOCK_MATCHES);
  const [selectedMatch, setSelectedMatch] = useState<PatternMatch>(MOCK_MATCHES[0]);
  const [matchTab, setMatchTab] = useState<"vue" | "details">("vue");
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [period, setPeriod] = useState<PeriodConfig>(defaultPeriod);
  const [exportConfig, setExportConfig] = useState<ExportConfig>(defaultExport);
  const [favorite, setFavorite] = useState(true);
  const [toast, setToast] = useState<Toast | null>(null);
  const [demoBanner, setDemoBanner] = useState(true);
  const [analysisHistory, setAnalysisHistory] = useState<AnalysisRecord[]>(loadHistory);
  const [backtestAsset, setBacktestAsset] = useState<Asset | null>(MOCK_ASSETS[0]);
  const [backtestFromChart, setBacktestFromChart] = useState(false);

  const current = stack[stack.length - 1];

  const collapseToMarkets = useCallback((): NavEntry[] => [{ screen: "assets" }], []);

  const navigate = useCallback((screen: ScreenId, extra?: { articleId?: string; replace?: boolean }) => {
    if (screen === "assets") {
      setDirection("back");
      setStack([{ screen: "assets" }]);
      return;
    }
    setDirection("fwd");
    setStack((s) => {
      const entry: NavEntry = { screen, articleId: extra?.articleId };
      if (extra?.replace) {
        const base = s.length > 0 ? s.slice(0, -1) : [{ screen: "assets" as const }];
        return [...base, entry];
      }
      const last = s[s.length - 1];
      if (last?.screen === screen && last?.articleId === extra?.articleId) return s;
      const rooted = s.length === 0 ? [{ screen: "assets" as const }] : s;
      return [...rooted, entry];
    });
  }, []);

  const goBack = useCallback(() => {
    setDirection("back");
    setStack((s) => {
      if (s.length <= 1) {
        const only = s[0]?.screen;
        if (only === "welcome") return s;
        return [{ screen: "assets" }];
      }
      let next = s.slice(0, -1);
      // Écrans transitoires : on ne s'y arrête pas en reculant.
      while (next.length > 0 && next[next.length - 1]?.screen === "sync") {
        next = next.slice(0, -1);
      }
      const top = next[next.length - 1]?.screen;
      if (!top || top === "welcome" || top === "assets") {
        return [{ screen: "assets" }];
      }
      return next;
    });
  }, []);

  const resetTo = useCallback((screen: ScreenId) => {
    setDirection(screen === "assets" ? "back" : "fwd");
    setStack([{ screen }]);
  }, []);

  const goHome = useCallback(() => {
    setDirection("back");
    setStack([{ screen: "assets" }]);
  }, []);

  const navigateFromMenu = useCallback((screen: ScreenId, extra?: { articleId?: string }) => {
    setDirection(screen === "assets" ? "back" : "fwd");
    setStack((s) => {
      if (screen === "assets") return [{ screen: "assets" }];
      const withoutMenu = s.filter((e) => e.screen !== "menu");
      if (screen === "chart") {
        const last = withoutMenu[withoutMenu.length - 1];
        if (last?.screen === "chart") return withoutMenu.length ? withoutMenu : [{ screen: "chart" as const }];
        const base: NavEntry[] = withoutMenu.length ? withoutMenu : [{ screen: "assets" }];
        return [...base, { screen: "chart" }];
      }
      const last = withoutMenu[withoutMenu.length - 1];
      if (last?.screen === screen) return withoutMenu.length ? withoutMenu : [{ screen: "assets" }];
      const base: NavEntry[] = withoutMenu.length ? withoutMenu : [{ screen: "assets" }];
      return [...base, { screen, articleId: extra?.articleId }];
    });
  }, []);

  // L'écran Marchés est la racine : toute arrivée ici réinitialise l'historique.
  useEffect(() => {
    if (current?.screen !== "assets") return;
    if (stack.length === 1 && stack[0].screen === "assets") return;
    setStack(collapseToMarkets());
  }, [current.screen, stack, collapseToMarkets]);

  const showToast = useCallback((message: string) => {
    const id = Date.now();
    setToast({ id, message });
    window.setTimeout(() => {
      setToast((t) => (t?.id === id ? null : t));
    }, 2600);
  }, []);

  const addAnalysisRecord = useCallback((r: Omit<AnalysisRecord, "id" | "at">) => {
    const rec: AnalysisRecord = {
      ...r,
      id: `a-${Date.now()}`,
      at: Date.now(),
    };
    setAnalysisHistory((prev) => {
      const next = [rec, ...prev].slice(0, 40);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const openBacktest = useCallback(
    (fromChart: boolean) => {
      setBacktestFromChart(fromChart);
      setBacktestAsset(fromChart ? selectedAsset : null);
      if (fromChart) navigate("backtest");
      else navigateFromMenu("backtest");
    },
    [navigate, navigateFromMenu, selectedAsset],
  );

  const value = useMemo<AppContextValue>(
    () => ({
      stack,
      screen: current.screen,
      articleId: current.articleId,
      direction,
      categoryFilter,
      selectedAsset,
      timeframe,
      selectionMode,
      patternRange,
      candles,
      matches,
      selectedMatch,
      matchTab,
      settings,
      period,
      exportConfig,
      favorite,
      toast,
      demoBanner,
      analysisHistory,
      backtestAsset,
      backtestFromChart,
      navigate,
      goBack,
      resetTo,
      goHome,
      navigateFromMenu,
      canGoBack: stack.length > 1,
      setCategoryFilter,
      setSelectedAsset,
      setTimeframe,
      setSelectionMode,
      setPatternRange,
      setCandles,
      setMatches,
      setSelectedMatch,
      setMatchTab,
      setSettings,
      setPeriod,
      setExportConfig,
      setFavorite,
      showToast,
      hideToast: () => setToast(null),
      dismissDemoBanner: () => setDemoBanner(false),
      addAnalysisRecord,
      setBacktestAsset,
      setBacktestFromChart,
      openBacktest,
    }),
    [
      stack,
      current,
      direction,
      categoryFilter,
      selectedAsset,
      timeframe,
      selectionMode,
      patternRange,
      candles,
      matches,
      selectedMatch,
      matchTab,
      settings,
      period,
      exportConfig,
      favorite,
      toast,
      demoBanner,
      analysisHistory,
      backtestAsset,
      backtestFromChart,
      navigate,
      goBack,
      resetTo,
      goHome,
      navigateFromMenu,
      showToast,
      addAnalysisRecord,
      openBacktest,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

/** Empêche le zoom navigateur et intercepte le bouton retour matériel. */
let historyArmed = false;

export function NavigationGuard() {
  const { goBack, screen, stack } = useApp();
  const stackRef = useRef(stack);
  stackRef.current = stack;

  useEffect(() => {
    const arm = () => {
      window.history.pushState({ ms: true, at: Date.now() }, "");
    };
    if (!historyArmed) {
      arm();
      historyArmed = true;
    }

    const onPop = () => {
      const s = stackRef.current;
      const currentScreen = s[s.length - 1]?.screen;
      const atRoot =
        s.length <= 1 || currentScreen === "assets" || currentScreen === "welcome";
      if (atRoot) {
        // Marchés (et accueil) : on reste, l'historique interne est déjà à la racine.
        arm();
        return;
      }
      goBack();
      arm();
    };
    window.addEventListener("popstate", onPop);

    const preventGesture = (e: Event) => e.preventDefault();
    document.addEventListener("gesturestart", preventGesture, { passive: false });
    document.addEventListener("gesturechange", preventGesture, { passive: false });
    document.addEventListener("gestureend", preventGesture, { passive: false });

    const preventPinch = (e: TouchEvent) => {
      if (e.touches.length > 1) e.preventDefault();
    };
    document.addEventListener("touchmove", preventPinch, { passive: false });

    const preventDbl = (e: MouseEvent) => e.preventDefault();
    document.addEventListener("dblclick", preventDbl);

    const preventWheelZoom = (e: WheelEvent) => {
      if (e.ctrlKey) e.preventDefault();
    };
    document.addEventListener("wheel", preventWheelZoom, { passive: false });

    return () => {
      window.removeEventListener("popstate", onPop);
      document.removeEventListener("gesturestart", preventGesture);
      document.removeEventListener("gesturechange", preventGesture);
      document.removeEventListener("gestureend", preventGesture);
      document.removeEventListener("touchmove", preventPinch);
      document.removeEventListener("dblclick", preventDbl);
      document.removeEventListener("wheel", preventWheelZoom);
    };
  }, [goBack]);

  // Chaque nouvel écran empile une entrée navigateur, jusqu'aux marchés.
  const prevLen = useRef(stack.length);
  useEffect(() => {
    if (screen === "assets") {
      prevLen.current = stack.length;
      return;
    }
    if (stack.length > prevLen.current) {
      window.history.pushState({ ms: true, screen, depth: stack.length }, "");
    }
    prevLen.current = stack.length;
  }, [stack.length, screen]);

  return null;
}
