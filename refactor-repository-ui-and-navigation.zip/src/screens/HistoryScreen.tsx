import { IconClock } from "../components/Icons";
import { Header, Screen, Scroll, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import { MOCK_ASSETS } from "../data/mock";
import { TIMEFRAME_LABELS } from "../types";
import { marketApi } from "../services/api";

function formatWhen(ts: number) {
  return new Date(ts).toLocaleString("fr-FR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function HistoryScreen() {
  const {
    goBack,
    navigate,
    analysisHistory,
    setSelectedAsset,
    setTimeframe,
    setCandles,
  } = useApp();

  const open = async (id: string, timeframe: typeof analysisHistory[number]["timeframe"]) => {
    const asset = MOCK_ASSETS.find((a) => a.id === id);
    if (!asset) {
      navigate("scenarios");
      return;
    }
    setSelectedAsset(asset);
    setTimeframe(timeframe);
    const candles = await marketApi.getCandles(asset.id, timeframe);
    setCandles(candles);
    navigate("scenarios");
  };

  return (
    <Screen>
      <StatusBar />
      <Header title="Historique" subtitle="Analyses lancées" onBack={goBack} />
      <Scroll>
        {analysisHistory.length === 0 ? (
          <div className="flex flex-col items-center px-6 py-16 text-center">
            <span className="mb-3 text-ms-muted">
              <IconClock size={28} />
            </span>
            <p className="text-[14px] font-medium text-white/85">Aucune analyse pour l'instant</p>
            <p className="mt-1 text-[12px] leading-relaxed text-ms-muted">
              Les recherches lancées apparaîtront ici.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {analysisHistory.map((h) => (
              <button
                key={h.id}
                type="button"
                onClick={() => open(h.assetId, h.timeframe)}
                className="flex w-full items-center gap-3 rounded-2xl bg-ms-card px-4 py-3 text-left active:bg-ms-card-2"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ms-elev text-ms-muted">
                  <IconClock size={18} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-[14px] font-semibold">{h.pairLabel}</div>
                  <div className="text-[11px] text-ms-muted">
                    {TIMEFRAME_LABELS[h.timeframe]} · {h.candleCount} bougies ·{" "}
                    {h.mode === "auto" ? "Auto" : "Manuel"}
                  </div>
                  <div className="text-[11px] text-ms-muted-2">{formatWhen(h.at)}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </Scroll>
    </Screen>
  );
}
