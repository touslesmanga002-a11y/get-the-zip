import { useEffect, useMemo, useState } from "react";
import { CandlestickChart, RateChart } from "../components/CandlestickChart";
import { IconSearch } from "../components/Icons";
import {
  BottomBar,
  Header,
  PeriodPicker,
  PrimaryButton,
  Screen,
  Scroll,
  Segmented,
  StatusBar,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { MOCK_ASSETS } from "../data/mock";
import { marketApi } from "../services/api";
import type { Asset, Candle, PeriodConfig, Timeframe } from "../types";
import { TIMEFRAME_LABELS, TIMEFRAMES } from "../types";
import { cn } from "../utils/cn";

type Phase = "setup" | "run";
type Horizon = "veryShort" | "short" | "medium" | "long";
type Speed = 0.5 | 1 | 2 | 4 | "instant";

const HORIZONS: { id: Horizon; label: string; short: string }[] = [
  { id: "veryShort", label: "Très court", short: "T. court" },
  { id: "short", label: "Court", short: "Court" },
  { id: "medium", label: "Moyen", short: "Moyen" },
  { id: "long", label: "Long", short: "Long" },
];

const SPEEDS: { id: Speed; label: string }[] = [
  { id: 0.5, label: "0,5×" },
  { id: 1, label: "1×" },
  { id: 2, label: "2×" },
  { id: 4, label: "4×" },
  { id: "instant", label: "Instantané" },
];

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function ratesAt(step: number, start: number, total: number) {
  const t = clamp((step - start) / Math.max(1, total - 1 - start), 0, 1);
  const w = (k: number) => Math.sin((step + 3) * 0.17 + k) * 4.2;
  return {
    veryShort: clamp(52 + t * 16 + w(0.4), 0, 100),
    short: clamp(49 + t * 12 + w(1.1), 0, 100),
    medium: clamp(46 + t * 9 + w(1.7), 0, 100),
    long: clamp(44 + t * 8 + w(2.3), 0, 100),
  };
}

export function BacktestScreen() {
  const {
    goBack,
    backtestAsset,
    setBacktestAsset,
    selectedAsset,
    backtestFromChart,
    period,
  } = useApp();

  const [phase, setPhase] = useState<Phase>("setup");
  const [query, setQuery] = useState("");
  const [openList, setOpenList] = useState(false);
  const [btPeriod, setBtPeriod] = useState<PeriodConfig>(period);
  const [granularity, setGranularity] = useState<Timeframe>("1h");
  const [startPct, setStartPct] = useState(50);
  const [series, setSeries] = useState<Candle[]>([]);
  const [cursor, setCursor] = useState(0);
  const [startIdx, setStartIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState<Speed>(1);
  const [horizon, setHorizon] = useState<Horizon>("veryShort");
  const [history, setHistory] = useState<Record<Horizon, number[]>>({
    veryShort: [],
    short: [],
    medium: [],
    long: [],
  });

  const asset = backtestAsset;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return MOCK_ASSETS;
    return MOCK_ASSETS.filter(
      (a) =>
        a.symbol.toLowerCase().includes(q) ||
        a.name.toLowerCase().includes(q) ||
        a.pairLabel.toLowerCase().includes(q),
    );
  }, [query]);

  const pick = (a: Asset) => {
    setBacktestAsset(a);
    setOpenList(false);
    setQuery("");
  };

  const launch = async () => {
    if (!asset) return;
    const data = await marketApi.getCandles(asset.id, granularity);
    const start = Math.floor((data.length - 1) * (startPct / 100));
    const initial = ratesAt(start, start, data.length);
    setSeries(data);
    setStartIdx(start);
    setCursor(start);
    setHistory({
      veryShort: [Math.round(initial.veryShort)],
      short: [Math.round(initial.short)],
      medium: [Math.round(initial.medium)],
      long: [Math.round(initial.long)],
    });
    setPhase("run");
    setPlaying(speed !== "instant");
    if (speed === "instant") {
      const end = data.length - 1;
      const hist: Record<Horizon, number[]> = {
        veryShort: [],
        short: [],
        medium: [],
        long: [],
      };
      for (let i = start; i <= end; i++) {
        const r = ratesAt(i, start, data.length);
        hist.veryShort.push(Math.round(r.veryShort));
        hist.short.push(Math.round(r.short));
        hist.medium.push(Math.round(r.medium));
        hist.long.push(Math.round(r.long));
      }
      setHistory(hist);
      setCursor(end);
      setPlaying(false);
    }
  };

  useEffect(() => {
    if (phase !== "run" || !playing) return;
    if (speed === "instant") {
      const end = series.length - 1;
      const hist: Record<Horizon, number[]> = {
        veryShort: [],
        short: [],
        medium: [],
        long: [],
      };
      for (let i = startIdx; i <= end; i++) {
        const r = ratesAt(i, startIdx, series.length);
        hist.veryShort.push(Math.round(r.veryShort));
        hist.short.push(Math.round(r.short));
        hist.medium.push(Math.round(r.medium));
        hist.long.push(Math.round(r.long));
      }
      setHistory(hist);
      setCursor(end);
      setPlaying(false);
      return;
    }
    const ms = 420 / speed;
    const id = window.setInterval(() => {
      setCursor((c) => {
        if (c >= series.length - 1) {
          setPlaying(false);
          return c;
        }
        const next = c + 1;
        const r = ratesAt(next, startIdx, series.length);
        setHistory((h) => ({
          veryShort: [...h.veryShort, Math.round(r.veryShort)],
          short: [...h.short, Math.round(r.short)],
          medium: [...h.medium, Math.round(r.medium)],
          long: [...h.long, Math.round(r.long)],
        }));
        return next;
      });
    }, ms);
    return () => window.clearInterval(id);
  }, [phase, playing, speed, series.length, startIdx]);

  const replay = () => {
    const r = ratesAt(startIdx, startIdx, series.length);
    setCursor(startIdx);
    setHistory({
      veryShort: [Math.round(r.veryShort)],
      short: [Math.round(r.short)],
      medium: [Math.round(r.medium)],
      long: [Math.round(r.long)],
    });
    setPlaying(speed !== "instant");
    if (speed === "instant") {
      const end = series.length - 1;
      const hist: Record<Horizon, number[]> = {
        veryShort: [],
        short: [],
        medium: [],
        long: [],
      };
      for (let i = startIdx; i <= end; i++) {
        const rr = ratesAt(i, startIdx, series.length);
        hist.veryShort.push(Math.round(rr.veryShort));
        hist.short.push(Math.round(rr.short));
        hist.medium.push(Math.round(rr.medium));
        hist.long.push(Math.round(rr.long));
      }
      setHistory(hist);
      setCursor(end);
      setPlaying(false);
    }
  };

  const visible = series.slice(0, Math.max(2, cursor + 1));
  const rates = ratesAt(cursor, startIdx, Math.max(series.length, 2));
  const estimateUp = rates.veryShort >= 50;
  const estimatePct = Math.round(rates.veryShort);

  if (phase === "setup") {
    return (
      <Screen>
        <StatusBar />
        <Header title="Backtest" onBack={goBack} />
        <Scroll className="space-y-4">
          <div>
            <span className="mb-1.5 block text-[12px] font-medium text-ms-muted">
              Courbe à utiliser
            </span>
            <div className="relative">
              <button
                type="button"
                onClick={() => setOpenList((v) => !v)}
                className="flex h-12 w-full items-center gap-2 rounded-xl border border-white/5 bg-ms-card px-3 text-left"
              >
                <IconSearch size={16} className="text-ms-muted" />
                <span className={cn("flex-1 text-[14px]", asset ? "text-white" : "text-ms-muted")}>
                  {asset ? `${asset.pairLabel} — ${asset.name}` : "À sélectionner"}
                </span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-ms-muted">
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
              {openList && (
                <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-xl border border-white/10 bg-ms-card-2 shadow-xl">
                  <div className="border-b border-white/5 px-3 py-2">
                    <input
                      autoFocus
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Rechercher un symbole…"
                      className="h-9 w-full bg-transparent text-[13px] text-white outline-none placeholder:text-ms-muted-2"
                    />
                  </div>
                  <div className="ms-scroll max-h-52 overflow-y-auto">
                    {filtered.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => pick(a)}
                        className={cn(
                          "flex w-full items-center justify-between px-3 py-2.5 text-left text-[13px] active:bg-white/5",
                          asset?.id === a.id && "bg-white/5",
                        )}
                      >
                        <span className="font-semibold">{a.pairLabel}</span>
                        <span className="text-ms-muted">{a.name}</span>
                      </button>
                    ))}
                    {filtered.length === 0 && (
                      <p className="px-3 py-3 text-[12px] text-ms-muted">Aucun résultat</p>
                    )}
                  </div>
                </div>
              )}
            </div>
            {backtestFromChart && asset && (
              <p className="mt-1.5 text-[11px] text-ms-muted">
                Pré-rempli depuis {selectedAsset.pairLabel}, modifiable.
              </p>
            )}
          </div>

          <PeriodPicker period={btPeriod} onChange={setBtPeriod} />

          <label className="block">
            <span className="mb-1.5 block text-[12px] font-medium text-ms-muted">
              Granularité des bougies
            </span>
            <Segmented
              size="sm"
              value={granularity}
              onChange={(id) => setGranularity(id as Timeframe)}
              options={TIMEFRAMES.map((tf) => ({ id: tf, label: TIMEFRAME_LABELS[tf] }))}
            />
          </label>

          <div className="rounded-2xl bg-ms-card px-4 py-3.5">
            <div className="flex items-center justify-between">
              <span className="text-[14px] font-medium">Début du backtest</span>
              <span className="text-[14px] font-semibold tabular-nums text-white">{startPct}%</span>
            </div>
            <p className="mt-1 text-[11px] text-ms-muted">
              Part d'historique déjà connue avant comparaison (30 à 90 %).
            </p>
            <input
              type="range"
              min={30}
              max={90}
              step={1}
              value={startPct}
              onChange={(e) => setStartPct(Number(e.target.value))}
              className="mt-3 w-full accent-ms-teal"
            />
            <div className="mt-1 flex justify-between text-[10px] text-ms-muted-2">
              <span>30%</span>
              <span>90%</span>
            </div>
          </div>
        </Scroll>
        <BottomBar>
          <PrimaryButton disabled={!asset} onClick={launch}>
            Lancer le backtest
          </PrimaryButton>
        </BottomBar>
      </Screen>
    );
  }

  return (
    <Screen>
      <StatusBar />
      <Header
        title="Backtest"
        subtitle={asset ? `${asset.pairLabel} · ${TIMEFRAME_LABELS[granularity]}` : undefined}
        onBack={() => {
          setPlaying(false);
          setPhase("setup");
        }}
      />
      <Scroll className="pt-1">
        <div className="relative rounded-2xl bg-ms-card/70 p-2">
          <div className="absolute right-3 top-3 z-10 rounded-xl bg-[#071422]/80 px-2.5 py-1.5 text-right backdrop-blur-sm">
            {HORIZONS.map((h) => (
              <div key={h.id} className="flex items-center justify-end gap-2 text-[10px] leading-4">
                <span className="text-ms-muted">{h.short}</span>
                <span className="w-8 font-semibold tabular-nums text-white">
                  {Math.round(rates[h.id])}%
                </span>
              </div>
            ))}
          </div>
          <CandlestickChart
            candles={visible}
            height={250}
            showVolume={false}
            highlightLast={Math.max(2, visible.length - startIdx)}
          />
        </div>

        <div className="mt-3 flex items-center justify-between rounded-2xl bg-ms-card px-4 py-3">
          <div>
            <div className="text-[11px] text-ms-muted">Estimation</div>
            <div className={cn("text-[15px] font-semibold", estimateUp ? "text-ms-green" : "text-ms-red")}>
              {estimateUp ? "Haussière" : "Baissière"} · {estimatePct}%
            </div>
          </div>
          <div className="text-right text-[11px] text-ms-muted">
            Bougie {cursor + 1} / {series.length}
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <button
            type="button"
            onClick={replay}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-ms-elev text-white"
            aria-label="Rejouer"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 12a8 8 0 101.7-4.9" />
              <path d="M4 4v5h5" />
            </svg>
          </button>
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            className="flex h-10 flex-1 items-center justify-center rounded-full bg-ms-card text-[13px] font-semibold"
          >
            {playing ? "Pause" : cursor >= series.length - 1 ? "Terminé" : "Lecture"}
          </button>
        </div>

        <div className="mt-3">
          <span className="mb-1.5 block text-[11px] font-medium text-ms-muted">Vitesse</span>
          <Segmented
            size="sm"
            value={String(speed)}
            onChange={(id) => setSpeed(id === "instant" ? "instant" : (Number(id) as Speed))}
            options={SPEEDS.map((s) => ({ id: String(s.id), label: s.label }))}
          />
        </div>

        <h3 className="mt-5 text-[14px] font-semibold">Taux de réussite</h3>
        <div className="mt-2">
          <Segmented
            size="sm"
            value={horizon}
            onChange={(id) => setHorizon(id as Horizon)}
            options={HORIZONS.map((h) => ({ id: h.id, label: h.label }))}
          />
        </div>
        <div className="mt-2 rounded-2xl bg-ms-card p-2">
          <RateChart values={history[horizon].length > 1 ? history[horizon] : [50, 50]} />
        </div>
        <p className="mt-2 text-center text-[10px] text-ms-muted-2">
          Backtest fictif — ne constitue pas un historique réel
        </p>
      </Scroll>
    </Screen>
  );
}
