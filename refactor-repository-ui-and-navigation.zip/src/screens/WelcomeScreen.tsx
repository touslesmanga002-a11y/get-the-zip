import { BitcoinBadge, LogoGlyph } from "../components/Icons";
import { BottomBar, PrimaryButton, Screen } from "../components/ui";
import { MOUNTAINS_SRC } from "../assets/mountains";
import { useApp } from "../context/AppContext";
import type { AssetCategory } from "../types";

function MountainSky() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <img
        src={MOUNTAINS_SRC}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-[center_35%]"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#050d18]/35 via-[#071422]/45 to-[#071422]" />
      <div className="absolute inset-x-0 bottom-0 h-[55%] bg-gradient-to-t from-[#071422] via-[#071422]/85 to-transparent" />
    </div>
  );
}

const CATEGORIES: {
  id: AssetCategory;
  title: string;
  subtitle: string;
  icon: "btc" | "forex" | "stock" | "commodity";
}[] = [
  { id: "crypto", title: "Cryptomonnaies", subtitle: "BTC, ETH, SOL…", icon: "btc" },
  { id: "forex", title: "Forex", subtitle: "EUR/USD, GBP/USD…", icon: "forex" },
  { id: "stock", title: "Actions", subtitle: "AAPL, MSFT…", icon: "stock" },
  { id: "commodity", title: "Matières premières", subtitle: "Or, pétrole…", icon: "commodity" },
];

function CatIcon({ kind }: { kind: (typeof CATEGORIES)[number]["icon"] }) {
  if (kind === "btc") return <BitcoinBadge />;
  if (kind === "forex")
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1a9b8a]">
        <span className="text-lg font-bold text-white">£</span>
      </div>
    );
  if (kind === "stock")
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#6d5efc]">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2">
          <path d="M4 16l5-6 4 3 7-8" />
        </svg>
      </div>
    );
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#c9a227]">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3a2a00" strokeWidth="2">
        <ellipse cx="12" cy="8" rx="7" ry="3" />
        <path d="M5 8v8c0 1.7 3.1 3 7 3s7-1.3 7-3V8" />
      </svg>
    </div>
  );
}

export function WelcomeScreen() {
  const { resetTo, setCategoryFilter } = useApp();

  const open = (cat: AssetCategory | "all") => {
    setCategoryFilter(cat);
    // L'accueil n'est vu qu'une fois : on réinitialise la pile sans y revenir.
    resetTo("assets");
  };

  return (
    <Screen className="relative overflow-hidden">
      <MountainSky />
      <div className="relative flex min-h-0 flex-1 flex-col pt-[max(16px,env(safe-area-inset-top))]">
        <div className="flex flex-1 flex-col px-5 pt-8">
          <div className="ms-fade flex flex-col items-center pt-2 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#10283f]/90 shadow-lg shadow-emerald-500/15 ring-1 ring-white/15 backdrop-blur-sm">
              <LogoGlyph size={40} />
            </div>
            <h1 className="text-[34px] font-extrabold tracking-tight text-white">MarketScope</h1>
            <p className="mt-2 max-w-[280px] text-[14px] leading-snug text-white/75">
              Repérez des patterns, comparez l'historique, anticipez les scénarios.
            </p>
          </div>

          <div className="mt-8 flex flex-col gap-3">
            {CATEGORIES.map((c, i) => (
              <button
                key={c.id}
                type="button"
                onClick={() => open(c.id)}
                className={`ms-fade ms-delay-${i + 1} flex items-center gap-3 rounded-2xl border border-white/10 bg-[#0e243a]/80 px-3.5 py-3 text-left shadow-sm backdrop-blur-md active:bg-[#163049]`}
              >
                <CatIcon kind={c.icon} />
                <div className="flex-1">
                  <div className="text-[15px] font-semibold text-white">{c.title}</div>
                  <div className="text-[12px] text-ms-muted">{c.subtitle}</div>
                </div>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#7d97ad" strokeWidth="2">
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </button>
            ))}
          </div>
        </div>
        <BottomBar>
          <PrimaryButton tone="blue" onClick={() => open("all")}>
            Explorer tous les marchés
          </PrimaryButton>
        </BottomBar>
      </div>
    </Screen>
  );
}
