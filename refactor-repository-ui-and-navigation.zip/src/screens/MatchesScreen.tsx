import { useState } from "react";
import { MiniSpark } from "../components/CandlestickChart";
import { IconChevronRight } from "../components/Icons";
import { Header, Screen, Scroll, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import { directionLabel, formatScore, cnScoreColor } from "../utils/format";
import { cn } from "../utils/cn";
import type { Direction, VolumeTrend } from "../types";

function DirChip({ d }: { d: Direction }) {
  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-[10px] font-semibold",
        d === "bullish" && "bg-emerald-500/15 text-ms-green",
        d === "bearish" && "bg-rose-500/15 text-ms-red",
        d === "neutral" && "bg-white/10 text-ms-muted",
      )}
    >
      {directionLabel(d)}
    </span>
  );
}

function VolChip({ v }: { v: VolumeTrend }) {
  const label = v === "up" ? "Volume ↑" : v === "down" ? "Volume ↓" : "Volume =";
  const color =
    v === "up" ? "text-ms-green" : v === "down" ? "text-ms-red" : "text-ms-muted";
  return <span className={cn("text-[10px] font-semibold", color)}>{label}</span>;
}

export function MatchesScreen() {
  const { goBack, navigate, matches, setSelectedMatch, setMatchTab, period, settings } = useApp();
  const pageSize = 5;
  const [page, setPage] = useState(0);
  const visible = matches.slice(0, settings.resultCount);
  const pages = Math.max(1, Math.ceil(visible.length / pageSize));
  const slice = visible.slice(page * pageSize, page * pageSize + pageSize);

  return (
    <Screen>
      <StatusBar />
      <Header title="Scénarios" subtitle="Correspondances historiques" onBack={goBack} />
      <div className="flex items-center justify-between px-5 pb-2">
        <p className="text-[13px] text-ms-muted">
          {Math.min(settings.resultCount, visible.length)} résultats
          {period.kind === "lastCandles" ? ` (${period.candleCount} bougies)` : ""}
        </p>
      </div>
      <Scroll className="pt-1">
        <div className="grid grid-cols-1 gap-2.5">
          {slice.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => {
                setSelectedMatch(m);
                setMatchTab("vue");
                navigate("matchDetail");
              }}
              className="flex min-w-0 items-center gap-2 rounded-2xl bg-ms-card px-[3.2%] py-2.5 text-left active:bg-ms-card-2 sm:gap-3 sm:px-3"
            >
              <span className="w-6 shrink-0 text-[12px] font-semibold text-ms-muted sm:w-7">
                #{m.rank}
              </span>
              <MiniSpark candles={m.candlesData.slice(-16)} />
              <div className="min-w-0 flex-1">
                <div className={cn("text-[16px] font-bold tabular-nums sm:text-[18px]", cnScoreColor(m.score))}>
                  {formatScore(m.score)}
                  <span className="text-[11px] font-semibold text-ms-muted sm:text-[12px]"> /10</span>
                </div>
                <div className="truncate text-[11px] text-ms-muted">
                  {m.date} · {m.candles} bougies
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <DirChip d={m.direction} />
                  <VolChip v={m.volumeTrend} />
                </div>
              </div>
              <IconChevronRight size={18} className="shrink-0 text-ms-muted-2" />
            </button>
          ))}
        </div>
      </Scroll>
      <div className="flex items-center justify-between px-6 pb-[max(16px,env(safe-area-inset-bottom))] pt-2 text-[13px] font-semibold text-ms-muted">
        <button
          type="button"
          disabled={page === 0}
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className={page === 0 ? "opacity-40" : "text-white/80"}
        >
          ‹ Précédent
        </button>
        <span className="text-[11px] tabular-nums">
          {page + 1} / {pages}
        </span>
        <button
          type="button"
          disabled={page >= pages - 1}
          onClick={() => setPage((p) => Math.min(pages - 1, p + 1))}
          className={page >= pages - 1 ? "opacity-40" : "text-white/80"}
        >
          Suivant ›
        </button>
      </div>
    </Screen>
  );
}
