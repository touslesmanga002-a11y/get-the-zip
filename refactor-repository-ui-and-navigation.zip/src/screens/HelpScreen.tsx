import {
  IconBook,
  IconChat,
  IconChevronRight,
  IconInfo,
  IconPhone,
  IconRefresh,
  LogoGlyph,
} from "../components/Icons";
import { Header, Screen, Scroll, StatusBar } from "../components/ui";
import { APP_UPDATED_AT, APP_VERSION, MOCK_HELP } from "../data/mock";
import { useApp } from "../context/AppContext";
import type { HelpArticle } from "../types";
import type { ReactNode } from "react";

function articleIcon(icon: HelpArticle["icon"]) {
  const p = { size: 20, className: "text-ms-muted" };
  switch (icon) {
    case "book":
      return <IconBook {...p} />;
    case "chat":
      return <IconChat {...p} />;
    case "phone":
      return <IconPhone {...p} />;
    default:
      return <IconInfo {...p} />;
  }
}

export function HelpScreen() {
  const { goBack, navigate, showToast } = useApp();

  return (
    <Screen>
      <StatusBar />
      <Header title="Aide" onBack={goBack} />
      <Scroll>
        <div className="overflow-hidden rounded-2xl bg-ms-card">
          {MOCK_HELP.map((a, i) => (
            <HelpRow
              key={a.id}
              icon={articleIcon(a.icon)}
              label={a.title}
              last={i === MOCK_HELP.length - 1}
              onClick={() => navigate("helpArticle", { articleId: a.id })}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={() => showToast(`MarketScope ${APP_VERSION} — démo`)}
          className="mt-4 flex w-full items-center gap-3 rounded-2xl bg-ms-card px-4 py-3.5 text-left"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#10283f] text-ms-green">
            <LogoGlyph size={22} color="currentColor" />
          </span>
          <div className="flex-1">
            <div className="text-[13px] font-semibold">Version de l'application</div>
            <div className="text-[12px] text-ms-muted">Version {APP_VERSION}</div>
            <div className="text-[11px] text-ms-muted-2">
              Dernière mise à jour : {APP_UPDATED_AT}
            </div>
          </div>
          <IconRefresh size={16} className="text-ms-muted" />
          <IconChevronRight size={18} className="text-ms-muted" />
        </button>
      </Scroll>
    </Screen>
  );
}

function HelpRow({
  icon,
  label,
  onClick,
  last,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  last?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-3 px-4 py-3.5 text-left ${last ? "" : "border-b border-white/5"}`}
    >
      {icon}
      <span className="flex-1 text-[14px]">{label}</span>
      <IconChevronRight size={18} className="text-ms-muted" />
    </button>
  );
}

export function HelpArticleScreen() {
  const { goBack, articleId } = useApp();
  const article = MOCK_HELP.find((a) => a.id === articleId) ?? MOCK_HELP[0];
  return (
    <Screen>
      <StatusBar />
      <Header title={article.title} onBack={goBack} />
      <Scroll>
        <div className="space-y-3 rounded-2xl bg-ms-card p-4">
          {article.body.map((p) => (
            <p key={p} className="text-[14px] leading-relaxed text-white/85">
              {p}
            </p>
          ))}
        </div>
      </Scroll>
    </Screen>
  );
}
