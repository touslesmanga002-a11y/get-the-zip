import { CandlestickChart } from "../components/CandlestickChart";
import { Header, Screen, Scroll, Segmented, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import { formatScore } from "../utils/format";

const TABS = [
  { id: "vue", label: "Vue" },
  { id: "details", label: "Détails" },
] as const;

export function MatchDetailScreen() {
  const { goBack, selectedMatch, candles, matchTab, setMatchTab } = useApp();
  const m = selectedMatch;
  const scoreLabel =
    m.score >= 9 ? "Excellente correspondance" : m.score >= 8 ? "Bonne correspondance" : "Correspondance acceptable";

  return (
    <Screen>
      <StatusBar />
      <Header title={`Correspondance #${m.rank}`} onBack={goBack} />
      <Scroll>
        <div className="flex flex-col items-center pt-1">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <path d="M5 12.5l4.2 4.2L19 7.5" />
              </svg>
            </span>
            <span className="text-[34px] font-extrabold tabular-nums tracking-tight text-ms-green">
              {formatScore(m.score)}
              <span className="text-[16px] font-semibold text-ms-muted"> /10</span>
            </span>
          </div>
          <p className="mt-0.5 text-[13px] font-medium text-ms-green">{scoreLabel}</p>
        </div>

        <div className="mt-4">
          <Segmented
            value={matchTab}
            onChange={(id) => setMatchTab(id as "vue" | "details")}
            options={TABS.map((t) => ({ id: t.id, label: t.label }))}
          />
        </div>

        {matchTab === "vue" && (
          <div className="mt-4">
            <div className="rounded-2xl bg-ms-card p-2">
              <CandlestickChart
                candles={m.candlesData}
                overlay={alignOverlay(
                  candles.slice(-m.candlesData.length),
                  m.candlesData,
                )}
                height={220}
                showVolume={false}
                dates={["12 fév.", "14 fév.", "16 fév.", "18 fév."]}
              />
            </div>
            <h3 className="mt-5 text-[15px] font-semibold">Points forts</h3>
            <ul className="mt-2 space-y-2.5">
              {m.strengths.map((s) => (
                <li key={s} className="flex items-start gap-2.5 text-[13px] text-white/90">
                  <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <path d="M5 12.5l4.2 4.2L19 7.5" />
                    </svg>
                  </span>
                  {s}
                </li>
              ))}
            </ul>
          </div>
        )}

        {matchTab === "details" && (
          <div className="mt-4 space-y-3">
            <Row k="Date" v={m.date} />
            <Row k="Bougies comparées" v={`${m.candles}`} />
            <Row k="Direction historique" v={m.direction === "bullish" ? "Haussière" : m.direction === "bearish" ? "Baissière" : "Neutre"} />
            <Row k="Volume" v={m.volumeTrend === "up" ? "En hausse" : m.volumeTrend === "down" ? "En baisse" : "Stable"} />
            <Row k="Score structure" v="9,4 / 10" />
            <Row k="Score amplitude" v="9,1 / 10" />
            <Row k="Score volume" v="9,8 / 10" />
            <p className="pt-2 text-[11px] text-ms-muted-2">
              Métriques calculées sur données de démonstration.
            </p>
          </div>
        )}
      </Scroll>
    </Screen>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-ms-card px-4 py-3">
      <span className="text-[13px] text-ms-muted">{k}</span>
      <span className="text-[13px] font-semibold text-white">{v}</span>
    </div>
  );
}

/** Aligne deux séries sur la même échelle pour le superposé de démo. */
function alignOverlay(
  overlay: { open: number; high: number; low: number; close: number; volume: number; time: number }[],
  base: { open: number; high: number; low: number; close: number }[],
) {
  if (!overlay.length || !base.length) return overlay;
  const b0 = base[0].open;
  const o0 = overlay[0].open || 1;
  const factor = b0 / o0;
  return overlay.map((c) => ({
    ...c,
    open: c.open * factor,
    high: c.high * factor,
    low: c.low * factor,
    close: c.close * factor,
  }));
}
