import {
  BottomBar,
  Header,
  PeriodPicker,
  PrimaryButton,
  Screen,
  Scroll,
  StatusBar,
} from "../components/ui";
import { useApp } from "../context/AppContext";

export function PeriodScreen() {
  const { goBack, period, setPeriod, showToast } = useApp();

  return (
    <Screen>
      <StatusBar />
      <Header title="Période de recherche" onBack={goBack} />
      <Scroll>
        <PeriodPicker period={period} onChange={setPeriod} />
      </Scroll>
      <BottomBar>
        <PrimaryButton
          onClick={() => {
            showToast("Période appliquée (démo)");
            goBack();
          }}
        >
          Appliquer
        </PrimaryButton>
      </BottomBar>
    </Screen>
  );
}
