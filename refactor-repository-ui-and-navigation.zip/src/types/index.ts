/**
 * Types du socle MarketScope.
 * Conçus pour coller à un futur backend REST/WebSocket sans casser l'UI.
 */

export type AssetCategory = "crypto" | "forex" | "stock" | "commodity";

export type Timeframe = "1m" | "5m" | "15m" | "1h" | "1j" | "1s" | "1M";

export type Direction = "bullish" | "bearish" | "neutral";

export type VolumeTrend = "up" | "down" | "flat";

export type SelectionMode = "auto" | "manual";

export type ScreenId =
  | "welcome"
  | "menu"
  | "assets"
  | "chart"
  | "pattern"
  | "sync"
  | "matches"
  | "matchDetail"
  | "scenarios"
  | "conditions"
  | "period"
  | "settings"
  | "backtest"
  | "export"
  | "help"
  | "helpArticle"
  | "dataSources"
  | "cache"
  | "advanced"
  | "history";

export interface Asset {
  id: string;
  symbol: string;
  pairLabel: string;
  name: string;
  category: AssetCategory;
  exchange: string;
  price: number;
  change24h: number;
  /** Devise d'affichage. Vide pour le forex (devises déjà dans le symbole). */
  quote: "USD" | "USDT" | "EUR" | "";
  decimals: number;
}

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface PatternRange {
  startIndex: number;
  endIndex: number;
}

export interface PatternMatch {
  id: string;
  rank: number;
  score: number;
  date: string;
  dateShort: string;
  candles: number;
  direction: Direction;
  volumeTrend: VolumeTrend;
  /** Bougies de la correspondance historique (données de démo). */
  candlesData: Candle[];
  strengths: string[];
}

export interface Scenario {
  id: string;
  horizon: string;
  rangeLabel: string;
  direction: Direction;
  probability: number;
  deviation: number;
}

export interface ConditionItem {
  id: string;
  label: string;
  value?: string;
}

export interface ConditionGroup {
  id: string;
  title: string;
  tone: "bullish" | "bearish" | "invalid";
  items: ConditionItem[];
}

export interface DataProvider {
  id: string;
  name: string;
  subtitle: string;
  connected: boolean;
  primary: boolean;
  color: string;
  icon: "yahoo" | "binance" | "kraken" | "iress" | "forex";
}

export interface AppSettings {
  mode: "auto" | "manual";
  cloudflare: boolean;
  directProviders: boolean;
  localFolder: boolean;
  granularity: Timeframe;
  resultCount: number;
  searchLimit: number;
}

export type PeriodKind = "lastCandles" | "custom" | "since" | "all";

export interface PeriodConfig {
  kind: PeriodKind;
  candleCount: number;
  start: string;
  end: string;
  since: string;
}

export interface BacktestStats {
  cases: number;
  correctDirection: number;
  meanError: number;
  calibration: number;
  bySimilarity: { range: string; accuracy: number; error: number }[];
  equityCurve: number[];
}

export interface BacktestConfig {
  assetId: string | null;
  period: PeriodConfig;
  granularity: Timeframe;
  startPct: number;
}

export interface AnalysisRecord {
  id: string;
  assetId: string;
  symbol: string;
  pairLabel: string;
  timeframe: Timeframe;
  at: number;
  candleCount: number;
  mode: SelectionMode;
}

export interface ExportConfig {
  format: "pdf" | "csv" | "json" | "image";
  includeCharts: boolean;
  includeMatches: boolean;
  includeScenarios: boolean;
  includeSettings: boolean;
}

export interface HelpArticle {
  id: string;
  title: string;
  icon: "book" | "info" | "grid" | "score" | "faq" | "chat" | "phone";
  body: string[];
}

export interface SyncStep {
  id: string;
  label: string;
}

export const TIMEFRAME_LABELS: Record<Timeframe, string> = {
  "1m": "1m",
  "5m": "5m",
  "15m": "15m",
  "1h": "1h",
  "1j": "1j",
  "1s": "1s",
  "1M": "1M",
};

export const TIMEFRAMES: Timeframe[] = ["1m", "5m", "15m", "1h", "1j", "1s", "1M"];

export const CATEGORY_LABELS: Record<AssetCategory | "all", string> = {
  all: "Tous",
  crypto: "Crypto",
  forex: "Forex",
  stock: "Actions",
  commodity: "Matières",
};

export const PERIOD_OPTIONS: { id: PeriodKind; label: string }[] = [
  { id: "lastCandles", label: "Dernières bougies" },
  { id: "custom", label: "Période personnalisée" },
  { id: "since", label: "Depuis une date" },
  { id: "all", label: "Tout l'historique" },
];
