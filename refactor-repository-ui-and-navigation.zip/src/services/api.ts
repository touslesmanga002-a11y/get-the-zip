/**
 * Couche d'accès aux données.
 *
 * Aujourd'hui : implémentation MOCK (présentation).
 * Demain : remplacer le corps des fonctions par des `fetch` vers le backend
 * sans modifier les écrans.
 *
 * Exemple de bascule :
 *   const res = await fetch(`${API_BASE}/assets`);
 *   return res.json();
 */

import {
  MOCK_ASSETS,
  MOCK_BACKTEST,
  MOCK_BTC_CANDLES,
  MOCK_CONDITIONS,
  MOCK_HELP,
  MOCK_MATCHES,
  MOCK_OUTCOME,
  MOCK_PROVIDERS,
  MOCK_SCENARIOS,
  MOCK_SYNC_STEPS,
  generateCandles,
} from "../data/mock";
import type {
  AppSettings,
  Asset,
  BacktestStats,
  Candle,
  ConditionGroup,
  DataProvider,
  HelpArticle,
  PatternMatch,
  PatternRange,
  PeriodConfig,
  Scenario,
  Timeframe,
} from "../types";

/** Renseigner l'URL du backend (ex. https://api.marketscope.app) pour quitter le mode démo. */
const API_BASE = "";

/** Délai artificiel pour simuler le réseau en démo. */
const latency = (ms = 180) => new Promise((r) => setTimeout(r, ms));

function isLive(): boolean {
  return Boolean(API_BASE);
}

export const marketApi = {
  async getAssets(): Promise<Asset[]> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/assets`);
      if (!res.ok) throw new Error("Impossible de charger les actifs");
      return res.json();
    }
    await latency();
    return MOCK_ASSETS;
  },

  async getCandles(assetId: string, timeframe: Timeframe): Promise<Candle[]> {
    if (isLive()) {
      const res = await fetch(
        `${API_BASE}/assets/${assetId}/candles?tf=${timeframe}`,
      );
      if (!res.ok) throw new Error("Impossible de charger le graphique");
      return res.json();
    }
    await latency(120);
    const asset = MOCK_ASSETS.find((a) => a.id === assetId);
    if (!asset) return MOCK_BTC_CANDLES;
    if (asset.id === "btc-usdt") return MOCK_BTC_CANDLES;
    const tfMul: Record<Timeframe, number> = {
      "1m": 0.004,
      "5m": 0.0055,
      "15m": 0.007,
      "1h": 0.011,
      "1j": 0.018,
      "1s": 0.025,
      "1M": 0.04,
    };
    return generateCandles({
      count: 90,
      startPrice: asset.price * 0.92,
      seed: asset.symbol.length * 97 + timeframe.length * 13,
      volatility: tfMul[timeframe],
    });
  },

  async detectPattern(candles: Candle[]): Promise<PatternRange> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/patterns/detect`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candles }),
      });
      return res.json();
    }
    await latency(400);
    const end = candles.length - 2;
    const start = Math.max(0, end - 24);
    return { startIndex: start, endIndex: end };
  },

  async searchMatches(_params: {
    assetId: string;
    range: PatternRange;
    period: PeriodConfig;
    settings: AppSettings;
  }): Promise<PatternMatch[]> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/matches`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(_params),
      });
      return res.json();
    }
    await latency(500);
    return MOCK_MATCHES;
  },

  async getScenarios(_matchId: string): Promise<{
    outcome: { bullish: number; bearish: number };
    scenarios: Scenario[];
  }> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/matches/${_matchId}/scenarios`);
      return res.json();
    }
    await latency();
    return { outcome: MOCK_OUTCOME, scenarios: MOCK_SCENARIOS };
  },

  async getConditions(_matchId: string): Promise<ConditionGroup[]> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/matches/${_matchId}/conditions`);
      return res.json();
    }
    await latency();
    return MOCK_CONDITIONS;
  },

  async runBacktest(_params: {
    assetId: string;
    settings: AppSettings;
  }): Promise<BacktestStats> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/backtest`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(_params),
      });
      return res.json();
    }
    await latency(600);
    return MOCK_BACKTEST;
  },

  async getProviders(): Promise<DataProvider[]> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/providers`);
      return res.json();
    }
    await latency();
    return MOCK_PROVIDERS;
  },

  async getHelp(): Promise<HelpArticle[]> {
    await latency(80);
    return MOCK_HELP;
  },

  async exportResults(_config: unknown): Promise<{ ok: boolean; filename: string }> {
    if (isLive()) {
      const res = await fetch(`${API_BASE}/export`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(_config),
      });
      return res.json();
    }
    await latency(700);
    return { ok: true, filename: "marketscope-rapport-demo.pdf" };
  },

  getSyncSteps() {
    return MOCK_SYNC_STEPS;
  },
};
