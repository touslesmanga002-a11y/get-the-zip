import type { ReactNode, SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function I({ size = 22, ...p }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...p}
    />
  );
}

export const IconChevronRight = (p: IconProps) => (
  <I {...p}>
    <path d="M9 6l6 6-6 6" />
  </I>
);
export const IconChevronLeft = (p: IconProps) => (
  <I {...p}>
    <path d="M15 6l-6 6 6 6" />
  </I>
);
export const IconSearch = (p: IconProps) => (
  <I {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="M20 20l-3.5-3.5" />
  </I>
);
export const IconStar = ({ filled, ...p }: IconProps & { filled?: boolean }) => (
  <I {...p} fill={filled ? "currentColor" : "none"}>
    <path d="M12 3.2l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 16.6 6.8 19.2l1-5.8L3.6 9.3l5.8-.8L12 3.2z" />
  </I>
);
export const IconBookmark = (p: IconProps) => (
  <I {...p}>
    <path d="M7 4h10a1 1 0 011 1v15l-6-3.2L6 20V5a1 1 0 011-1z" />
  </I>
);
export const IconFilter = (p: IconProps) => (
  <I {...p}>
    <path d="M4 6h16M7 12h10M10 18h4" />
  </I>
);
export const IconHome = (p: IconProps) => (
  <I {...p}>
    <path d="M4 11l8-7 8 7v8a1 1 0 01-1 1h-5v-6H10v6H5a1 1 0 01-1-1v-8z" />
  </I>
);
export const IconAnalyze = (p: IconProps) => (
  <I {...p}>
    <circle cx="6" cy="16" r="2" />
    <circle cx="12" cy="8" r="2" />
    <circle cx="18" cy="13" r="2" />
    <path d="M8 15l3.2-5.5M14 9.2l3 3" />
  </I>
);
export const IconClock = (p: IconProps) => (
  <I {...p}>
    <circle cx="12" cy="12" r="8" />
    <path d="M12 8v4.5L15 15" />
  </I>
);
export const IconLineChart = (p: IconProps) => (
  <I {...p}>
    <path d="M4 18l5-6 4 3 7-9" />
    <path d="M4 20h16" />
  </I>
);
export const IconBars = (p: IconProps) => (
  <I {...p}>
    <path d="M6 18V10M12 18V6M18 18v-7" />
  </I>
);
export const IconBacktest = (p: IconProps) => (
  <I {...p}>
    <path d="M4 16l5-5 4 3 7-8" />
    <path d="M15 6h5v5" />
  </I>
);
export const IconGear = (p: IconProps) => (
  <I {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 3.5v2.2M12 18.3v2.2M4.8 6.5l1.6 1.6M17.6 15.9l1.6 1.6M3.5 12h2.2M18.3 12h2.2M4.8 17.5l1.6-1.6M17.6 8.1l1.6-1.6" />
  </I>
);
export const IconExport = (p: IconProps) => (
  <I {...p}>
    <path d="M12 4v10" />
    <path d="M8 8l4-4 4 4" />
    <path d="M5 16v3a1 1 0 001 1h12a1 1 0 001-1v-3" />
  </I>
);
export const IconBook = (p: IconProps) => (
  <I {...p}>
    <path d="M5 5.5A2.5 2.5 0 017.5 3H20v16H7.5A2.5 2.5 0 005 16.5v-11z" />
    <path d="M5 16.5A2.5 2.5 0 017.5 19H20" />
  </I>
);
export const IconInfo = (p: IconProps) => (
  <I {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 11v5M12 8h.01" />
  </I>
);
export const IconChat = (p: IconProps) => (
  <I {...p}>
    <path d="M5 16.5V7a2 2 0 012-2h10a2 2 0 012 2v7a2 2 0 01-2 2H9l-4 3.2z" />
  </I>
);
export const IconPhone = (p: IconProps) => (
  <I {...p}>
    <path d="M8 3.5h3.2l1 3.3-2 1.2a12 12 0 006.8 6.8l1.2-2 3.3 1V17a1.5 1.5 0 01-1.5 1.5A15.5 15.5 0 016.5 8 1.5 1.5 0 018 6.5V3.5z" />
  </I>
);
export const IconCheck = (p: IconProps) => (
  <I {...p}>
    <path d="M5 12.5l4.2 4.2L19 7.5" />
  </I>
);
export const IconAlert = (p: IconProps) => (
  <I {...p}>
    <path d="M12 4l9 16H3L12 4z" />
    <path d="M12 10v4M12 16.5h.01" />
  </I>
);
export const IconMinus = (p: IconProps) => (
  <I {...p}>
    <path d="M6 12h12" />
  </I>
);
export const IconPlus = (p: IconProps) => (
  <I {...p}>
    <path d="M12 6v12M6 12h12" />
  </I>
);
export const IconCalendar = (p: IconProps) => (
  <I {...p}>
    <rect x="4" y="5" width="16" height="15" rx="2" />
    <path d="M8 3v4M16 3v4M4 10h16" />
  </I>
);
export const IconRefresh = (p: IconProps) => (
  <I {...p}>
    <path d="M20 12a8 8 0 10-2.2 5.5" />
    <path d="M20 12v-5h-5" />
  </I>
);
export const IconMenu = (p: IconProps) => (
  <I {...p}>
    <path d="M5 7h14M5 12h14M5 17h14" />
  </I>
);
export const IconX = (p: IconProps) => (
  <I {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </I>
);
export const IconSignal = (p: IconProps) => (
  <I {...p} strokeWidth={2.2}>
    <path d="M5 16v2M9 13v5M13 10v8M17 7v11" />
  </I>
);
export const IconWifi = (p: IconProps) => (
  <I {...p}>
    <path d="M5 10.5a10 10 0 0114 0M8 13.5a6 6 0 018 0M12 17h.01" />
  </I>
);
export const IconBattery = (p: IconProps) => (
  <I {...p}>
    <rect x="3" y="8" width="16" height="8" rx="1.6" />
    <path d="M20.5 10.5v3" />
  </I>
);
export const IconDatabase = (p: IconProps) => (
  <I {...p}>
    <ellipse cx="12" cy="6.5" rx="7" ry="2.5" />
    <path d="M5 6.5v11c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5v-11" />
    <path d="M5 12c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5" />
  </I>
);
export const IconFolder = (p: IconProps) => (
  <I {...p}>
    <path d="M3.5 8.5V18a2 2 0 002 2h13a2 2 0 002-2V10a2 2 0 00-2-2h-7l-2-2h-4a2 2 0 00-2 2.5z" />
  </I>
);
export const IconCloud = (p: IconProps) => (
  <I {...p}>
    <path d="M8 18h9a4 4 0 00.4-8 5.5 5.5 0 00-10.6 1.5A3.5 3.5 0 008 18z" />
  </I>
);
export const IconLock = (p: IconProps) => (
  <I {...p}>
    <rect x="6" y="11" width="12" height="9" rx="2" />
    <path d="M9 11V8a3 3 0 016 0v3" />
  </I>
);
export const IconShield = (p: IconProps) => (
  <I {...p}>
    <path d="M12 3.5l8 3.2v5.6c0 4.4-3.3 7.6-8 8.7-4.7-1.1-8-4.3-8-8.7V6.7L12 3.5z" />
    <path d="M9 12.2l2.1 2.1L15.4 10" />
  </I>
);

/** Courbe en dents de scie qui remonte vers la pointe de la flèche. */
export function LogoGlyph({
  size = 36,
  color = "#34d399",
}: {
  size?: number;
  color?: string;
}) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden>
      <path
        d="M6 36 L13 27 L19 32 L26 18 L31.5 23.5 L40 8"
        stroke={color}
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M32 8 H40 V16"
        stroke={color}
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      aria-label="MarketScope"
    >
      <rect width="48" height="48" rx="14" fill="#10283f" />
      <path
        d="M6 36 L13 27 L19 32 L26 18 L31.5 23.5 L40 8"
        stroke="#34d399"
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M32 8 H40 V16"
        stroke="#34d399"
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function BitcoinBadge() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#f7931a]">
      <span className="text-lg font-extrabold text-white">₿</span>
    </div>
  );
}
export function EthBadge() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#627eea]">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
        <path d="M12 2l-7 12 7 4 7-4-7-12zm0 20l-7-9 7 4 7-4-7 9z" />
      </svg>
    </div>
  );
}
export function SolBadge() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-[#00ffa3] to-[#dc1fff]">
      <span className="text-xs font-extrabold text-white">SOL</span>
    </div>
  );
}
export function FlagEU() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#003399] text-[11px] font-bold text-[#ffcc00]">
      EUR
    </div>
  );
}
export function FlagUK() {
  return (
    <div className="flex h-11 w-11 items-center justify-center overflow-hidden rounded-full bg-[#012169] text-[11px] font-bold text-white">
      GBP
    </div>
  );
}
export function AppleBadge() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1c1c1e]">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
        <path d="M16.7 12.4c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.2-2.8.9-3.5.9s-1.8-.8-3-.8c-1.5 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.3.8 1.1 1.7 2.3 2.9 2.3 1.2 0 1.6-.7 3-.7s1.8.7 3 .7 2-.1 2.9-2.3c.7-1.1 1-2.1 1-2.2-.1 0-2.3-.9-2.3-3.2zM14.8 6.3c.6-.8 1.1-1.8.9-2.9-1 .1-2.1.7-2.8 1.5-.6.7-1.2 1.8-.9 2.8 1.1.1 2.1-.6 2.8-1.4z" />
      </svg>
    </div>
  );
}
export function MsftBadge() {
  return (
    <div className="grid h-11 w-11 grid-cols-2 overflow-hidden rounded-full">
      <div className="bg-[#f25022]" />
      <div className="bg-[#7fba00]" />
      <div className="bg-[#00a4ef]" />
      <div className="bg-[#ffb900]" />
    </div>
  );
}
export function GoldBadge() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#c9a227] text-sm font-extrabold text-[#3a2a00]">
      Au
    </div>
  );
}
export function OilBadge() {
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#2b2b2b] text-lg">
      🛢
    </div>
  );
}

export function ProviderIcon({
  icon,
  color,
}: {
  icon: "yahoo" | "binance" | "kraken" | "iress" | "forex";
  color: string;
}) {
  const wrap = (child: ReactNode) => (
    <div
      className="flex h-11 w-11 items-center justify-center rounded-2xl"
      style={{ background: color }}
    >
      {child}
    </div>
  );
  if (icon === "yahoo")
    return wrap(
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M4 16l6-10 4 6" stroke="white" strokeWidth="2.2" strokeLinecap="round" />
        <path d="M14 8l6 10" stroke="white" strokeWidth="2.2" strokeLinecap="round" />
        <circle cx="10" cy="18" r="1.4" fill="white" />
      </svg>,
    );
  if (icon === "binance")
    return wrap(
      <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
        <path d="M12 3l3.2 3.2-3.2 3.2-3.2-3.2L12 3zm6.8 6.8L22 13l-3.2 3.2-3.2-3.2 3.2-3.2zM5.2 9.8l3.2 3.2-3.2 3.2L2 13l3.2-3.2zM12 14.6l3.2 3.2L12 21l-3.2-3.2L12 14.6zM12 9.2l3.2 3.2-3.2 3.2-3.2-3.2L12 9.2z" />
      </svg>,
    );
  if (icon === "kraken")
    return wrap(
      <span className="text-lg font-black text-white">m</span>,
    );
  if (icon === "iress")
    return wrap(
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8">
        <circle cx="12" cy="12" r="8" />
        <path d="M3 12h18M12 4c2.5 3 2.5 13 0 16M12 4c-2.5 3-2.5 13 0 16" />
      </svg>,
    );
  return wrap(
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
      <path d="M4 16l5-8 4 5 3-4 4 7" />
    </svg>,
  );
}
