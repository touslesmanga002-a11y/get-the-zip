import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";
import { IconChevronLeft, IconMenu, IconX } from "./Icons";
import { useApp } from "../context/AppContext";

/** Espace sûr en haut — plus de faux chrome iOS (heure / wifi / batterie). */
export function StatusBar() {
  return (
    <div
      className="h-[max(10px,env(safe-area-inset-top))] shrink-0"
      aria-hidden
    />
  );
}

function MenuButton() {
  const { navigate, screen, goBack } = useApp();
  const isMenu = screen === "menu";
  return (
    <button
      type="button"
      onClick={() => (isMenu ? goBack() : navigate("menu"))}
      className="z-10 flex h-10 w-10 items-center justify-center rounded-full text-white/90 active:bg-white/10"
      aria-label={isMenu ? "Fermer le menu" : "Menu"}
    >
      {isMenu ? <IconX size={20} /> : <IconMenu size={22} />}
    </button>
  );
}

export function Header({
  title,
  onBack,
  right,
  subtitle,
  center = true,
  showMenu = true,
}: {
  title: ReactNode;
  onBack?: () => void;
  right?: ReactNode;
  subtitle?: string;
  center?: boolean;
  showMenu?: boolean;
}) {
  return (
    <div className="relative flex min-h-12 shrink-0 items-center px-3 pt-1">
      {onBack ? (
        <button
          type="button"
          onClick={onBack}
          className="z-10 flex h-10 w-10 items-center justify-center rounded-full text-white/90 active:bg-white/10"
          aria-label="Retour"
        >
          <IconChevronLeft size={24} />
        </button>
      ) : (
        <div className="w-10" />
      )}
      <div className={cn("flex-1 px-1", center && "text-center")}>
        <h1 className="text-[17px] font-semibold leading-tight tracking-tight text-white">
          {title}
        </h1>
        {subtitle && (
          <p className="text-[11px] font-medium text-ms-muted">{subtitle}</p>
        )}
      </div>
      <div className="z-10 flex min-w-10 items-center justify-end">
        {right}
        {showMenu && <MenuButton />}
      </div>
    </div>
  );
}

export function StepBar({
  current,
  steps = ["Graphique", "Zone", "Analyse"],
}: {
  current: number;
  steps?: string[];
}) {
  return (
    <div className="grid grid-cols-3 gap-2 px-5 pb-2 pt-0.5">
      {steps.map((label, i) => (
        <div key={label} className="flex flex-col items-center gap-1">
          <div
            className={cn(
              "h-1 w-full rounded-full transition-colors",
              i <= current ? "bg-ms-teal" : "bg-white/10",
            )}
          />
          <span
            className={cn(
              "text-[10px] font-semibold tracking-wide",
              i === current ? "text-ms-teal" : "text-ms-muted",
            )}
          >
            {label}
          </span>
        </div>
      ))}
    </div>
  );
}

export function PrimaryButton({
  children,
  className,
  tone = "teal",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: "teal" | "blue" }) {
  return (
    <button
      type="button"
      className={cn(
        "h-12 w-full rounded-full text-[15px] font-semibold tracking-wide text-white shadow-lg transition active:scale-[0.98] disabled:opacity-50",
        tone === "teal" &&
          "bg-ms-teal text-[#06201c] shadow-ms-teal/20 hover:brightness-105",
        tone === "blue" && "bg-ms-blue shadow-ms-blue/25 hover:bg-ms-blue-2",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      className={cn(
        "h-12 rounded-full border border-ms-border-2 bg-transparent px-5 text-[15px] font-semibold text-white/90 transition active:scale-[0.98] active:bg-white/5",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function Card({
  children,
  className,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  const Comp = onClick ? "button" : "div";
  return (
    <Comp
      type={onClick ? "button" : undefined}
      onClick={onClick}
      className={cn(
        "rounded-2xl border border-white/5 bg-ms-card text-left",
        onClick && "active:bg-ms-card-2",
        className,
      )}
    >
      {children}
    </Comp>
  );
}

export function Segmented({
  options,
  value,
  onChange,
}: {
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex rounded-full bg-ms-elev p-1">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          className={cn(
            "h-9 flex-1 rounded-full text-[13px] font-semibold transition",
            value === o.id
              ? "bg-ms-blue text-white shadow"
              : "text-ms-muted",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn(
        "toggle-track relative h-7 w-12 shrink-0 rounded-full",
        checked ? "bg-ms-teal" : "bg-[#2a4258]",
      )}
    >
      <span
        className={cn(
          "toggle-thumb absolute top-0.5 h-6 w-6 rounded-full bg-white shadow",
          checked ? "left-[22px]" : "left-0.5",
        )}
      />
    </button>
  );
}

export function Stepper({
  value,
  onChange,
  min = 1,
  max = 5000,
  step = 10,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number;
  step?: number;
}) {
  return (
    <div className="flex items-center gap-3">
      <button
        type="button"
        className="flex h-8 w-8 items-center justify-center rounded-lg bg-ms-elev text-lg text-white"
        onClick={() => onChange(Math.max(min, value - step))}
      >
        −
      </button>
      <span className="min-w-10 text-center text-[15px] font-semibold tabular-nums">
        {value}
      </span>
      <button
        type="button"
        className="flex h-8 w-8 items-center justify-center rounded-lg bg-ms-elev text-lg text-white"
        onClick={() => onChange(Math.min(max, value + step))}
      >
        +
      </button>
    </div>
  );
}

export function RadioRow({
  checked,
  onChange,
  children,
  trailing,
}: {
  checked: boolean;
  onChange: () => void;
  children: ReactNode;
  trailing?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onChange}
      className="flex w-full items-center gap-3 rounded-2xl bg-ms-card px-4 py-3.5 text-left"
    >
      <span
        className={cn(
          "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2",
          checked ? "border-ms-teal" : "border-ms-muted-2",
        )}
      >
        {checked && <span className="h-2.5 w-2.5 rounded-full bg-ms-teal" />}
      </span>
      <span className="flex-1 text-[14px] font-medium text-white">{children}</span>
      {trailing}
    </button>
  );
}

export function CheckRow({
  checked,
  onChange,
  children,
}: {
  checked: boolean;
  onChange: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onChange}
      className="flex w-full items-center gap-3 py-2.5 text-left"
    >
      <span
        className={cn(
          "flex h-5 w-5 items-center justify-center rounded-md border",
          checked
            ? "border-ms-teal bg-ms-teal text-[#06201c]"
            : "border-ms-muted-2 bg-transparent",
        )}
      >
        {checked && (
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
            <path d="M5 12.5l4.2 4.2L19 7.5" />
          </svg>
        )}
      </span>
      <span className="text-[14px] font-medium text-white">{children}</span>
    </button>
  );
}

export function Screen({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex min-h-0 flex-1 flex-col", className)}>{children}</div>
  );
}

export function Scroll({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("ms-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-6", className)}>
      {children}
    </div>
  );
}

export function BottomBar({ children }: { children: ReactNode }) {
  return (
    <div className="shrink-0 px-4 pb-[max(16px,env(safe-area-inset-bottom))] pt-2">
      {children}
    </div>
  );
}

export function DemoChip() {
  return (
    <span className="rounded-full bg-ms-teal/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-ms-teal">
      Démo
    </span>
  );
}

export function Toast({ message }: { message: string }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-24 z-50 flex justify-center px-6">
      <div className="rounded-full bg-[#14324c] px-4 py-2.5 text-center text-[13px] font-medium text-white shadow-xl ring-1 ring-white/10">
        {message}
      </div>
    </div>
  );
}
