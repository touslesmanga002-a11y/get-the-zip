import { useEffect, useState } from "react";
import { IconCheck } from "../components/Icons";
import {
  BottomBar,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  StatusBar,
  StepBar,
} from "../components/ui";
import { MOCK_SYNC_STEPS } from "../data/mock";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import { cn } from "../utils/cn";

export function SyncScreen() {
  const { goBack, navigate, selectedAsset, patternRange, period, settings, setMatches } =
    useApp();
  const steps = MOCK_SYNC_STEPS;
  const [progress, setProgress] = useState(8);
  const [doneStep, setDoneStep] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let p = 8;
    let s = 0;
    const id = window.setInterval(() => {
      p += 9;
      if (p >= 100) {
        p = 100;
        s = steps.length;
        setProgress(100);
        setDoneStep(steps.length);
        setDone(true);
        window.clearInterval(id);
        return;
      }
      s = Math.min(steps.length, Math.floor((p / 100) * steps.length) + 1);
      setProgress(p);
      setDoneStep(s);
    }, 280);
    return () => window.clearInterval(id);
  }, [steps.length]);

  const continueFlow = async () => {
    const matches = await marketApi.searchMatches({
      assetId: selectedAsset.id,
      range: patternRange,
      period,
      settings,
    });
    setMatches(matches);
    navigate("matches");
  };

  return (
    <Screen>
      <StatusBar />
      <Header
        title="Recherche historique"
        subtitle={done ? "Terminée" : "En cours"}
        onBack={goBack}
      />
      <StepBar current={2} />
      <Scroll>
        <div className="rounded-2xl bg-ms-card p-4">
          <div className="mb-3 flex items-center gap-3">
            <span
              className={cn(
                "flex h-9 w-9 items-center justify-center rounded-full",
                done ? "bg-ms-green text-[#06201c]" : "bg-ms-teal/20 text-ms-teal",
              )}
            >
              <IconCheck size={18} />
            </span>
            <div className="flex-1">
              <div className="flex items-center justify-between text-[13px] font-medium">
                <span>Progression</span>
                <span className="tabular-nums text-ms-teal">{Math.round(progress)}%</span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-[#1a334c]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-ms-teal-dim to-ms-teal transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>

          <ul className="mt-4 space-y-3">
            {steps.map((st, i) => {
              const ok = i < doneStep;
              return (
                <li key={st.id} className="flex items-center gap-3 text-[14px]">
                  <span
                    className={cn(
                      "flex h-6 w-6 items-center justify-center rounded-full",
                      ok ? "bg-ms-green text-[#06201c]" : "bg-ms-elev text-ms-muted",
                    )}
                  >
                    {ok ? <IconCheck size={14} /> : <span className="h-2 w-2 rounded-full bg-ms-muted" />}
                  </span>
                  <span className={ok ? "text-white" : "text-ms-muted"}>{st.label}</span>
                </li>
              );
            })}
          </ul>
        </div>

        <p className="mt-6 px-1 text-[13px] leading-relaxed text-ms-muted">
          {done
            ? "La zone sélectionnée a été comparée à l'historique. 8 correspondances sont prêtes."
            : "Indexation des séries et calcul de similarité (données de présentation)."}
        </p>
      </Scroll>
      <BottomBar>
        {done ? (
          <PrimaryButton onClick={continueFlow}>Voir les correspondances</PrimaryButton>
        ) : (
          <PrimaryButton onClick={goBack}>Annuler</PrimaryButton>
        )}
      </BottomBar>
    </Screen>
  );
}
