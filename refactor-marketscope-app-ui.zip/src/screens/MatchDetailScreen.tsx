import { CandlestickChart } from "../components/CandlestickChart";
import { Header, Screen, Scroll, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import { formatScore } from "../utils/format";
import { cn } from "../utils/cn";

const TABS = [
  { id: "vue", label: "Vue" },
  { id: "details", label: "Détails" },
  { id: "evolution", label: "Évolution" },
] as const;

export function MatchDetailScreen() {
  const { goBack, navigate, selectedMatch, candles, matchTab, setMatchTab } = useApp();
  const m = selectedMatch;
  const scoreLabel =
    m.score >= 9 ? "Excellente correspondance" : m.score >= 8 ? "Bonne correspondance" : "Correspondance acceptable";

  return (
    <Screen>
      <StatusBar />
      <Header title={`Correspondance #${m.rank}`} onBack={goBack} />
      <Scroll>
        <div className="flex flex-col items-center pt-1">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <path d="M5 12.5l4.2 4.2L19 7.5" />
              </svg>
            </span>
            <span className="text-[34px] font-extrabold tabular-nums tracking-tight text-ms-green">
              {formatScore(m.score)}
              <span className="text-[16px] font-semibold text-ms-muted"> /10</span>
            </span>
          </div>
          <p className="mt-0.5 text-[13px] font-medium text-ms-green">{scoreLabel}</p>
        </div>

        <div className="mt-4 flex rounded-full bg-ms-elev p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setMatchTab(t.id)}
              className={cn(
                "h-9 flex-1 rounded-full text-[13px] font-semibold",
                matchTab === t.id ? "bg-ms-blue text-white" : "text-ms-muted",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {matchTab === "vue" && (
          <div className="mt-4">
            <div className="rounded-2xl bg-ms-card p-2">
              <CandlestickChart
                candles={m.candlesData}
                overlay={alignOverlay(
                  candles.slice(-m.candlesData.length),
                  m.candlesData,
                )}
                height={220}
                showVolume={false}
                dates={["12 fév.", "14 fév.", "16 fév.", "18 fév."]}
              />
            </div>
            <h3 className="mt-5 text-[15px] font-semibold">Points forts</h3>
            <ul className="mt-2 space-y-2.5">
              {m.strengths.map((s) => (
                <li key={s} className="flex items-start gap-2.5 text-[13px] text-white/90">
                  <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <path d="M5 12.5l4.2 4.2L19 7.5" />
                    </svg>
                  </span>
                  {s}
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => navigate("scenarios")}
              className="mt-6 w-full text-center text-[13px] font-semibold text-ms-teal"
            >
              Voir les prolongements historiques →
            </button>
          </div>
        )}

        {matchTab === "details" && (
          <div className="mt-4 space-y-3">
            <Row k="Date" v={m.date} />
            <Row k="Bougies comparées" v={`${m.candles}`} />
            <Row k="Direction historique" v={m.direction === "bullish" ? "Haussière" : m.direction === "bearish" ? "Baissière" : "Neutre"} />
            <Row k="Volume" v={m.volumeTrend === "up" ? "En hausse" : m.volumeTrend === "down" ? "En baisse" : "Stable"} />
            <Row k="Score structure" v="9,4 / 10" />
            <Row k="Score amplitude" v="9,1 / 10" />
            <Row k="Score volume" v="9,8 / 10" />
            <p className="pt-2 text-[11px] text-ms-muted-2">
              Métriques calculées sur données de démonstration.
            </p>
          </div>
        )}

        {matchTab === "evolution" && (
          <div className="mt-4">
            <p className="text-[13px] leading-relaxed text-ms-muted">
              Après cette correspondance, le marché a poursuivi dans la direction
              indiquée dans 68 % des cas similaires. Consultez les scénarios pour
              les horizons de temps.
            </p>
            <button
              type="button"
              onClick={() => navigate("scenarios")}
              className="mt-4 h-11 w-full rounded-full bg-ms-teal text-[14px] font-semibold text-[#06201c]"
            >
              Scénarios et prolongements
            </button>
          </div>
        )}
      </Scroll>
    </Screen>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-ms-card px-4 py-3">
      <span className="text-[13px] text-ms-muted">{k}</span>
      <span className="text-[13px] font-semibold text-white">{v}</span>
    </div>
  );
}

/** Aligne deux séries sur la même échelle pour le superposé de démo. */
function alignOverlay(
  overlay: { open: number; high: number; low: number; close: number; volume: number; time: number }[],
  base: { open: number; high: number; low: number; close: number }[],
) {
  if (!overlay.length || !base.length) return overlay;
  const b0 = base[0].open;
  const o0 = overlay[0].open || 1;
  const factor = b0 / o0;
  return overlay.map((c) => ({
    ...c,
    open: c.open * factor,
    high: c.high * factor,
    low: c.low * factor,
    close: c.close * factor,
  }));
}
