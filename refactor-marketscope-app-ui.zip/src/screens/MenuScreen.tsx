import {
  IconAnalyze,
  IconBacktest,
  IconBars,
  IconBook,
  IconChevronRight,
  IconClock,
  IconExport,
  IconGear,
  IconHome,
  IconLineChart,
  IconX,
  LogoMark,
} from "../components/Icons";
import { Screen, Scroll, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import { APP_VERSION } from "../data/mock";
import type { ScreenId } from "../types";
import type { ReactNode } from "react";

const GROUPS: { title: string; items: { id: ScreenId; label: string; icon: ReactNode }[] }[] = [
  {
    title: "Analyse",
    items: [
      { id: "assets", label: "Marchés", icon: <IconHome size={20} /> },
      { id: "chart", label: "Graphique en cours", icon: <IconAnalyze size={20} /> },
      { id: "matches", label: "Correspondances", icon: <IconClock size={20} /> },
    ],
  },
  {
    title: "Lecture des résultats",
    items: [
      { id: "scenarios", label: "Scénarios", icon: <IconLineChart size={20} /> },
      { id: "conditions", label: "Conditions & alertes", icon: <IconBars size={20} /> },
      { id: "backtest", label: "Backtest", icon: <IconBacktest size={20} /> },
    ],
  },
  {
    title: "Application",
    items: [
      { id: "settings", label: "Paramètres", icon: <IconGear size={20} /> },
      { id: "export", label: "Exporter", icon: <IconExport size={20} /> },
      { id: "help", label: "Aide", icon: <IconBook size={20} /> },
    ],
  },
];

export function MenuScreen() {
  const { navigateFromMenu, goBack, selectedAsset } = useApp();

  return (
    <Screen>
      <StatusBar />
      <div className="flex items-center gap-2 px-4 py-3">
        <LogoMark size={32} />
        <div className="flex-1">
          <h1 className="text-[18px] font-semibold leading-tight">MarketScope</h1>
          <p className="text-[11px] text-ms-muted">{selectedAsset.pairLabel} · menu</p>
        </div>
        <button
          type="button"
          onClick={goBack}
          className="flex h-10 w-10 items-center justify-center rounded-full text-white/80 active:bg-white/10"
          aria-label="Fermer le menu"
        >
          <IconX size={20} />
        </button>
      </div>
      <Scroll>
        {GROUPS.map((g) => (
          <section key={g.title} className="mb-4">
            <h2 className="mb-1.5 px-1 text-[11px] font-semibold uppercase tracking-wider text-ms-muted">
              {g.title}
            </h2>
            <div className="overflow-hidden rounded-2xl bg-ms-card">
              {g.items.map((it, i) => (
                <button
                  key={it.id}
                  type="button"
                  onClick={() => navigateFromMenu(it.id)}
                  className={`flex w-full items-center gap-3 px-4 py-3.5 text-left ${
                    i < g.items.length - 1 ? "border-b border-white/5" : ""
                  }`}
                >
                  <span className="text-ms-muted">{it.icon}</span>
                  <span className="flex-1 text-[14px]">{it.label}</span>
                  <IconChevronRight size={18} className="text-ms-muted" />
                </button>
              ))}
            </div>
          </section>
        ))}
        <p className="pb-2 text-center text-[11px] text-ms-muted-2">
          MarketScope {APP_VERSION} · présentation
        </p>
      </Scroll>
    </Screen>
  );
}
