import { CandlestickChart } from "../components/CandlestickChart";
import {
  BottomBar,
  GhostButton,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  Segmented,
  StatusBar,
  StepBar,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";

export function PatternScreen() {
  const {
    goBack,
    navigate,
    candles,
    patternRange,
    setPatternRange,
    selectionMode,
    setSelectionMode,
    selectedAsset,
  } = useApp();

  const reset = async () => {
    const range = await marketApi.detectPattern(candles);
    setPatternRange(range);
    setSelectionMode("auto");
  };

  const count = patternRange.endIndex - patternRange.startIndex + 1;

  const onMode = async (id: string) => {
    const mode = id as "auto" | "manual";
    setSelectionMode(mode);
    if (mode === "auto") {
      const range = await marketApi.detectPattern(candles);
      setPatternRange(range);
    }
  };

  return (
    <Screen>
      <StatusBar />
      <Header title="Zone à analyser" subtitle={selectedAsset.pairLabel} onBack={goBack} />
      <StepBar current={1} />
      <div className="px-4 pb-2">
        <Segmented
          value={selectionMode}
          onChange={onMode}
          options={[
            { id: "auto", label: "Auto" },
            { id: "manual", label: "Manuel" },
          ]}
        />
      </div>
      <Scroll>
        <div className="rounded-2xl bg-ms-card/70 p-2">
          <CandlestickChart
            candles={candles}
            height={268}
            showVolume={false}
            selection={patternRange}
            onSelectionChange={setPatternRange}
            interactive
          />
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-[11px] text-ms-muted">
          <span>↔ Étirez les bords</span>
          <span>✥ Glissez la zone</span>
          <span>+ Tracez ailleurs</span>
        </div>
        <p className="mt-4 px-2 text-center text-[13px] leading-relaxed text-ms-muted">
          {selectionMode === "auto" ? (
            <>
              Pattern détecté sur{" "}
              <span className="font-semibold text-white">{count} bougies</span>. Ajustez la
              zone verte, puis lancez la recherche historique.
            </>
          ) : (
            <>
              Mode manuel — déplacez, redimensionnez ou tracez une nouvelle zone (
              <span className="font-semibold text-white">{count} bougies</span>).
            </>
          )}
        </p>
      </Scroll>
      <BottomBar>
        <div className="flex gap-3">
          <GhostButton className="flex-1" onClick={reset}>
            Réinitialiser
          </GhostButton>
          <PrimaryButton className="flex-1" onClick={() => navigate("sync")}>
            Lancer la recherche
          </PrimaryButton>
        </div>
      </BottomBar>
    </Screen>
  );
}
