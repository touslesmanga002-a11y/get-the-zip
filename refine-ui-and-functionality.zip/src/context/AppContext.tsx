import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { MOCK_ASSETS, MOCK_BTC_CANDLES, MOCK_MATCHES } from "../data/mock";
import type {
  AnalysisRecord,
  AppSettings,
  Asset,
  AssetCategory,
  Candle,
  ExportConfig,
  PatternMatch,
  PatternRange,
  PeriodConfig,
  ScreenId,
  SelectionMode,
  Timeframe,
} from "../types";

interface Toast {
  id: number;
  message: string;
}

interface NavEntry {
  screen: ScreenId;
  articleId?: string;
}

interface AppState {
  stack: NavEntry[];
  screen: ScreenId;
  articleId?: string;
  direction: "fwd" | "back";
  categoryFilter: AssetCategory | "all";
  selectedAsset: Asset;
  timeframe: Timeframe;
  selectionMode: SelectionMode;
  patternRange: PatternRange;
  candles: Candle[];
  matches: PatternMatch[];
  selectedMatch: PatternMatch;
  matchTab: "vue" | "details";
  settings: AppSettings;
  period: PeriodConfig;
  exportConfig: ExportConfig;
  favorite: boolean;
  toast: Toast | null;
  demoBanner: boolean;
  analysisHistory: AnalysisRecord[];
  backtestAsset: Asset | null;
  backtestFromChart: boolean;
}

interface AppContextValue extends AppState {
  navigate: (screen: ScreenId, extra?: { articleId?: string }) => void;
  goBack: () => void;
  resetTo: (screen: ScreenId) => void;
  goHome: () => void;
  navigateFromMenu: (screen: ScreenId, extra?: { articleId?: string }) => void;
  canGoBack: boolean;
  setCategoryFilter: (c: AssetCategory | "all") => void;
  setSelectedAsset: (a: Asset) => void;
  setTimeframe: (t: Timeframe) => void;
  setSelectionMode: (m: SelectionMode) => void;
  setPatternRange: (r: PatternRange) => void;
  setCandles: (c: Candle[]) => void;
  setMatches: (m: PatternMatch[]) => void;
  setSelectedMatch: (m: PatternMatch) => void;
  setMatchTab: (t: "vue" | "details") => void;
  setSettings: (s: AppSettings | ((p: AppSettings) => AppSettings)) => void;
  setPeriod: (p: PeriodConfig | ((prev: PeriodConfig) => PeriodConfig)) => void;
  setExportConfig: (e: ExportConfig | ((p: ExportConfig) => ExportConfig)) => void;
  setFavorite: (v: boolean) => void;
  showToast: (message: string) => void;
  hideToast: () => void;
  dismissDemoBanner: () => void;
  addAnalysisRecord: (r: Omit<AnalysisRecord, "id" | "at">) => void;
  setBacktestAsset: (a: Asset | null) => void;
  setBacktestFromChart: (v: boolean) => void;
  openBacktest: (fromChart: boolean) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const defaultSettings: AppSettings = {
  mode: "auto",
  cloudflare: true,
  directProviders: true,
  localFolder: false,
  granularity: "1h",
  resultCount: 20,
  searchLimit: 500,
};

const defaultPeriod: PeriodConfig = {
  kind: "lastCandles",
  candleCount: 500,
  start: "2024-01-01",
  end: "2025-04-25",
  since: "2024-01-01",
};

const defaultExport: ExportConfig = {
  format: "pdf",
  includeCharts: true,
  includeMatches: true,
  includeScenarios: true,
  includeSettings: true,
};

const HISTORY_KEY = "ms-analysis-history";

function loadHistory(): AnalysisRecord[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as AnalysisRecord[]) : [];
  } catch {
    return [];
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<NavEntry[]>([{ screen: "welcome" }]);
  const [direction, setDirection] = useState<"fwd" | "back">("fwd");
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | "all">("all");
  const [selectedAsset, setSelectedAsset] = useState<Asset>(MOCK_ASSETS[0]);
  const [timeframe, setTimeframe] = useState<Timeframe>("1h");
  const [selectionMode, setSelectionMode] = useState<SelectionMode>("auto");
  const [patternRange, setPatternRange] = useState<PatternRange>({
    startIndex: 64,
    endIndex: 88,
  });
  const [candles, setCandles] = useState<Candle[]>(MOCK_BTC_CANDLES);
  const [matches, setMatches] = useState<PatternMatch[]>(MOCK_MATCHES);
  const [selectedMatch, setSelectedMatch] = useState<PatternMatch>(MOCK_MATCHES[0]);
  const [matchTab, setMatchTab] = useState<"vue" | "details">("vue");
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [period, setPeriod] = useState<PeriodConfig>(defaultPeriod);
  const [exportConfig, setExportConfig] = useState<ExportConfig>(defaultExport);
  const [favorite, setFavorite] = useState(true);
  const [toast, setToast] = useState<Toast | null>(null);
  const [demoBanner, setDemoBanner] = useState(true);
  const [analysisHistory, setAnalysisHistory] = useState<AnalysisRecord[]>(loadHistory);
  const [backtestAsset, setBacktestAsset] = useState<Asset | null>(MOCK_ASSETS[0]);
  const [backtestFromChart, setBacktestFromChart] = useState(false);

  const current = stack[stack.length - 1];

  const navigate = useCallback((screen: ScreenId, extra?: { articleId?: string }) => {
    setDirection("fwd");
    setStack((s) => [...s, { screen, articleId: extra?.articleId }]);
  }, []);

  const goBack = useCallback(() => {
    setDirection("back");
    setStack((s) => (s.length > 1 ? s.slice(0, -1) : s));
  }, []);

  const resetTo = useCallback((screen: ScreenId) => {
    setDirection("fwd");
    setStack([{ screen }]);
  }, []);

  const goHome = useCallback(() => {
    setDirection("back");
    setStack([{ screen: "assets" }]);
  }, []);

  const navigateFromMenu = useCallback((screen: ScreenId, extra?: { articleId?: string }) => {
    setDirection("fwd");
    setStack((s) => {
      if (screen === "assets") return [{ screen: "assets" }];
      if (screen === "chart") {
        const withoutMenu = s.filter((e) => e.screen !== "menu");
        const last = withoutMenu[withoutMenu.length - 1];
        if (last?.screen === "chart") return withoutMenu.length ? withoutMenu : [{ screen: "chart" as const }];
        const base: NavEntry[] = withoutMenu.length ? withoutMenu : [{ screen: "assets" }];
        return [...base, { screen: "chart" }];
      }
      const last = s[s.length - 1];
      if (last?.screen === screen) return s;
      return [...s, { screen, articleId: extra?.articleId }];
    });
  }, []);

  const showToast = useCallback((message: string) => {
    const id = Date.now();
    setToast({ id, message });
    window.setTimeout(() => {
      setToast((t) => (t?.id === id ? null : t));
    }, 2600);
  }, []);

  const addAnalysisRecord = useCallback((r: Omit<AnalysisRecord, "id" | "at">) => {
    const rec: AnalysisRecord = {
      ...r,
      id: `a-${Date.now()}`,
      at: Date.now(),
    };
    setAnalysisHistory((prev) => {
      const next = [rec, ...prev].slice(0, 40);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const openBacktest = useCallback(
    (fromChart: boolean) => {
      setBacktestFromChart(fromChart);
      setBacktestAsset(fromChart ? selectedAsset : null);
      if (fromChart) navigate("backtest");
      else navigateFromMenu("backtest");
    },
    [navigate, navigateFromMenu, selectedAsset],
  );

  const value = useMemo<AppContextValue>(
    () => ({
      stack,
      screen: current.screen,
      articleId: current.articleId,
      direction,
      categoryFilter,
      selectedAsset,
      timeframe,
      selectionMode,
      patternRange,
      candles,
      matches,
      selectedMatch,
      matchTab,
      settings,
      period,
      exportConfig,
      favorite,
      toast,
      demoBanner,
      analysisHistory,
      backtestAsset,
      backtestFromChart,
      navigate,
      goBack,
      resetTo,
      goHome,
      navigateFromMenu,
      canGoBack: stack.length > 1,
      setCategoryFilter,
      setSelectedAsset,
      setTimeframe,
      setSelectionMode,
      setPatternRange,
      setCandles,
      setMatches,
      setSelectedMatch,
      setMatchTab,
      setSettings,
      setPeriod,
      setExportConfig,
      setFavorite,
      showToast,
      hideToast: () => setToast(null),
      dismissDemoBanner: () => setDemoBanner(false),
      addAnalysisRecord,
      setBacktestAsset,
      setBacktestFromChart,
      openBacktest,
    }),
    [
      stack,
      current,
      direction,
      categoryFilter,
      selectedAsset,
      timeframe,
      selectionMode,
      patternRange,
      candles,
      matches,
      selectedMatch,
      matchTab,
      settings,
      period,
      exportConfig,
      favorite,
      toast,
      demoBanner,
      analysisHistory,
      backtestAsset,
      backtestFromChart,
      navigate,
      goBack,
      resetTo,
      goHome,
      navigateFromMenu,
      showToast,
      addAnalysisRecord,
      openBacktest,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

/** Empêche le zoom navigateur et intercepte le bouton retour matériel. */
export function NavigationGuard() {
  const { goBack } = useApp();

  useEffect(() => {
    window.history.pushState({ ms: 1 }, "");
    const onPop = () => {
      goBack();
      window.history.pushState({ ms: 1 }, "");
    };
    window.addEventListener("popstate", onPop);

    const preventGesture = (e: Event) => e.preventDefault();
    document.addEventListener("gesturestart", preventGesture, { passive: false });
    document.addEventListener("gesturechange", preventGesture, { passive: false });
    document.addEventListener("gestureend", preventGesture, { passive: false });

    const preventPinch = (e: TouchEvent) => {
      if (e.touches.length > 1) e.preventDefault();
    };
    document.addEventListener("touchmove", preventPinch, { passive: false });

    const preventDbl = (e: MouseEvent) => e.preventDefault();
    document.addEventListener("dblclick", preventDbl);

    const preventWheelZoom = (e: WheelEvent) => {
      if (e.ctrlKey) e.preventDefault();
    };
    document.addEventListener("wheel", preventWheelZoom, { passive: false });

    return () => {
      window.removeEventListener("popstate", onPop);
      document.removeEventListener("gesturestart", preventGesture);
      document.removeEventListener("gesturechange", preventGesture);
      document.removeEventListener("gestureend", preventGesture);
      document.removeEventListener("touchmove", preventPinch);
      document.removeEventListener("dblclick", preventDbl);
      document.removeEventListener("wheel", preventWheelZoom);
    };
  }, [goBack]);

  return null;
}
