import { CandlestickChart } from "../components/CandlestickChart";
import {
  BottomBar,
  GhostButton,
  Header,
  PeriodPicker,
  PrimaryButton,
  Screen,
  Scroll,
  Segmented,
  StatusBar,
  StepBar,
  Stepper,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { PatternRange } from "../types";

export function PatternScreen() {
  const {
    goBack,
    navigate,
    candles,
    patternRange,
    setPatternRange,
    selectionMode,
    setSelectionMode,
    selectedAsset,
    period,
    setPeriod,
  } = useApp();

  const reset = async () => {
    const range = await marketApi.detectPattern(candles);
    setPatternRange(range);
    setSelectionMode("auto");
  };

  const count = patternRange.endIndex - patternRange.startIndex + 1;

  const onMode = async (id: string) => {
    const mode = id as "auto" | "manual";
    setSelectionMode(mode);
    if (mode === "auto") {
      const range = await marketApi.detectPattern(candles);
      setPatternRange(range);
    }
  };

  const onSelectionChange = (r: PatternRange) => {
    if (selectionMode === "auto") setSelectionMode("manual");
    setPatternRange(r);
  };

  const setCount = (n: number) => {
    const next = Math.max(4, Math.min(candles.length, n));
    const end = patternRange.endIndex;
    let start = end - next + 1;
    if (start < 0) {
      setPatternRange({ startIndex: 0, endIndex: Math.min(candles.length - 1, next - 1) });
      return;
    }
    setPatternRange({ startIndex: start, endIndex: end });
    if (selectionMode === "auto") setSelectionMode("manual");
  };

  return (
    <Screen>
      <StatusBar />
      <Header title="Zone à analyser" subtitle={selectedAsset.pairLabel} onBack={goBack} />
      <StepBar current={1} />
      <div className="px-4 pb-2">
        <Segmented
          value={selectionMode}
          onChange={onMode}
          options={[
            { id: "auto", label: "Auto" },
            { id: "manual", label: "Manuel" },
          ]}
        />
      </div>
      <Scroll>
        <div className="rounded-2xl bg-ms-card/70 p-2">
          <CandlestickChart
            candles={candles}
            height={268}
            showVolume={false}
            selection={patternRange}
            onSelectionChange={onSelectionChange}
            interactive
          />
        </div>

        {selectionMode === "manual" && (
          <div className="mt-3 flex items-center justify-between rounded-2xl bg-ms-card px-4 py-3">
            <span className="text-[14px] font-medium">Nombre de bougies</span>
            <Stepper value={count} onChange={setCount} min={4} max={candles.length} step={1} />
          </div>
        )}

        <div className="mt-4">
          <PeriodPicker period={period} onChange={setPeriod} />
        </div>
      </Scroll>
      <BottomBar>
        <div className="flex gap-3">
          <GhostButton className="flex-1" onClick={reset}>
            Réinitialiser
          </GhostButton>
          <PrimaryButton className="flex-1" onClick={() => navigate("sync")}>
            Lancer la recherche
          </PrimaryButton>
        </div>
      </BottomBar>
    </Screen>
  );
}
