import { IconBars, IconExport, IconLineChart } from "../components/Icons";
import {
  Header,
  MenuListButton,
  Screen,
  Scroll,
  StatusBar,
  Stepper,
} from "../components/ui";
import { MOCK_OUTCOME, MOCK_SCENARIOS } from "../data/mock";
import { useApp } from "../context/AppContext";
import { directionLabel } from "../utils/format";
import { cn } from "../utils/cn";
import type { Direction, Timeframe } from "../types";
import { TIMEFRAME_LABELS, TIMEFRAMES } from "../types";

function DirIcon({ d }: { d: Direction }) {
  const color =
    d === "bullish" ? "text-ms-green bg-ms-green/15" : d === "bearish" ? "text-ms-red bg-ms-red/15" : "text-ms-muted bg-white/10";
  return (
    <span className={cn("flex h-6 w-6 items-center justify-center rounded-full", color)}>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
        <path d="M5 12.5l4.2 4.2L19 7.5" />
      </svg>
    </span>
  );
}

export function ScenariosScreen() {
  const { goBack, navigate, settings, setSettings } = useApp();
  const outcome = MOCK_OUTCOME;
  const scenarios = MOCK_SCENARIOS;

  return (
    <Screen>
      <StatusBar />
      <Header title="Résultats estimés" onBack={goBack} />
      <Scroll>
        <p className="text-[13px] text-ms-muted">Ce que l'algorithme anticipe pour la suite :</p>
        <div className="mt-3 flex gap-3">
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-ms-card px-3 py-3">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ms-green/15 text-ms-green">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <path d="M5 12.5l4.2 4.2L19 7.5" />
              </svg>
            </span>
            <span className="text-[22px] font-bold text-ms-green">{outcome.bullish}%</span>
            <span className="text-[13px] text-ms-muted">hausse</span>
          </div>
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-ms-card px-3 py-3">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ms-red/15 text-ms-red">
              <span className="text-xs">●</span>
            </span>
            <span className="text-[22px] font-bold text-ms-red">{outcome.bearish}%</span>
            <span className="text-[13px] text-ms-muted">baisse</span>
          </div>
        </div>

        <h3 className="mt-6 text-[15px] font-semibold">Scénarios probabilistes</h3>
        <div className="mt-3 space-y-2.5">
          {scenarios.map((s) => (
            <div key={s.id} className="rounded-2xl bg-ms-card px-4 py-3.5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[14px] font-semibold text-white">{s.horizon}</div>
                  <div className="text-[11px] text-ms-muted">({s.rangeLabel})</div>
                </div>
                <div className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <DirIcon d={s.direction} />
                    <span
                      className={cn(
                        "text-[13px] font-semibold",
                        s.direction === "bullish"
                          ? "text-ms-green"
                          : s.direction === "bearish"
                            ? "text-ms-red"
                            : "text-ms-muted",
                      )}
                    >
                      {directionLabel(s.direction)}
                    </span>
                    <span className="text-[16px] font-bold tabular-nums text-white">
                      {s.probability}%
                    </span>
                  </div>
                  <div className="mt-0.5 text-[11px] text-ms-muted">
                    ±{s.deviation.toLocaleString("fr-FR")} %
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 overflow-hidden rounded-2xl bg-ms-card">
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[14px]">Granularité</span>
            <select
              value={settings.granularity}
              onChange={(e) =>
                setSettings((s) => ({ ...s, granularity: e.target.value as Timeframe }))
              }
              className="rounded-lg bg-ms-elev px-3 py-1.5 text-[13px] text-white outline-none"
            >
              {TIMEFRAMES.map((t) => (
                <option key={t} value={t}>
                  {TIMEFRAME_LABELS[t]}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center justify-between border-t border-white/5 px-4 py-3.5">
            <span className="text-[14px]">Nombre de résultats</span>
            <Stepper
              value={settings.resultCount}
              onChange={(n) => setSettings((s) => ({ ...s, resultCount: n }))}
              min={5}
              max={100}
              step={5}
            />
          </div>
          <div className="flex items-center justify-between border-t border-white/5 px-4 py-3.5">
            <span className="text-[14px]">Limite de recherche</span>
            <div className="flex items-center gap-2">
              <Stepper
                value={settings.searchLimit}
                onChange={(n) => setSettings((s) => ({ ...s, searchLimit: n }))}
                min={100}
                max={5000}
                step={50}
              />
              <span className="text-[11px] text-ms-muted">bougies</span>
            </div>
          </div>
        </div>

        <div className="mt-5 overflow-hidden rounded-2xl bg-ms-card">
          <MenuListButton
            icon={<IconLineChart size={20} />}
            label="Scénarios"
            onClick={() => navigate("matches")}
          />
          <MenuListButton
            icon={<IconBars size={20} />}
            label="Conditions et alertes"
            onClick={() => navigate("conditions")}
          />
          <MenuListButton
            icon={<IconExport size={20} />}
            label="Exporter"
            onClick={() => navigate("export")}
            last
          />
        </div>
      </Scroll>
    </Screen>
  );
}
