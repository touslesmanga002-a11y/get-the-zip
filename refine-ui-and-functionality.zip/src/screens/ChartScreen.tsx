import { CandlestickChart } from "../components/CandlestickChart";
import { IconBacktest, IconStar } from "../components/Icons";
import {
  BottomBar,
  GhostButton,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  Segmented,
  StatusBar,
  StepBar,
} from "../components/ui";
import { useApp } from "../context/AppContext";
import { marketApi } from "../services/api";
import type { Timeframe } from "../types";
import { TIMEFRAME_LABELS, TIMEFRAMES } from "../types";
import { formatPct, formatPrice } from "../utils/format";
import { cn } from "../utils/cn";

export function ChartScreen() {
  const {
    goBack,
    navigate,
    selectedAsset,
    timeframe,
    setTimeframe,
    setCandles,
    candles,
    setSelectionMode,
    setPatternRange,
    favorite,
    setFavorite,
    openBacktest,
  } = useApp();

  const a = selectedAsset;
  const up = a.change24h >= 0;
  const suffix = a.quote ? " $" : "";

  const changeTf = async (tf: Timeframe) => {
    setTimeframe(tf);
    const data = await marketApi.getCandles(a.id, tf);
    setCandles(data);
  };

  const launch = async () => {
    const range = await marketApi.detectPattern(candles);
    setPatternRange(range);
    setSelectionMode("auto");
    navigate("pattern");
  };

  return (
    <Screen>
      <StatusBar />
      <Header
        title={
          <span className="inline-flex items-center gap-1.5">
            {a.pairLabel}
            <button
              type="button"
              onClick={() => setFavorite(!favorite)}
              className="text-ms-gold"
              aria-label="Favori"
            >
              <IconStar size={16} filled={favorite} />
            </button>
          </span>
        }
        onBack={goBack}
        center={false}
      />
      <StepBar current={0} />
      <Scroll className="pt-0">
        <p className="px-1 text-[12px] text-ms-muted">{a.exchange}</p>
        <div className="mt-1 flex items-end justify-between px-1">
          <div className="text-[28px] font-bold tabular-nums tracking-tight text-white">
            {formatPrice(a.price, a.decimals, suffix)}
          </div>
          <div
            className={cn(
              "mb-1 text-[13px] font-semibold",
              up ? "text-ms-green" : "text-ms-red",
            )}
          >
            {formatPct(a.change24h)} <span className="text-ms-muted">(24h)</span>
          </div>
        </div>

        <div className="mt-3">
          <Segmented
            size="sm"
            value={timeframe}
            onChange={(id) => changeTf(id as Timeframe)}
            options={TIMEFRAMES.map((tf) => ({ id: tf, label: TIMEFRAME_LABELS[tf] }))}
          />
        </div>

        <div className="mt-2 rounded-2xl bg-ms-card/60 p-2">
          <CandlestickChart
            candles={candles}
            height={280}
            dates={["10 avr.", "15 avr.", "20 avr.", "25 avr."]}
          />
        </div>

        <p className="mt-4 px-2 text-center text-[12px] leading-relaxed text-ms-muted">
          Choisissez l'unité de temps, puis délimitez la zone à comparer à l'historique.
        </p>
      </Scroll>
      <BottomBar>
        <GhostButton className="mb-2 flex w-full items-center justify-center gap-2" onClick={() => openBacktest(true)}>
          <IconBacktest size={18} />
          Backtest
        </GhostButton>
        <PrimaryButton onClick={launch}>Choisir la zone d'analyse</PrimaryButton>
      </BottomBar>
    </Screen>
  );
}
