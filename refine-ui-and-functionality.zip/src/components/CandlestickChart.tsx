import { useMemo, useRef, useState, type PointerEvent } from "react";
import type { Candle, PatternRange } from "../types";
import { cn } from "../utils/cn";

interface Props {
  candles: Candle[];
  height?: number;
  showVolume?: boolean;
  showAxis?: boolean;
  selection?: PatternRange | null;
  onSelectionChange?: (r: PatternRange) => void;
  interactive?: boolean;
  overlay?: Candle[] | null;
  overlayLabel?: string;
  patternLabel?: string;
  axisValues?: number[];
  dates?: string[];
  highlightLast?: number;
}

type DragMode = "move" | "l" | "r";

interface DragState {
  mode: DragMode;
  originIndex: number;
  originStart: number;
  originEnd: number;
}

function extents(candles: Candle[]) {
  let min = Infinity;
  let max = -Infinity;
  let vmax = 0;
  for (const c of candles) {
    if (c.low < min) min = c.low;
    if (c.high > max) max = c.high;
    if (c.volume > vmax) vmax = c.volume;
  }
  const pad = (max - min) * 0.08 || 1;
  return { min: min - pad, max: max + pad, vmax: vmax || 1 };
}

const MIN_WIDTH = 3;
const HANDLE_HIT = 16;

export function CandlestickChart({
  candles,
  height = 260,
  showVolume = true,
  showAxis = true,
  selection,
  onSelectionChange,
  interactive = false,
  overlay,
  overlayLabel = "Correspondance",
  patternLabel = "Pattern",
  axisValues,
  dates,
  highlightLast,
}: Props) {
  const volH = showVolume ? 46 : 0;
  const plotH = height - volH;
  const padL = showAxis ? 8 : 4;
  const padR = showAxis ? 44 : 8;
  const width = 360;
  const innerW = width - padL - padR;

  const { min, max, vmax } = useMemo(() => extents(candles), [candles]);
  const y = (price: number) => 8 + ((max - price) / (max - min)) * (plotH - 16);
  const x = (i: number) => padL + ((i + 0.5) / candles.length) * innerW;
  const cw = Math.max(2.2, (innerW / candles.length) * 0.62);

  const axis = axisValues ?? niceAxis(min, max);

  const drag = useRef<DragState | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const [activeHandle, setActiveHandle] = useState<DragMode | null>(null);
  const [hoverHandle, setHoverHandle] = useState<DragMode | null>(null);

  const clientToSvgX = (clientX: number, el: SVGSVGElement) => {
    const rect = el.getBoundingClientRect();
    return ((clientX - rect.left) / rect.width) * width;
  };

  const indexFromClientX = (clientX: number, el: SVGSVGElement) => {
    const sx = clientToSvgX(clientX, el);
    const i = Math.round(((sx - padL) / innerW) * candles.length - 0.5);
    return Math.max(0, Math.min(candles.length - 1, i));
  };

  const hitTest = (svgX: number): DragMode | null => {
    if (!selection) return null;
    const leftX = x(selection.startIndex) - cw;
    const rightX = x(selection.endIndex) + cw;
    if (Math.abs(svgX - leftX) <= HANDLE_HIT) return "l";
    if (Math.abs(svgX - rightX) <= HANDLE_HIT) return "r";
    if (svgX >= leftX && svgX <= rightX) return "move";
    return null;
  };

  const onPointerDown = (e: PointerEvent<SVGSVGElement>) => {
    if (!interactive || !onSelectionChange) return;
    const el = e.currentTarget;
    el.setPointerCapture(e.pointerId);
    const i = indexFromClientX(e.clientX, el);
    const svgX = clientToSvgX(e.clientX, el);
    const hit = hitTest(svgX);

    if (selection && hit) {
      drag.current = {
        mode: hit,
        originIndex: i,
        originStart: selection.startIndex,
        originEnd: selection.endIndex,
      };
      setActiveHandle(hit);
    }
  };

  const onPointerMove = (e: PointerEvent<SVGSVGElement>) => {
    const el = e.currentTarget;
    const i = indexFromClientX(e.clientX, el);
    const svgX = clientToSvgX(e.clientX, el);
    setHover(i);
    if (!drag.current) {
      setHoverHandle(interactive ? hitTest(svgX) : null);
    }
    if (!drag.current || !onSelectionChange) return;

    const { mode, originIndex, originStart, originEnd } = drag.current;

    if (mode === "l") {
      const ns = Math.max(0, Math.min(i, originEnd - MIN_WIDTH));
      onSelectionChange({ startIndex: ns, endIndex: originEnd });
    } else if (mode === "r") {
      const ne = Math.min(candles.length - 1, Math.max(i, originStart + MIN_WIDTH));
      onSelectionChange({ startIndex: originStart, endIndex: ne });
    } else if (mode === "move") {
      const len = originEnd - originStart;
      const delta = i - originIndex;
      const ns = Math.max(0, Math.min(candles.length - 1 - len, originStart + delta));
      onSelectionChange({ startIndex: ns, endIndex: ns + len });
    }
  };

  const endDrag = () => {
    drag.current = null;
    setActiveHandle(null);
  };

  const sel =
    selection && candles.length
      ? {
          x: x(selection.startIndex) - cw,
          w: Math.max(8, x(selection.endIndex) - x(selection.startIndex) + cw * 2),
          count: selection.endIndex - selection.startIndex + 1,
        }
      : null;

  const cursorClass = !interactive
    ? ""
    : activeHandle === "move"
      ? "cursor-grabbing"
      : activeHandle === "l" ||
          activeHandle === "r" ||
          hoverHandle === "l" ||
          hoverHandle === "r"
        ? "cursor-ew-resize"
        : hoverHandle === "move"
          ? "cursor-grab"
          : "cursor-default";

  return (
    <div className="relative w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className={cn("w-full touch-none", cursorClass)}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onPointerLeave={() => {
          endDrag();
          setHover(null);
          setHoverHandle(null);
        }}
      >
        <defs>
          <linearGradient id="ms-sel-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2ee6c8" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#2ee6c8" stopOpacity="0.06" />
          </linearGradient>
        </defs>

        {axis.map((v) => (
          <g key={v}>
            <line
              x1={padL}
              x2={width - padR + 6}
              y1={y(v)}
              y2={y(v)}
              stroke="#1c3d5a"
              strokeDasharray="3 5"
              strokeWidth={0.8}
            />
            {showAxis && (
              <text
                x={width - 6}
                y={y(v) + 3}
                textAnchor="end"
                fill="#7d97ad"
                fontSize="8"
                fontFamily="Inter, sans-serif"
              >
                {formatAxis(v)}
              </text>
            )}
          </g>
        ))}

        {sel && (
          <rect
            x={sel.x}
            y={6}
            width={sel.w}
            height={plotH - 10}
            rx={6}
            fill="url(#ms-sel-fill)"
            stroke="#2ee6c8"
            strokeWidth={activeHandle ? 1.6 : 1.2}
          />
        )}

        {candles.map((c, i) => {
          const up = c.close >= c.open;
          const color = up ? "#34d399" : "#f43f5e";
          const outsideSel =
            selection != null && (i < selection.startIndex || i > selection.endIndex);
          const dim = outsideSel
            ? 0.28
            : highlightLast != null && i < candles.length - highlightLast
              ? 0.35
              : 1;
          const bodyTop = y(Math.max(c.open, c.close));
          const bodyBot = y(Math.min(c.open, c.close));
          const bh = Math.max(1.2, bodyBot - bodyTop);
          return (
            <g key={c.time} opacity={dim}>
              <line
                x1={x(i)}
                x2={x(i)}
                y1={y(c.high)}
                y2={y(c.low)}
                stroke={color}
                strokeWidth={1.1}
              />
              <rect
                x={x(i) - cw / 2}
                y={bodyTop}
                width={cw}
                height={bh}
                rx={0.6}
                fill={color}
              />
            </g>
          );
        })}

        {overlay &&
          overlay.slice(0, candles.length).map((c, i) => {
            const up = c.close >= c.open;
            const color = up ? "rgba(96,165,250,0.85)" : "rgba(248,113,113,0.7)";
            const bodyTop = y(Math.max(c.open, c.close));
            const bodyBot = y(Math.min(c.open, c.close));
            return (
              <rect
                key={`ov-${i}`}
                x={x(i) - cw / 2}
                y={bodyTop}
                width={cw}
                height={Math.max(1, bodyBot - bodyTop)}
                fill={color}
                opacity={0.45}
              />
            );
          })}

        {sel && interactive && (
          <SelectionChrome
            sel={sel}
            plotH={plotH}
            width={width}
            padR={padR}
            activeHandle={activeHandle}
            hoverHandle={hoverHandle}
          />
        )}

        {showVolume &&
          candles.map((c, i) => {
            const up = c.close >= c.open;
            const vh = (c.volume / vmax) * (volH - 8);
            return (
              <rect
                key={`v-${c.time}`}
                x={x(i) - cw / 2}
                y={height - 4 - vh}
                width={cw}
                height={vh}
                rx={0.5}
                fill={up ? "#34d399" : "#f43f5e"}
                opacity={0.55}
              />
            );
          })}

        {hover != null && candles[hover] && (
          <line
            x1={x(hover)}
            x2={x(hover)}
            y1={4}
            y2={height - 2}
            stroke="#7d97ad"
            strokeDasharray="2 3"
            strokeWidth={0.8}
          />
        )}
      </svg>

      {dates && dates.length > 0 && (
        <div className="mt-0.5 flex justify-between px-1 text-[10px] text-ms-muted">
          {dates.map((d) => (
            <span key={d}>{d}</span>
          ))}
        </div>
      )}

      {overlay && (
        <div className="mt-2 flex items-center justify-center gap-4 text-[11px] text-ms-muted">
          <span className="flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-full bg-ms-green" /> {patternLabel}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-full bg-sky-400" /> {overlayLabel}
          </span>
        </div>
      )}
    </div>
  );
}

function SelectionChrome({
  sel,
  plotH,
  width,
  padR,
  activeHandle,
  hoverHandle,
}: {
  sel: { x: number; w: number; count: number };
  plotH: number;
  width: number;
  padR: number;
  activeHandle: DragMode | null;
  hoverHandle: DragMode | null;
}) {
  const leftX = sel.x;
  const rightX = sel.x + sel.w;
  const midY = 6 + (plotH - 10) / 2;
  const labelW = 78;
  const labelX = Math.min(
    Math.max(sel.x + sel.w / 2 - labelW / 2, 4),
    width - padR - labelW,
  );
  const leftHot = activeHandle === "l" || hoverHandle === "l";
  const rightHot = activeHandle === "r" || hoverHandle === "r";
  const moveHot = activeHandle === "move" || hoverHandle === "move";

  return (
    <g className="ms-sel-chrome">
      <rect
        x={sel.x + 10}
        y={6}
        width={Math.max(0, sel.w - 20)}
        height={18}
        rx={9}
        fill={moveHot ? "rgba(46,230,200,0.22)" : "rgba(10,27,46,0.55)"}
      />
      {[sel.x + sel.w / 2 - 6, sel.x + sel.w / 2, sel.x + sel.w / 2 + 6].map((gx) => (
        <circle key={gx} cx={gx} cy={15} r={1.3} fill="#9ee9d8" />
      ))}

      <rect
        x={labelX}
        y={plotH - 20}
        width={labelW}
        height={15}
        rx={7.5}
        fill="#0a1b2e"
        stroke="#2ee6c8"
        strokeWidth={0.9}
      />
      <text
        x={labelX + labelW / 2}
        y={plotH - 9.5}
        textAnchor="middle"
        fill="#2ee6c8"
        fontSize="8.5"
        fontWeight="700"
        fontFamily="Inter, sans-serif"
      >
        {sel.count} bougies
      </text>

      <EdgeHandle x={leftX} midY={midY} plotH={plotH} hot={leftHot} />
      <EdgeHandle x={rightX} midY={midY} plotH={plotH} hot={rightHot} />
    </g>
  );
}

function EdgeHandle({
  x,
  midY,
  plotH,
  hot,
}: {
  x: number;
  midY: number;
  plotH: number;
  hot: boolean;
}) {
  const r = hot ? 8 : 6.5;
  return (
    <g>
      <rect
        x={x - 2.5}
        y={8}
        width={5}
        height={plotH - 14}
        rx={2.5}
        fill={hot ? "#5ff0d4" : "#2ee6c8"}
        opacity={0.95}
      />
      <circle cx={x} cy={midY} r={r} fill="#f4fffb" stroke="#2ee6c8" strokeWidth={1.6} />
      <path
        d={`M${x - 2.2} ${midY - 3.2} L${x - 4.4} ${midY} L${x - 2.2} ${midY + 3.2}`}
        fill="none"
        stroke="#0a1b2e"
        strokeWidth={1.2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d={`M${x + 2.2} ${midY - 3.2} L${x + 4.4} ${midY} L${x + 2.2} ${midY + 3.2}`}
        fill="none"
        stroke="#0a1b2e"
        strokeWidth={1.2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </g>
  );
}

export function MiniSpark({
  candles,
  className,
}: {
  candles: Candle[];
  className?: string;
}) {
  const w = 72;
  const h = 40;
  const { min, max } = extents(candles);
  const x = (i: number) => (i / Math.max(1, candles.length - 1)) * w;
  const y = (p: number) => ((max - p) / (max - min || 1)) * (h - 4) + 2;
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className={cn("h-8 w-14 shrink-0 overflow-visible sm:h-10 sm:w-[72px]", className)}
      preserveAspectRatio="xMidYMid meet"
    >
      {candles.map((c, i) => {
        const up = c.close >= c.open;
        const color = up ? "#34d399" : "#f43f5e";
        const cw = Math.max(1.4, w / candles.length - 0.6);
        const top = y(Math.max(c.open, c.close));
        const bot = y(Math.min(c.open, c.close));
        return (
          <g key={i}>
            <line
              x1={x(i)}
              x2={x(i)}
              y1={y(c.high)}
              y2={y(c.low)}
              stroke={color}
              strokeWidth={0.8}
            />
            <rect
              x={x(i) - cw / 2}
              y={top}
              width={cw}
              height={Math.max(1, bot - top)}
              fill={color}
            />
          </g>
        );
      })}
    </svg>
  );
}

export function RateChart({ values }: { values: number[] }) {
  const w = 360;
  const h = 110;
  const pts = values.length ? values : [50, 50];
  const min = 0;
  const max = 100;
  const x = (i: number) => (i / Math.max(1, pts.length - 1)) * (w - 48) + 8;
  const y = (v: number) => 8 + ((max - v) / (max - min)) * (h - 24);
  const d = pts.map((v, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(v)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
      {[0, 25, 50, 75, 100].map((tick) => (
        <g key={tick}>
          <line
            x1={8}
            x2={w - 36}
            y1={y(tick)}
            y2={y(tick)}
            stroke="#1c3d5a"
            strokeDasharray="3 4"
          />
          <text x={w - 6} y={y(tick) + 3} textAnchor="end" fill="#7d97ad" fontSize="8">
            {tick}%
          </text>
        </g>
      ))}
      <path d={d} fill="none" stroke="#34d399" strokeWidth={1.8} />
    </svg>
  );
}

export function EquityChart({ values }: { values: number[] }) {
  const w = 360;
  const h = 110;
  const min = Math.min(...values) - 1;
  const max = Math.max(...values) + 1;
  const x = (i: number) => (i / (values.length - 1)) * (w - 48) + 8;
  const y = (v: number) => 8 + ((max - v) / (max - min)) * (h - 24);
  const d = values.map((v, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(v)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
      {[0, 10, 20].map((tick) => (
        <g key={tick}>
          <line
            x1={8}
            x2={w - 36}
            y1={y(tick)}
            y2={y(tick)}
            stroke="#1c3d5a"
            strokeDasharray="3 4"
          />
          <text x={w - 6} y={y(tick) + 3} textAnchor="end" fill="#7d97ad" fontSize="8">
            {tick > 0 ? `+${tick}%` : `${tick}%`}
          </text>
        </g>
      ))}
      <path d={d} fill="none" stroke="#f87171" strokeWidth={1.5} opacity={0.45} />
      <path d={d} fill="none" stroke="#34d399" strokeWidth={1.8} />
      <path
        d={`${d} L${x(values.length - 1)},${h - 4} L${x(0)},${h - 4} Z`}
        fill="url(#eq)"
        opacity={0.25}
      />
      <defs>
        <linearGradient id="eq" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#34d399" />
          <stop offset="100%" stopColor="#34d399" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function niceAxis(min: number, max: number): number[] {
  const span = max - min;
  const step = niceStep(span / 4);
  const start = Math.ceil(min / step) * step;
  const out: number[] = [];
  for (let v = start; v <= max; v += step) out.push(v);
  return out.slice(0, 5);
}

function niceStep(raw: number) {
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / pow;
  const nice = n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10;
  return nice * pow;
}

function formatAxis(v: number) {
  if (v >= 1000) return v.toLocaleString("fr-FR", { maximumFractionDigits: 0 });
  return v.toLocaleString("fr-FR", { maximumFractionDigits: 4 });
}
