/**
 * MarketScope — socle mobile-first.
 *
 * Navigation : pile d'écrans dans AppContext (pas de react-router).
 * Données : src/services/api.ts (MOCK aujourd'hui, HTTP demain).
 * UI : src/screens/* + src/components/*
 *
 * Toutes les séries (BTC 68 542,32 $, scores, backtest…) sont fictives
 * et documentées dans src/data/mock.ts.
 */
import { AppProvider, NavigationGuard, useApp } from "./context/AppContext";
import { Toast } from "./components/ui";
import { WelcomeScreen } from "./screens/WelcomeScreen";
import { AssetSelectScreen } from "./screens/AssetSelectScreen";
import { ChartScreen } from "./screens/ChartScreen";
import { PatternScreen } from "./screens/PatternScreen";
import { SyncScreen } from "./screens/SyncScreen";
import { MatchesScreen } from "./screens/MatchesScreen";
import { MatchDetailScreen } from "./screens/MatchDetailScreen";
import { ScenariosScreen } from "./screens/ScenariosScreen";
import { ConditionsScreen } from "./screens/ConditionsScreen";
import { PeriodScreen } from "./screens/PeriodScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { BacktestScreen } from "./screens/BacktestScreen";
import { ExportScreen } from "./screens/ExportScreen";
import { HelpArticleScreen, HelpScreen } from "./screens/HelpScreen";
import { MenuScreen } from "./screens/MenuScreen";
import { AdvancedScreen, CacheScreen, DataSourcesScreen } from "./screens/DataSourcesScreen";
import { HistoryScreen } from "./screens/HistoryScreen";
import type { ScreenId } from "./types";
import { cn } from "./utils/cn";

function ScreenRouter() {
  const { screen } = useApp();
  switch (screen as ScreenId) {
    case "welcome":
      return <WelcomeScreen />;
    case "assets":
      return <AssetSelectScreen />;
    case "chart":
      return <ChartScreen />;
    case "pattern":
      return <PatternScreen />;
    case "sync":
      return <SyncScreen />;
    case "matches":
      return <MatchesScreen />;
    case "matchDetail":
      return <MatchDetailScreen />;
    case "scenarios":
      return <ScenariosScreen />;
    case "conditions":
      return <ConditionsScreen />;
    case "period":
      return <PeriodScreen />;
    case "settings":
      return <SettingsScreen />;
    case "backtest":
      return <BacktestScreen />;
    case "export":
      return <ExportScreen />;
    case "help":
      return <HelpScreen />;
    case "helpArticle":
      return <HelpArticleScreen />;
    case "menu":
      return <MenuScreen />;
    case "dataSources":
      return <DataSourcesScreen />;
    case "cache":
      return <CacheScreen />;
    case "advanced":
      return <AdvancedScreen />;
    case "history":
      return <HistoryScreen />;
    default:
      return <AssetSelectScreen />;
  }
}

function Shell() {
  const { direction, screen, toast } = useApp();
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#050d18]">
      <NavigationGuard />
      <div className="relative flex h-[100dvh] w-full max-w-[430px] flex-col overflow-hidden bg-ms-bg shadow-2xl shadow-black/50 ring-1 ring-white/5 sm:h-[min(874px,100dvh)] sm:rounded-[32px]">
        <div
          key={screen}
          className={cn(
            "flex min-h-0 flex-1 flex-col",
            direction === "back" ? "ms-enter-back" : "ms-enter-fwd",
          )}
        >
          <ScreenRouter />
        </div>
        {toast && <Toast message={toast.message} />}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
