import { useMemo, useRef, useState, type PointerEvent } from "react";
import type { Candle, PatternRange } from "../types";
import { cn } from "../utils/cn";

interface Props {
  candles: Candle[];
  height?: number;
  showVolume?: boolean;
  showAxis?: boolean;
  selection?: PatternRange | null;
  onSelectionChange?: (r: PatternRange) => void;
  interactive?: boolean;
  overlay?: Candle[] | null;
  overlayLabel?: string;
  patternLabel?: string;
  axisValues?: number[];
  dates?: string[];
  highlightLast?: number;
}

function extents(candles: Candle[]) {
  let min = Infinity;
  let max = -Infinity;
  let vmax = 0;
  for (const c of candles) {
    if (c.low < min) min = c.low;
    if (c.high > max) max = c.high;
    if (c.volume > vmax) vmax = c.volume;
  }
  const pad = (max - min) * 0.08 || 1;
  return { min: min - pad, max: max + pad, vmax: vmax || 1 };
}

export function CandlestickChart({
  candles,
  height = 260,
  showVolume = true,
  showAxis = true,
  selection,
  onSelectionChange,
  interactive = false,
  overlay,
  overlayLabel = "Correspondance",
  patternLabel = "Pattern",
  axisValues,
  dates,
  highlightLast,
}: Props) {
  const volH = showVolume ? 46 : 0;
  const plotH = height - volH;
  const padL = showAxis ? 8 : 4;
  const padR = showAxis ? 44 : 8;
  const width = 360;
  const innerW = width - padL - padR;

  const { min, max, vmax } = useMemo(() => extents(candles), [candles]);
  const y = (price: number) =>
    8 + ((max - price) / (max - min)) * (plotH - 16);
  const x = (i: number) => padL + ((i + 0.5) / candles.length) * innerW;
  const cw = Math.max(2.2, (innerW / candles.length) * 0.62);

  const axis = axisValues ?? niceAxis(min, max);

  const drag = useRef<{ start: number; mode: "move" | "l" | "r" } | null>(null);
  const [hover, setHover] = useState<number | null>(null);

  const indexFromClientX = (clientX: number, el: SVGSVGElement) => {
    const rect = el.getBoundingClientRect();
    const sx = ((clientX - rect.left) / rect.width) * width;
    const i = Math.round(((sx - padL) / innerW) * candles.length - 0.5);
    return Math.max(0, Math.min(candles.length - 1, i));
  };

  const onPointerDown = (e: PointerEvent<SVGSVGElement>) => {
    if (!interactive || !selection || !onSelectionChange) return;
    const el = e.currentTarget;
    el.setPointerCapture(e.pointerId);
    const i = indexFromClientX(e.clientX, el);
    const nearL = Math.abs(i - selection.startIndex) <= 2;
    const nearR = Math.abs(i - selection.endIndex) <= 2;
    const inside = i >= selection.startIndex && i <= selection.endIndex;
    drag.current = {
      start: i,
      mode: nearL ? "l" : nearR ? "r" : inside ? "move" : "move",
    };
    if (!inside && !nearL && !nearR) {
      onSelectionChange({ startIndex: i, endIndex: Math.min(candles.length - 1, i + 12) });
    }
  };

  const onPointerMove = (e: PointerEvent<SVGSVGElement>) => {
    const el = e.currentTarget;
    const i = indexFromClientX(e.clientX, el);
    setHover(i);
    if (!drag.current || !selection || !onSelectionChange) return;
    const { start, mode } = drag.current;
    if (mode === "l") {
      onSelectionChange({
        startIndex: Math.min(i, selection.endIndex - 3),
        endIndex: selection.endIndex,
      });
    } else if (mode === "r") {
      onSelectionChange({
        startIndex: selection.startIndex,
        endIndex: Math.max(i, selection.startIndex + 3),
      });
    } else {
      const len = selection.endIndex - selection.startIndex;
      const delta = i - start;
      let ns = selection.startIndex + delta;
      ns = Math.max(0, Math.min(candles.length - 1 - len, ns));
      drag.current.start = i;
      onSelectionChange({ startIndex: ns, endIndex: ns + len });
    }
  };

  const sel =
    selection && candles.length
      ? {
          x: x(selection.startIndex) - cw,
          w: x(selection.endIndex) - x(selection.startIndex) + cw * 2,
        }
      : null;

  return (
    <div className="relative w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className={cn("w-full", interactive && "cursor-ew-resize touch-none")}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={() => {
          drag.current = null;
        }}
        onPointerLeave={() => {
          drag.current = null;
          setHover(null);
        }}
      >
        {axis.map((v) => (
          <g key={v}>
            <line
              x1={padL}
              x2={width - padR + 6}
              y1={y(v)}
              y2={y(v)}
              stroke="#1c3d5a"
              strokeDasharray="3 5"
              strokeWidth={0.8}
            />
            {showAxis && (
              <text
                x={width - 6}
                y={y(v) + 3}
                textAnchor="end"
                fill="#7d97ad"
                fontSize="8"
                fontFamily="Inter, sans-serif"
              >
                {formatAxis(v)}
              </text>
            )}
          </g>
        ))}

        {sel && (
          <rect
            x={sel.x}
            y={6}
            width={sel.w}
            height={plotH - 10}
            rx={6}
            fill="rgba(46,230,200,0.10)"
            stroke="#2ee6c8"
            strokeWidth={1.4}
          />
        )}

        {candles.map((c, i) => {
          const up = c.close >= c.open;
          const color = up ? "#34d399" : "#f43f5e";
          const dim =
            highlightLast != null && i < candles.length - highlightLast
              ? 0.35
              : 1;
          const bodyTop = y(Math.max(c.open, c.close));
          const bodyBot = y(Math.min(c.open, c.close));
          const bh = Math.max(1.2, bodyBot - bodyTop);
          return (
            <g key={c.time} opacity={dim}>
              <line
                x1={x(i)}
                x2={x(i)}
                y1={y(c.high)}
                y2={y(c.low)}
                stroke={color}
                strokeWidth={1.1}
              />
              <rect
                x={x(i) - cw / 2}
                y={bodyTop}
                width={cw}
                height={bh}
                rx={0.6}
                fill={color}
              />
            </g>
          );
        })}

        {overlay &&
          overlay.slice(0, candles.length).map((c, i) => {
            const up = c.close >= c.open;
            const color = up ? "rgba(96,165,250,0.85)" : "rgba(248,113,113,0.7)";
            const bodyTop = y(Math.max(c.open, c.close));
            const bodyBot = y(Math.min(c.open, c.close));
            return (
              <rect
                key={`ov-${i}`}
                x={x(i) - cw / 2}
                y={bodyTop}
                width={cw}
                height={Math.max(1, bodyBot - bodyTop)}
                fill={color}
                opacity={0.45}
              />
            );
          })}

        {sel && interactive && (
          <>
            {(["l", "r"] as const).map((side) => {
              const hx = side === "l" ? sel.x : sel.x + sel.w;
              const hy = [6, plotH / 2, plotH - 4];
              return hy.map((yy, k) => (
                <rect
                  key={`${side}-${k}`}
                  x={hx - 4.5}
                  y={yy - 4.5}
                  width={9}
                  height={9}
                  rx={1.5}
                  fill="#e8f7ff"
                  stroke="#9ec9e6"
                  strokeWidth={0.8}
                />
              ));
            })}
          </>
        )}

        {showVolume &&
          candles.map((c, i) => {
            const up = c.close >= c.open;
            const vh = (c.volume / vmax) * (volH - 8);
            return (
              <rect
                key={`v-${c.time}`}
                x={x(i) - cw / 2}
                y={height - 4 - vh}
                width={cw}
                height={vh}
                rx={0.5}
                fill={up ? "#34d399" : "#f43f5e"}
                opacity={0.55}
              />
            );
          })}

        {hover != null && candles[hover] && (
          <line
            x1={x(hover)}
            x2={x(hover)}
            y1={4}
            y2={height - 2}
            stroke="#7d97ad"
            strokeDasharray="2 3"
            strokeWidth={0.8}
          />
        )}
      </svg>

      {dates && dates.length > 0 && (
        <div className="mt-0.5 flex justify-between px-1 text-[10px] text-ms-muted">
          {dates.map((d) => (
            <span key={d}>{d}</span>
          ))}
        </div>
      )}

      {overlay && (
        <div className="mt-2 flex items-center justify-center gap-4 text-[11px] text-ms-muted">
          <span className="flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-full bg-ms-green" /> {patternLabel}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-full bg-sky-400" /> {overlayLabel}
          </span>
        </div>
      )}
    </div>
  );
}

export function MiniSpark({
  candles,
  className,
}: {
  candles: Candle[];
  className?: string;
}) {
  const w = 72;
  const h = 40;
  const { min, max } = extents(candles);
  const x = (i: number) => (i / Math.max(1, candles.length - 1)) * w;
  const y = (p: number) => ((max - p) / (max - min || 1)) * (h - 4) + 2;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={cn("overflow-visible", className)} width={72} height={40}>
      {candles.map((c, i) => {
        const up = c.close >= c.open;
        const color = up ? "#34d399" : "#f43f5e";
        const cw = Math.max(1.4, w / candles.length - 0.6);
        const top = y(Math.max(c.open, c.close));
        const bot = y(Math.min(c.open, c.close));
        return (
          <g key={i}>
            <line
              x1={x(i)}
              x2={x(i)}
              y1={y(c.high)}
              y2={y(c.low)}
              stroke={color}
              strokeWidth={0.8}
            />
            <rect
              x={x(i) - cw / 2}
              y={top}
              width={cw}
              height={Math.max(1, bot - top)}
              fill={color}
            />
          </g>
        );
      })}
    </svg>
  );
}

export function EquityChart({ values }: { values: number[] }) {
  const w = 360;
  const h = 110;
  const min = Math.min(...values) - 1;
  const max = Math.max(...values) + 1;
  const x = (i: number) => (i / (values.length - 1)) * (w - 48) + 8;
  const y = (v: number) => 8 + ((max - v) / (max - min)) * (h - 24);
  const d = values.map((v, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(v)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
      {[0, 10, 20].map((tick) => (
        <g key={tick}>
          <line
            x1={8}
            x2={w - 36}
            y1={y(tick)}
            y2={y(tick)}
            stroke="#1c3d5a"
            strokeDasharray="3 4"
          />
          <text x={w - 6} y={y(tick) + 3} textAnchor="end" fill="#7d97ad" fontSize="8">
            {tick > 0 ? `+${tick}%` : `${tick}%`}
          </text>
        </g>
      ))}
      <path d={d} fill="none" stroke="#f87171" strokeWidth={1.5} opacity={0.45} />
      <path d={d} fill="none" stroke="#34d399" strokeWidth={1.8} />
      <path
        d={`${d} L${x(values.length - 1)},${h - 4} L${x(0)},${h - 4} Z`}
        fill="url(#eq)"
        opacity={0.25}
      />
      <defs>
        <linearGradient id="eq" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#34d399" />
          <stop offset="100%" stopColor="#34d399" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function niceAxis(min: number, max: number): number[] {
  const span = max - min;
  const step = niceStep(span / 4);
  const start = Math.ceil(min / step) * step;
  const out: number[] = [];
  for (let v = start; v <= max; v += step) out.push(v);
  return out.slice(0, 5);
}

function niceStep(raw: number) {
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / pow;
  const nice = n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10;
  return nice * pow;
}

function formatAxis(v: number) {
  if (v >= 1000) return v.toLocaleString("fr-FR", { maximumFractionDigits: 0 });
  return v.toLocaleString("fr-FR", { maximumFractionDigits: 4 });
}
