import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { MOCK_ASSETS, MOCK_BTC_CANDLES, MOCK_MATCHES } from "../data/mock";
import type {
  AppSettings,
  Asset,
  AssetCategory,
  Candle,
  ExportConfig,
  PatternMatch,
  PatternRange,
  PeriodConfig,
  ScreenId,
  SelectionMode,
  Timeframe,
} from "../types";

interface Toast {
  id: number;
  message: string;
}

interface NavEntry {
  screen: ScreenId;
  articleId?: string;
}

interface AppState {
  stack: NavEntry[];
  screen: ScreenId;
  articleId?: string;
  direction: "fwd" | "back";
  categoryFilter: AssetCategory | "all";
  selectedAsset: Asset;
  timeframe: Timeframe;
  selectionMode: SelectionMode;
  patternRange: PatternRange;
  candles: Candle[];
  matches: PatternMatch[];
  selectedMatch: PatternMatch;
  matchTab: "vue" | "details" | "evolution";
  settings: AppSettings;
  period: PeriodConfig;
  exportConfig: ExportConfig;
  favorite: boolean;
  toast: Toast | null;
  demoBanner: boolean;
}

interface AppContextValue extends AppState {
  navigate: (screen: ScreenId, extra?: { articleId?: string }) => void;
  goBack: () => void;
  resetTo: (screen: ScreenId) => void;
  setCategoryFilter: (c: AssetCategory | "all") => void;
  setSelectedAsset: (a: Asset) => void;
  setTimeframe: (t: Timeframe) => void;
  setSelectionMode: (m: SelectionMode) => void;
  setPatternRange: (r: PatternRange) => void;
  setCandles: (c: Candle[]) => void;
  setMatches: (m: PatternMatch[]) => void;
  setSelectedMatch: (m: PatternMatch) => void;
  setMatchTab: (t: "vue" | "details" | "evolution") => void;
  setSettings: (s: AppSettings | ((p: AppSettings) => AppSettings)) => void;
  setPeriod: (p: PeriodConfig | ((prev: PeriodConfig) => PeriodConfig)) => void;
  setExportConfig: (e: ExportConfig | ((p: ExportConfig) => ExportConfig)) => void;
  setFavorite: (v: boolean) => void;
  showToast: (message: string) => void;
  hideToast: () => void;
  dismissDemoBanner: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const defaultSettings: AppSettings = {
  mode: "auto",
  cloudflare: true,
  directProviders: true,
  localFolder: false,
  granularity: "1h",
  resultCount: 20,
  searchLimit: 500,
};

const defaultPeriod: PeriodConfig = {
  kind: "lastCandles",
  candleCount: 500,
  start: "2024-01-01",
  end: "2025-04-25",
  since: "2024-01-01",
};

const defaultExport: ExportConfig = {
  format: "pdf",
  includeCharts: true,
  includeMatches: true,
  includeScenarios: true,
  includeSettings: true,
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<NavEntry[]>([{ screen: "welcome" }]);
  const [direction, setDirection] = useState<"fwd" | "back">("fwd");
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | "all">("all");
  const [selectedAsset, setSelectedAsset] = useState<Asset>(MOCK_ASSETS[0]);
  const [timeframe, setTimeframe] = useState<Timeframe>("1h");
  const [selectionMode, setSelectionMode] = useState<SelectionMode>("auto");
  const [patternRange, setPatternRange] = useState<PatternRange>({
    startIndex: 64,
    endIndex: 88,
  });
  const [candles, setCandles] = useState<Candle[]>(MOCK_BTC_CANDLES);
  const [matches, setMatches] = useState<PatternMatch[]>(MOCK_MATCHES);
  const [selectedMatch, setSelectedMatch] = useState<PatternMatch>(MOCK_MATCHES[0]);
  const [matchTab, setMatchTab] = useState<"vue" | "details" | "evolution">("vue");
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [period, setPeriod] = useState<PeriodConfig>(defaultPeriod);
  const [exportConfig, setExportConfig] = useState<ExportConfig>(defaultExport);
  const [favorite, setFavorite] = useState(true);
  const [toast, setToast] = useState<Toast | null>(null);
  const [demoBanner, setDemoBanner] = useState(true);

  const current = stack[stack.length - 1];

  const navigate = useCallback((screen: ScreenId, extra?: { articleId?: string }) => {
    setDirection("fwd");
    setStack((s) => [...s, { screen, articleId: extra?.articleId }]);
  }, []);

  const goBack = useCallback(() => {
    setDirection("back");
    setStack((s) => (s.length > 1 ? s.slice(0, -1) : s));
  }, []);

  const resetTo = useCallback((screen: ScreenId) => {
    setDirection("fwd");
    setStack([{ screen }]);
  }, []);

  const showToast = useCallback((message: string) => {
    const id = Date.now();
    setToast({ id, message });
    window.setTimeout(() => {
      setToast((t) => (t?.id === id ? null : t));
    }, 2600);
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      stack,
      screen: current.screen,
      articleId: current.articleId,
      direction,
      categoryFilter,
      selectedAsset,
      timeframe,
      selectionMode,
      patternRange,
      candles,
      matches,
      selectedMatch,
      matchTab,
      settings,
      period,
      exportConfig,
      favorite,
      toast,
      demoBanner,
      navigate,
      goBack,
      resetTo,
      setCategoryFilter,
      setSelectedAsset,
      setTimeframe,
      setSelectionMode,
      setPatternRange,
      setCandles,
      setMatches,
      setSelectedMatch,
      setMatchTab,
      setSettings,
      setPeriod,
      setExportConfig,
      setFavorite,
      showToast,
      hideToast: () => setToast(null),
      dismissDemoBanner: () => setDemoBanner(false),
    }),
    [
      stack,
      current,
      direction,
      categoryFilter,
      selectedAsset,
      timeframe,
      selectionMode,
      patternRange,
      candles,
      matches,
      selectedMatch,
      matchTab,
      settings,
      period,
      exportConfig,
      favorite,
      toast,
      demoBanner,
      navigate,
      goBack,
      resetTo,
      showToast,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
