import { BitcoinBadge } from "../components/Icons";
import { BottomBar, PrimaryButton, Screen, StatusBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import type { AssetCategory } from "../types";

function MountainSky() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,#163a5c_0%,#071422_55%,#050d18_100%)]" />
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 390 844" preserveAspectRatio="xMidYMin slice">
        {Array.from({ length: 40 }).map((_, i) => (
          <circle
            key={i}
            cx={(i * 97) % 390}
            cy={20 + ((i * 53) % 220)}
            r={i % 5 === 0 ? 1.2 : 0.6}
            fill="white"
            opacity={0.15 + (i % 4) * 0.08}
          />
        ))}
        <path
          d="M0 310 L70 230 L110 270 L170 180 L210 240 L260 150 L320 240 L390 190 L390 844 L0 844 Z"
          fill="#0a1c30"
          opacity="0.9"
        />
        <path
          d="M0 360 L50 300 L90 340 L140 250 L190 330 L250 220 L310 310 L360 250 L390 290 L390 844 L0 844 Z"
          fill="#071422"
        />
        <path
          d="M0 430 L80 360 L130 400 L200 310 L270 390 L330 340 L390 380 L390 844 L0 844 Z"
          fill="#06101c"
          opacity="0.85"
        />
      </svg>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#071422]/40 to-[#071422]" />
    </div>
  );
}

const CATEGORIES: {
  id: AssetCategory;
  title: string;
  subtitle: string;
  icon: "btc" | "forex" | "stock" | "commodity";
}[] = [
  { id: "crypto", title: "Cryptomonnaies", subtitle: "BTC, ETH, etc.", icon: "btc" },
  { id: "forex", title: "Forex", subtitle: "EUR/USD, GBP/USD, etc.", icon: "forex" },
  { id: "stock", title: "Actions", subtitle: "AAPL, MSFT, etc.", icon: "stock" },
  { id: "commodity", title: "Matières premières", subtitle: "Or, pétrole, etc.", icon: "commodity" },
];

function CatIcon({ kind }: { kind: (typeof CATEGORIES)[number]["icon"] }) {
  if (kind === "btc") return <BitcoinBadge />;
  if (kind === "forex")
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1a9b8a]">
        <span className="text-lg font-bold text-white">£</span>
      </div>
    );
  if (kind === "stock")
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#6d5efc]">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2">
          <path d="M4 16l5-6 4 3 7-8" />
        </svg>
      </div>
    );
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#c9a227]">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3a2a00" strokeWidth="2">
        <ellipse cx="12" cy="8" rx="7" ry="3" />
        <path d="M5 8v8c0 1.7 3.1 3 7 3s7-1.3 7-3V8" />
      </svg>
    </div>
  );
}

export function WelcomeScreen() {
  const { navigate, setCategoryFilter } = useApp();

  const open = (cat: AssetCategory | "all") => {
    setCategoryFilter(cat);
    navigate("assets");
  };

  return (
    <Screen className="relative overflow-hidden">
      <MountainSky />
      <div className="relative flex min-h-0 flex-1 flex-col">
        <StatusBar />
        <div className="flex flex-1 flex-col px-5 pt-6">
          <div className="ms-fade flex flex-col items-center pt-4 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#10283f] shadow-lg shadow-emerald-500/10 ring-1 ring-white/10">
              <svg width="36" height="36" viewBox="0 0 48 48" fill="none">
                <path
                  d="M8 32l8-9 6 5 10-14 8 8"
                  stroke="#34d399"
                  strokeWidth="3.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M32 14h8v8"
                  stroke="#34d399"
                  strokeWidth="3.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <h1 className="text-[34px] font-extrabold tracking-tight text-white">MarketScope</h1>
            <p className="mt-2 max-w-[260px] text-[14px] leading-snug text-ms-muted">
              Analysez les marchés, repérez les opportunités
            </p>
          </div>

          <div className="mt-8 flex flex-col gap-3">
            {CATEGORIES.map((c, i) => (
              <button
                key={c.id}
                type="button"
                onClick={() => open(c.id)}
                className={`ms-fade ms-delay-${i + 1} flex items-center gap-3 rounded-2xl border border-white/5 bg-[#0e243a]/90 px-3.5 py-3 text-left shadow-sm backdrop-blur-sm active:bg-[#163049]`}
              >
                <CatIcon kind={c.icon} />
                <div className="flex-1">
                  <div className="text-[15px] font-semibold text-white">{c.title}</div>
                  <div className="text-[12px] text-ms-muted">{c.subtitle}</div>
                </div>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#7d97ad" strokeWidth="2">
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </button>
            ))}
          </div>
        </div>
        <BottomBar>
          <PrimaryButton tone="blue" onClick={() => open("all")}>
            Commencer
          </PrimaryButton>
        </BottomBar>
      </div>
    </Screen>
  );
}
