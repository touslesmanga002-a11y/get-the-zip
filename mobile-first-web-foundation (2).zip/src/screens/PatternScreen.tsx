import { CandlestickChart } from "../components/CandlestickChart";
import {
  BottomBar,
  GhostButton,
  Header,
  PrimaryButton,
  Screen,
  Scroll,
  Segmented,
  StatusBar,
} from "../components/ui";
import { useApp } from "../context/AppContext";

export function PatternScreen() {
  const {
    goBack,
    navigate,
    candles,
    patternRange,
    setPatternRange,
    selectionMode,
    setSelectionMode,
  } = useApp();

  const reset = () => {
    setPatternRange({
      startIndex: Math.max(0, candles.length - 26),
      endIndex: candles.length - 2,
    });
    setSelectionMode("auto");
  };

  const count = patternRange.endIndex - patternRange.startIndex + 1;

  return (
    <Screen>
      <StatusBar />
      <Header title="Sélection du pattern" onBack={goBack} />
      <div className="px-4 pb-2">
        <Segmented
          value={selectionMode}
          onChange={(id) => setSelectionMode(id as "auto" | "manual")}
          options={[
            { id: "auto", label: "Auto" },
            { id: "manual", label: "Manuel" },
          ]}
        />
      </div>
      <Scroll>
        <div className="rounded-2xl bg-ms-card/70 p-2">
          <CandlestickChart
            candles={candles}
            height={250}
            showVolume={false}
            selection={patternRange}
            onSelectionChange={setPatternRange}
            interactive
            highlightLast={count + 4}
          />
        </div>
        <p className="mt-5 px-2 text-center text-[13px] leading-relaxed text-ms-muted">
          Le pattern a été automatiquement détecté sur les{" "}
          <span className="font-semibold text-white">{count} dernières bougies</span>.
          Vous pouvez ajuster la zone ci-dessus ou passer en mode manuel.
        </p>
      </Scroll>
      <BottomBar>
        <div className="flex gap-3">
          <GhostButton className="flex-1" onClick={reset}>
            Réinitialiser
          </GhostButton>
          <PrimaryButton className="flex-1" onClick={() => navigate("sync")}>
            Continuer
          </PrimaryButton>
        </div>
      </BottomBar>
    </Screen>
  );
}
